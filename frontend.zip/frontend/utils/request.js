import axios from 'axios';

class AxiosInstance {
  constructor() {
    this.instance = axios.create({
      baseURL: 'https://mychat.apiv2.zyy.muo.cc', // 设置默认的 baseURL  http://localhost:9528  
      timeout: 10000, // 请求超时设置
      headers: {
        'Content-Type': 'application/json', // 默认 Content-Type
      },
    });

    // 请求拦截器
    this.instance.interceptors.request.use(
      (config) => {
        // 处理请求头，例如加上 token
        const token = localStorage.getItem('mychatToken');
        if (token) {
          config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // 响应拦截器
    this.instance.interceptors.response.use(
      (response) => {
        if (response.data.code !== 200) {
          return Promise.reject(new Error(response.data.message || '请求失败'));
        }
        return response.data; // 直接返回 data
      },
      (error) => {
        console.error('请求错误:', error);
        return Promise.reject(error);
        
      }
    );
  }

  // GET 请求
  async get(url, params = {}, headers = {}) {
    try {
      const response = await this.instance.get(url, { params, headers });
      return response;
    } catch (error) {
      throw error;
    }
  }

  // POST 请求，可传递 headers
  async post(url, data = {}, headers = {}) {
    try {
      const response = await this.instance.post(url, data, {
        headers: { ...this.instance.defaults.headers, ...headers },
      });
      return response;
    } catch (error) {
      throw error;
    }
  }

  // PUT 请求，可传递 headers
  async put(url, data = {}, headers = {}) {
    try {
      const response = await this.instance.put(url, data, {
        headers: { ...this.instance.defaults.headers, ...headers },
      });
      return response;
    } catch (error) {
      throw error;
    }
  }

  // DELETE 请求，可传递 headers
  async delete(url, data = {}, headers = {}) {
    try {
      const response = await this.instance.delete(url, {
        data,
        headers: { ...this.instance.defaults.headers, ...headers },
      });
      return response;
    } catch (error) {
      throw error;
    }
  }
}

export default new AxiosInstance();
