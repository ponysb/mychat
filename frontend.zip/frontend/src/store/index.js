import Axios from '../../utils/request';
import { defineStore } from "pinia";
import { nextTick } from "vue";
export const useMainStore = defineStore('main', {
    state: () => {
        return {
            config:{
                port:'https://mychat.apiv2.zyy.muo.cc',
                socket: 'https://mychat.apiv2.zyy.muo.cc'
                // port:'http://127.0.0.1:9528',
                // socket: 'http://127.0.0.1:9528'
            },
            user:{
                rooms: [],  // 房间列表里边不包含真正的房间信息，只包含房间id和房间备注在房间的昵称状态等
                username: '',  // 用户名
                avatar: '',  // 头像
                nickname: '',  // 昵称
                status: '',  // 状态
                email: '',  // 邮箱
                phone: '',  // 手机号
                gender: '',  // 性别
                friends: '',  // 好友列表
            },

            rooms: [],  // 这是真正的房间列表以及信息
            select_room: {  // 当前选择的房间id
                room_id: '',  // 当前选择的房间id
                index: 0,  // 当前选择的房间索引
                messages: [],  // 当前房间消息列表
            },

            roomApps:[],  // 当前房间内应用列表
            isOwner:false,   // 当前房间是否是房主

            socket: null,  // socket连接
            badgeData:[],

            stockholder:{   // 股东弹窗是否显示
                visible: false,  // 股东弹窗是否显示
            },


            terminal: false,  // 控制台是否显示

            ac:'', // 邀请码

            menu:{
                menu_list: [  // 菜单列表
                    {name:'聊天室',type:'chat',icon: 'https://img.zyy.muo.cc/icon_/chat.svg',url:'', app_id:'chat'},
                    {name:'应用',type:'app',icon:'https://img.zyy.muo.cc/icon_/link.svg',url:'',app_id:'app'},
                    {name:'内置浏览器',type:'browser',icon:'https://img.zyy.muo.cc/icon_/browser.svg',url:'https://moyugo.com/yiweihot/index.html',app_id:'news'},
                ],
                app_list: []  // 应用列表
            },

            drawer: {  // 侧边栏状态
                visible: false,  // 侧边栏是否显示
                ranks:[],  // 排行榜
                    
                stockholder:[],  // 股东
                float: {  // 悬浮球状态
                    visible: false,  // 悬浮球是否显示
                },
            },

            browser: {  // 浏览器状态
                visible: false,  // 浏览器是否显示
                width: 0,  // 浏览器宽度
                height: 0,  // 浏览器高度
                tabs: [],
                select_tab:0,  // 选中的tab索引
            },

            float:{
                visible: true,  // 悬浮球是否显示
            },

            // 徽章动态数据
            badge:{
                fish_catch: 0,  // 鱼数量
                online_time: 0,  // 在线时长
                chat_times: 0,  // 聊天次数
                fish_age: 0,  // 鱼龄
                badge_name: '初级帕鲁',  // 徽章名称
                sign_in_days: 0,  // 签到天数
            },


            admin:{ // 后台的数据，所有数据全都放到这里边
                user:{
                    username:'',
                    user_id:'',
                },
                menu_list: [  // 菜单列表
                    {
                        "id": 100,
                        "name": "仪表盘",
                        "routeName": "dashboard",
                        "icon": "dashboard",
                        "date": "2016-05-02",
                        "url": "/admin/dashboard",
                        "type": "router",
                        "children": [],
                    },
                    {
                        "id": 102,
                        "name": "用户管理",
                        "routeName": "users",
                        "icon": "people",
                        "date": "2016-05-02",
                        "url": "/users",
                        "type": "title",
                        "children": [
                            {
                                "id": 103,
                                "name": "用户数据",
                                "routeName": "user",
                                "icon": "id-card-v",
                                "date": "2016-05-02",
                                "url": "/admin/user",
                                "type": "router",
                            },
                            {
                                "id": 104,
                                "name": "亲爱的股东",
                                "routeName": "stockholder",
                                "icon": "people-safe-one",
                                "date": "2016-05-02",
                                "url": "/admin/stockholder",
                                "type": "router",
                            },
                            {
                                "id": 106,
                                "name": "用户头像",
                                "routeName": "userAvatar",
                                "icon": "me",
                                "date": "2016-05-02",
                                "url": "/admin/userAvatar",
                                "type": "router",
                            }
                        ]
                    },
                    {
                        "id": 107,
                        "name": "合规管理",
                        "routeName": "compliance",
                        "icon": "bill",
                        "date": "2016-05-02",
                        "url": "compliance",
                        "type": "title",
                        "children": [
                            {
                                "id": 108,
                                "name": "违规审核",
                                "routeName": "violationAudit",
                                "icon": "seal",
                                "date": "2016-05-02",
                                "url": "/admin/violationAudit",
                                "type": "router",
                            },
                            {
                                "id": 109,
                                "name": "封禁数据",
                                "routeName": "banned",
                                "icon": "link-interrupt",
                                "date": "2016-05-02",
                                "url": "/admin/banned",
                                "type": "router",
                            },
                            {
                                "id": 110,
                                "name": "敏感词管理",
                                "routeName": "ForbiddeWord",
                                "icon": "abnormal",
                                "date": "2016-05-02",
                                "url": "/admin/ForbiddeWord",
                                "type": "router",
                            }
                        ]
                    },
                    {
                        "id": 111,
                        "name": "聊天室管理",
                        "routeName": "room",
                        "icon": "every-user",
                        "date": "2016-05-02",
                        "url": "/room",
                        "type": "title",
                        "children": [
                            {
                                "id": 112,
                                "name": "聊天室列表",
                                "routeName": "rooms",
                                "icon": "list-one",
                                "date": "2016-05-02",
                                "url": "/admin/rooms",
                                "type": "router",
                            },
                            {
                                "id": 114,
                                "name": "聊天室头像",
                                "routeName": "roomAvatar",
                                "icon": "me",
                                "date": "2016-05-02",
                                "url": "/admin/roomAvatar",
                                "type": "router",
                            },
                        ]
                    },
                    {
                        "id": 116,
                        "name": "应用管理",
                        "routeName": "app",
                        "icon": "application-one",
                        "date": "2016-05-02",
                        "url": "/app",
                        "type": "title",
                        "children": [
                            {
                                "id": 117,
                                "name": "应用列表",
                                "routeName": "apps",
                                "icon": "application-two",
                                "date": "2016-05-02",
                                "url": "/admin/apps",
                                "type": "router",
                            },
                            {
                                "id": 118,
                                "name": "标签管理",
                                "routeName": "appTag",
                                "icon": "tag-one",
                                "date": "2016-05-02",
                                "url": "/admin/appTag",
                                "type": "router",
                            }
                        ]
                    },
                    {
                        "id": 120,
                        "name": "订单管理",
                        "routeName": "order",
                        "icon": "order",
                        "date": "2016-05-02",
                        "url": "/order",
                        "type": "title",
                        "children": [
                            {
                                "id": 121,
                                "name": "订单数据",
                                "routeName": "order",
                                "icon": "view-list",
                                "date": "2016-05-02",
                                "url": "/admin/order",
                                "type": "router",
                            }
                        ]
                    },
                    {
                        "id": 124,
                        "name": "机器人管理",
                        "routeName": "robot",
                        "icon": "robot-one",
                        "date": "2016-05-02",
                        "url": "/robot",
                        "type": "title",
                        "children": [
                            {
                                "id": 125,
                                "name": "机器人列表",
                                "routeName": "robots",
                                "icon": "robot",
                                "date": "2016-05-02",
                                "url": "/robots",
                                "type": "router",
                            },
                            {
                                "id": 126,
                                "name": "机器人审核",
                                "routeName": "robotExamine",
                                "icon": "seal",
                                "date": "2016-05-02",
                                "url": "/robotExamine",
                                "type": "router",
                            },
                            {
                                "id": 127,
                                "name": "机器人消息",
                                "routeName": "robotMessages",
                                "icon": "message-emoji",
                                "date": "2016-05-02",
                                "url": "/robotMessages",
                                "type": "router",
                            },
                        ]
                    },
                    {
                        "id": 128,
                        "name": "系统管理",
                        "routeName": "system",
                        "icon": "system",
                        "date": "2016-05-02",
                        "url": "/system",
                        "type": "title",
                        "children": [
                            {
                                "id": 129,
                                "name": "系统公告",
                                "routeName": "systemNotice",
                                "icon": "announcement",
                                "date": "2016-05-02",
                                "url": "/admin/systemNotice",
                                "type": "router",
                            },
                            {
                                "id": 130,
                                "name": "系统日志",
                                "routeName": "systemLog",
                                "icon": "log",
                                "date": "2016-05-02",
                                "url": "/admin/systemLog",
                                "type": "router",
                            },
                            {
                                "id": 131,
                                "name": "支付设置",
                                "routeName": "paySetting",
                                "icon": "swipe",
                                "date": "2016-05-02",
                                "url": "/admin/PaySetup",
                                "type": "router",
                            },
                            {
                                "id": 132,
                                "name": "入股设置",
                                "routeName": "stockholderSetting",
                                "icon": "thumbs-up",
                                "date": "2016-05-02",
                                "url": "/admin/stockholderSetting",
                                "type": "router",
                            },
                            {
                                "id": 133,
                                "name": "用户反馈",
                                "routeName": "feedback",
                                "icon": "communication",
                                "date": "2016-05-02",
                                "url": "/admin/feedback",
                                "type": "router",
                            },
                            {
                                "id": 135,
                                "name": "后台用户",
                                "routeName": "adminUser",
                                "icon": "personal-privacy",
                                "date": "2016-05-02",
                                "url": "/admin/adminUser",
                                "type": "router",
                            },
                        ]
                    }
                ]
            },

        }
    },
    getters: {},
    actions: {
        // socketio消息接收
        socket_message() {
            this.socket.on('messages', (data) => {
                // console.log(callback)
                // callback({ status: "ok" });
                if(data.room_id === this.select_room.room_id){
                    if(data.type === 'text' || data.type === 'file' || data.type === 'md'){
                        console.log(data.type)
                        if(this.user.username != data.username){
                            this.select_room.messages.push(data);
                        }
                    }else{
                        this.select_room.messages.push(data);
                    }
                }
            })
        },


        // 获取房间列表
        get_rooms(rooms) {
            let that = this;

            Axios.post('/api/v1/chats/getRoomList', {
                rooms: rooms,
            })
            .then(response => {
                // console.log(response)
                that.rooms = response.data;
            })
            .catch(error => {
                console.log(error)
            });
        },
        

        // 滚动条置底
        scroll_bottom() {
            let chat_box = document.getElementById('chat_box')
            if (chat_box.scrollHeight - chat_box.scrollTop - chat_box.clientHeight < 250) {
                // 当前滚动条距离底部小于250，触发置底
                setTimeout(() => {
                    chat_box.scrollTop = chat_box.scrollHeight;
                }, 100);
            }
        },


        // 获取房间应用列表
        getRoomApps(room_id) {
            let that = this;

            Axios.post('/api/v1/chats/getRoomApps', {
                room_id: room_id
            })
            .then(response => {
                // console.log(response)
                that.roomApps = response.data;
            })
            .catch(error => {
                console.log(error)
            });

        },

        // 请求徽章数据
        getBadgeData() {
            let that = this;

            Axios.post('/api/v1/chats/getBadgeData', {})
            .then(response => {
                // console.log(response)
                that.badgeData = response.data
            })
            .catch(error => {
                console.log(error)
            });
        },



        // 校验是不是群主
        isOwnerQuery(room_id) {
            let that = this;

            Axios.post('/api/v1/chats/checkOwner', {
                room_id: room_id
            })
            .then(response => {
                // console.log(response)
                that.isOwner = response.data;
            })
            .catch(error => {
                console.log(error)
            });

        },
        

        // 返回token
        getToken(){
            return localStorage.getItem('mychatToken')
        },


        // 浏览器指纹生成
        generateBrowserFingerprint() {
            const fingerprint = {};
        
            // 收集浏览器信息
            fingerprint.userAgent = navigator.userAgent;
            fingerprint.language = navigator.language;
            fingerprint.platform = navigator.platform;
            fingerprint.hardwareConcurrency = navigator.hardwareConcurrency;
            fingerprint.deviceMemory = navigator.deviceMemory;
        
            // 收集屏幕信息
            fingerprint.screenResolution = `${window.screen.width}x${window.screen.height}`;
            fingerprint.colorDepth = window.screen.colorDepth;
        
            // 收集时区信息
            fingerprint.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        
            // 收集WebGL信息
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            if (gl) {
                const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
                if (debugInfo) {
                    fingerprint.webglVendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
                    fingerprint.webglRenderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                }
            }
        
            // 收集字体信息
            fingerprint.fonts = [];
            const testText = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            const testFonts = ['Arial', 'Times New Roman', 'Courier New', 'Verdana', 'Georgia'];
            testFonts.forEach(font => {
                const span = document.createElement('span');
                span.style.fontFamily = font;
                span.textContent = testText;
                document.body.appendChild(span);
                const width = span.offsetWidth;
                document.body.removeChild(span);
                fingerprint.fonts.push({ font, width });
            });
        
            // 将指纹信息转换为字符串
            const fingerprintString = JSON.stringify(fingerprint);
        
            // 使用哈希函数生成唯一的指纹标识符
            function hashFingerprint(str) {
                let hash = 0;
                for (let i = 0; i < str.length; i++) {
                    const char = str.charCodeAt(i);
                    hash = (hash << 5) - hash + char;
                    hash |= 0; // 转换为32位整数
                }
                return hash.toString(16);
            }
        
            return hashFingerprint(fingerprintString);
        },

        // 时间格式转换2024-12-20T15:54:55.497Z => 2024-12-20 15:54:55
        formatDate(date) {
            if (!date) {
                return '';
            }
            const d = new Date(date);
            const year = d.getFullYear();
            const month = d.getMonth() + 1;
            const day = d.getDate();
            const hour = d.getHours();
            const minute = d.getMinutes();
            const second = d.getSeconds();
            return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
        },
    }
})