import { createRouter, createWebHistory } from 'vue-router';

// 路由配置
const routes = [
    {
        path: '/',
        name: 'index',
        meta: {
            title: '首页'
        },
        component: () => import('../components/index.vue'),
        children: [
            {
                path: 'chat/:id',
                name: 'chat',
                meta: {
                    title: '聊天室'
                },
                component: () => import('../components/chat/chat.vue')
            },
            {
                path: 'app',
                name: 'app',
                meta: {
                    title: '摸鱼应用'
                },
                component: () => import('../components/app/app.vue')
            },
            {
                path: 'AppContent/:id',
                name: 'AppContent',
                meta: {
                    title: '应用详情'
                },
                component: () => import('../components/app/content.vue')
            },
        ]
    },
    {
        path: '/login',
        name: 'login',
        meta: {
            title: '登录'
        },
        component: () => import('../components/login/login.vue'),
    },
    {
        path: '/admin/login',
        name: 'adminLogin',
        meta: {
            title: '登录'
        },
        component: () => import('../components/admin/page/login.vue')
    },
    {
        path: '/invite/:id',
        name: 'invite',
        meta: {
            title: '邀请链接'
        },
        component: () => import('../components/invite/invite.vue')
    },
    {
        path: '/outer',
        name: 'outer',
        meta: {
            title: '外部链接'
        },
        component: () => import('../components/outer/outer.vue')
    },
    {
        path: '/admin',
        name: 'admin',
        meta: {
            title: '后台管理'
        },
        component: () => import('../components/admin/admin.vue'),
        children: [
            {
                path: '/admin/dashboard',
                name: 'dashboard',
                meta: {
                    title: '看板'
                },
                component: () => import('../components/admin/page/dashboard.vue')
            },
            {
                path: '/admin/systemboard',
                name: 'systemboard',
                meta: {
                    title: '服务器信息看板'
                },
                component: () => import('../components/admin/page/systemboard.vue')
            },
            {
                path: '/admin/user',
                name: 'user',
                meta: {
                    title: '用户管理'
                },
                component: () => import('../components/admin/page/user.vue')
            },
            {
                path: '/admin/stockholder',
                name: 'stockholder',
                meta: {
                    title: '股东数据'
                },
                component: () => import('../components/admin/page/stockholder.vue')
            },
            {
                path: '/admin/badge',
                name: 'badge',
                meta: {
                    title: '徽章数据'
                },
                component: () => import('../components/admin/page/badge.vue')
            },
            {
                path: '/admin/userAvatar',
                name: 'userAvatar',
                meta: {
                    title: '用户头像'
                },
                component: () => import('../components/admin/page/userAvatar.vue')
            },
            {
                path: '/admin/violationAudit',
                name: 'violationAudit',
                meta: {
                    title: '聊天记录举报管理'
                },
                component: () => import('../components/admin/page/violationAudit.vue')
            },
            {
                path: '/admin/banned',
                name: 'banned',
                meta: {
                    title: '封禁数据'
                },
                component: () => import('../components/admin/page/banned.vue')
            },
            {
                path: '/admin/ForbiddeWord',
                name: 'ForbiddeWord',
                meta: {
                    title: '违禁词库'
                },
                component: () => import('../components/admin/page/ForbiddeWord.vue')
            },
            {
                path: '/admin/rooms',
                name: 'rooms',
                meta: {
                    title: '房间管理'
                },
                component: () => import('../components/admin/page/rooms.vue')
            },
            {
                path: '/admin/roomAvatar',
                name: 'roomAvatar',
                meta: {
                    title: '房间头像管理'
                },
                component: () => import('../components/admin/page/roomAvatar.vue')
            },
            {
                path: '/admin/apps',
                name: 'apps',
                meta: {
                    title: '应用管理'
                },
                component: () => import('../components/admin/page/apps.vue')
            },
            {
                path: '/admin/appTag',
                name: 'appTag',
                meta: {
                    title: '标签管理'
                },
                component: () => import('../components/admin/page/appTag.vue')
            },
            {
                path: '/admin/appKeywords',
                name: 'appKeywords',
                meta: {
                    title: '应用关键词热度'
                },
                component: () => import('../components/admin/page/appKeywords.vue')
            },
            {
                path: '/admin/order',
                name: 'order',
                meta: {
                    title: '订单管理'
                },
                component: () => import('../components/admin/page/order.vue')
            },
            {
                path: '/admin/systemNotice',
                name: 'systemNotice',
                meta: {
                    title: '系统公告'
                },
                component: () => import('../components/admin/page/systemNotice.vue')
            },
            {
                path: '/admin/systemLog',
                name: 'systemLog',
                meta: {
                    title: '系统日志'
                },
                component: () => import('../components/admin/page/systemLog.vue')
            },
            {
                path: '/admin/PaySetup',
                name: 'PaySetup',
                meta: {
                    title: '支付设置'
                },
                component: () => import('../components/admin/page/PaySetup.vue')
            },
            {
                path: '/admin/stockholderSetting',
                name: 'stockholderSetting',
                meta: {
                    title: '股东设置'
                },
                component: () => import('../components/admin/page/stockholderSetting.vue')
            },
            {
                path: '/admin/feedback',
                name: 'feedback',
                meta: {
                    title: '反馈管理'
                },
                component: () => import('../components/admin/page/feedback.vue')
            },
            {
                path: '/admin/channelLink',
                name: 'channelLink',
                meta: {
                    title: '渠道链接'
                },
                component: () => import('../components/admin/page/channelLink.vue')
            },
            {
                path: '/admin/adminUser',
                name: 'adminUser',
                meta: {
                    title: '管理员管理'
                },
                component: () => import('../components/admin/page/adminUser.vue')
            },
        ]
    },
    {
        path: '/:pathMatch(.*)*',
        name: 'notFound',
        meta: {
            title: '页面未找到'
        },
        component: () => import('../components/notFound.vue')
    }

];

// 创建路由实例
const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL), // 需要根据实际情况选择使用 History 或 Hash 模式
    routes
});

export default router;
