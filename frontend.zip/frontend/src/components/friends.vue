<script setup>
import { reactive } from 'vue'
import { IconPark } from '@icon-park/vue-next/es/all';
import '@imengyu/vue3-context-menu/lib/vue3-context-menu.css'
import { ContextMenu } from '@imengyu/vue3-context-menu';
import { useMainStore } from "../store/index";
import { useRoute, useRouter } from 'vue-router';
import Axios from '../../utils/request';
const stores = useMainStore();
const data = reactive({
    banner:[
        {img:'https://img.zyy.muo.cc/element_icon/liuliangka_chang.png',src:'https://haokawx.lot-ml.com/Product/Index/229080'},
        {img:'https://img.zyy.muo.cc/element_icon/ailunwen.png',src:'https://wen.zhuayuya.com/'},
    ],
    left:'left:0px',
    arr:0,


    // 创建房间表单
    create_room_visible:false,
    create_room:{
        avatar:'3f8447cadc5695cc1fe0f5d02.jpg',
        name:'',
        desc:''
    },

    // 添加房间表单
    add_room_visible:false,
    add_room:{
        keyword:'',
        list:[]
    },

    // 添加应用表单
    add_app_visible:false,
    add_app_getInfo_loding:false,
    add_app:{
        title:'',
        desc:'',
        url:''
    },


    show:false,
    optionsComponent: {
        room_id: '',
        zIndex: 3,
        minWidth: 160,
        x: 10,
        y: 10
    },


})

const Route = useRoute();
const Router = useRouter();

//banner轮播
let timer_ = setInterval(() => {
    if(data.arr == -238){
        data.arr = 0
        data.left = 'left:'+data.arr+'px'
    }else{
        data.arr = data.arr-238
        data.left = 'left:'+data.arr+'px'
    }
    
}, 10000);

// 创建房间
function createRoom(){

    Axios.post('/api/v1/chats/createRoom', {
        avatar: data.create_room.avatar,
        name: data.create_room.name,
        desc: data.create_room.desc
    })
    .then(response => {
        // console.log(response)
        // 房间列表
        window.location.href = '/chat/'+response.data.newRoom.room_id;
    })
    .catch(error => {
        console.log(error)
        ElMessage.error(error.response.data.message)
    });

}


// 选择切换房间
function selectRoom(room_id, index){
    if(room_id != Route.params.id){
        stores.select_room = {
            room_id: room_id,
            index: index,
            messages: []
        }
        Router.push({path:'/chat/'+room_id})
    }
}


// 搜索房间
function searchRoom(){
    Axios.post('/api/v1/chats/searchRoom', {
        keyword: data.add_room.keyword
    })
    .then(response => {
        data.add_room.list = response.data
    })
    .catch(error => {
        console.log(error)
        ElMessage.error(error.response.data.message)
    });
}


// 加入房间
function joinRoom(room_id){

    Axios.post('/api/v1/chats/joinRoom', {
        room_id: room_id,
    })
    .then(response => {
        // console.log(response)
        // 房间列表
        window.location.href = '/chat/'+room_id;
    })
    .catch(error => {
        console.log(error)
        ElMessage.error(error.response.data.message)
    });

}

// 打开房间
function openRoom(room_id){
    window.location.href = '/chat/'+room_id;
}
// 获取任意网站的title和description
function getTitleAndDesc(){
    ElMessage.info('自动获取中，长时间未返回结果是获取失败...')
    data.add_app_getInfo_loding = true

    Axios.post('/api/v1/chatApps/getWebsiteInfo', {
        url: data.add_app.url
    })
    .then(response => {
        data.add_app.title = response.data.title
        data.add_app.desc = response.data.description
        data.add_app_getInfo_loding = false
        ElMessage.success('获取成功 QaQ ~')
    })
    .catch(error => {
        console.log(error)
        ElMessage.error(error.response.data.message)
    });

}


// 添加应用
function addApp(){
    // 表单校验
    if(!data.add_app.url){
        ElMessage.error('请输入应用地址')
        return
    }
    try{
        new URL(data.add_app.url)
    }
    catch(err){
        ElMessage.error('请输入正确的网址')
        return
    }
    if(!data.add_app.title){
        ElMessage.error('请输入应用名称')
        return
    }
    if(!data.add_app.desc){
        ElMessage.error('请输入应用描述')
        return
    }


    Axios.post('/api/v1/chatApps/addChatApp', {
        title: data.add_app.title,
        desc: data.add_app.desc,
        url: data.add_app.url,
        type: "web",
        source: new URL(data.add_app.url).hostname  // 获取网址的一级域名
    })
    .then(response => {
        ElMessage.success('添加成功 QaQ ~')
        data.add_app_visible = false
    })
    .catch(error => {
        console.log(error)
        ElMessage.error(error.response.data.message)
    });

}


// 右击事件
function showMenu(event, room_id){
    event.preventDefault()
    if(room_id != '666666'){
        data.show = true
        data.optionsComponent.x = event.clientX
        data.optionsComponent.y = event.clientY
        data.optionsComponent.room_id = room_id
    }
}

// 退出房间
function exitRoom() {
    Axios.post('/api/v1/chats/quitRoom', {
        room_id: data.optionsComponent.room_id
    })
    .then(response => {
        Router.push({ path: '/' });
        setTimeout(() => {
            window.location.reload();
        }, 50);
    })
    .catch(error => {
        console.log(error)
        ElMessage.error(error.response.data.message)
    });

}


// banner点击
function banner_click(e){
    window.open(data.banner[e].src)
}

</script>

<template>
    <!-- 创建房间弹窗 -->
    <el-dialog title="创建房间" v-model="data.create_room_visible" width="500">
        <el-form ref="form" :model="data.create_room" label-width="80px">

            <el-form-item label="房间头像">
                <el-upload
                    class="avatar-uploader"
                    :action="stores.config.port + '/api/v1/chats/uploadGroupAvatar'"
                    :headers="{'Authorization': 'Bearer '+stores.getToken()}"
                    
                    :show-file-list="false"
                    :on-success="(res, file) => {
                        data.create_room.avatar = res.data.file.newFilename
                    }"
                >
                    <img v-if="data.create_room.avatar" :src="stores.config.port + '/group/'+data.create_room.avatar" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
            </el-form-item>

            <el-form-item label="房间名称">
                <el-input v-model="data.create_room.name" placeholder="请输入房间名称"></el-input>
            </el-form-item>

            <el-form-item label="简介">
                <el-input v-model="data.create_room.desc" placeholder="请输入简介"></el-input>
            </el-form-item>

            <el-button type="primary" @click="createRoom">创建</el-button>
        </el-form>
    </el-dialog>


    <!-- 添加房间弹窗 -->
    <el-dialog title="加入房间" v-model="data.add_room_visible" style="width: 800px; height: 500px;">
        <el-form ref="form" :model="data.add_room">
            <el-form-item label="搜索房间">
                <div style="display: flex;">
                    <el-input v-model="data.add_room.keyword" placeholder="请输入房间名称"></el-input>
                    <el-button style="margin-left: 6px;" type="primary" @click="searchRoom">搜索</el-button>
                </div>
                
            </el-form-item>
            
            <!-- 房间列表 -->
             <div class="app-list-container">
                <el-empty v-if="data.add_room.list.length === 0" description="暂无搜索结果" />
                <ul v-if="data.add_room.list.length > 0" class="app-list grid">
                    <li v-for="(item, index) in data.add_room.list" :key="index">
                        <div class="app-item">
                            <div class="app-item-content">
                                <img class="app-item-icon" :src="stores.config.port + '/group/'+item.avatar" alt="">
                                <h2>{{ item.name }}</h2>
                                <p>{{ item.desc }}</p>
                                
                                <!-- 互动按钮 -->
                                <div class="app-item-btn">
                                    <div class="app-item-btn-left">
                                        <div>成员：{{ item.users.length }}</div>
                                    </div>
                                    <div>
                                        <span @click="joinRoom(item.room_id)" v-if="item.exist === 0">加入房间</span>
                                        <span @click="openRoom(item.room_id)" v-if="item.exist === 1">打开房间</span>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </li>
                </ul>
             </div>
             
        </el-form>
    </el-dialog>
    


    <!-- 添加应用 -->
     <el-dialog title="添加应用" v-model="data.add_app_visible" width="500">
        <el-form ref="form" :model="data.add_app" label-width="80px">

            <el-form-item label="应用logo" required>
                <img style="width: 50px; height: 50px; margin-bottom: 10px;" :src="'https://icon.bqb.cool?url='+data.add_app.url" alt="">
            </el-form-item>
            
            <el-form-item label="应用地址" required>
                <el-input v-model="data.add_app.url" placeholder="请输入应用地址"></el-input>
            </el-form-item>
            
            <el-form-item label="自动获取">
                <el-button type="primary" link :loading="data.add_app_getInfo_loding" @click="getTitleAndDesc">点我自动获取应用名称和描述</el-button>
            </el-form-item>
            

            <el-form-item label="应用名称" required>
                <el-input v-model="data.add_app.title" placeholder="请输入应用名称"></el-input>
            </el-form-item>

            <el-form-item label="应用描述" required>
                <el-input v-model="data.add_app.desc" placeholder="请输入应用描述"></el-input>
            </el-form-item>

            <el-button type="primary" @click="addApp">添加</el-button>
            
        </el-form>
     </el-dialog>

    <div class="friends-box">
        <!-- banner -->
        <div class="banner-box">
            <div class="banner-inside" :style="data.left">
                <div @click="banner_click(0)" class="banner-item">
                    <img :src="data.banner[0].img" alt="">
                </div>
                <div @click="banner_click(1)" class="banner-item">
                    <img :src="data.banner[1].img" alt="">
                </div>
            </div>
        </div>

        <!-- 添加或创建房间 -->
        <ul class="add-room">
            <li @click="data.add_room_visible = true">
                <icon-park type="four-round-point-connection" size="20" fill="#949ba4"/>
                <span>加入房间</span>
            </li>

            <li @click="data.create_room_visible = true">
                <icon-park type="newlybuild" size="20" fill="#949ba4"/>
                <span>创建房间</span>
            </li>

            <li @click="data.add_app_visible = true">
                <icon-park type="application-one" size="20" fill="#949ba4"/>
                <span>添加应用</span>
            </li>
        </ul>

        <!-- 房间列表 -->
        <ul class="room-list">

            <!-- 右击事件 -->
            <li 
                @contextmenu="showMenu($event, item.room_id)" 
                class="room-item" v-for="(item, index) in stores.rooms" 
                :key="index" :class="{'active':item.room_id === Route.params.id}" 
                @click="selectRoom(item.room_id, index)"
            >
                <img :src="stores.config.port + '/group/'+item.avatar" alt="">
                <div class="room-info">
                    <h3>{{ item.name }}</h3>
                    <!-- 渲染最后一条消息 -->
                    <p>{{ item.desc || '暂无简介' }}</p>
                </div>
                <!-- <div class="room-status">
                    <i></i>
                    <p>1000</p>
                </div> -->
            </li>
        </ul>

        <!-- 右击菜单 -->
        <context-menu
            v-model:show="data.show"
            :options="data.optionsComponent"
        >
            <!-- <context-menu-item label="Simple item" /> -->
            <div @click="exitRoom" class="room-menu">
                <span>退出房间</span>
            </div>
        </context-menu>
        

        <!-- 底部个人信息 -->
         <div @click="stores.drawer.visible = true" class="user-info">
            <img :src="stores.config.port + '/api/v1/users/getUserAvatar/'+stores.user.username" alt="">

            <div class="user-info-inside">
                <h3>{{stores.user.nickname}}</h3>
                <p>{{ stores.user.signature || '来去匆匆，什么都没留下' }}</p>
            </div>

            <icon-park type="setting-two" size="20" />
         </div>
    </div>
</template>

<style scoped>
.room-menu{
    width: 86%;
    margin: 0 auto;
    border-radius: 5px;
    height: 34px;
    text-align: center;
    line-height: 34px;
    background: #fff;
    cursor: pointer;
    font-size: 14px;
    color: #333;
}
.room-menu:hover{
    background: #f2f3f5;
}
.app-item-btn span{
    font-size: 13px;
    color: #b5bac1;
    padding: 6px 12px;
    background: #2a2a2a;
    margin-left: 10px;
    border-radius: 3px;
    cursor: pointer;
}
.app-item-btn span:hover{
    background: #4a4a4a;
}
.app-item-btn-left div{
    font-size: 15px;
    color: #b5bac1;
    margin-top: 3px;
}
.app-item-btn-left{
    display: flex;
    align-items: center;
}
.app-item-btn i{
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    margin-right: 5px;
    border-radius: 5px;
    /* filter: brightness(.2); */
    /* opacity: .2; */
    transition: all .3s ease;
}
.app-item-btn i:hover{
    filter: brightness(1);
    opacity: 1;
}
.app-item-btn img{
    width: 22px;
}
.app-item-btn{
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 18px;
}
.app-item-icon{
    width: 40px;
    height: 40px;
    border-radius: 13px;
    border: 5px solid #232428;
    margin-top: -22px;
}
.app-item-content{
    width: 88%;
    margin: 0 auto;
}
.app-item{
    width: 100%;
    height: 168px;
    background: #232428;
    border-radius: 10px;
    cursor: pointer;
    transition: all .2s ease;
}
.app-item:hover{
    background: #1f2024;
    box-shadow:  0 5px 6px rgba(0,0,0,0.2);
    transform: translateY(-1.5px);
}
.app-list li{
    position: relative;
    width: 100%;
    height: 188px;
    /* background: #232428; */
    border-radius: 10px;
    display: flex;
    align-items: flex-end;
}
.app-list {
    /* background: #10e353; */
    margin-top: -16px;
}
.app-list-container{
    height: 380px;
    padding-top: 5px;
    overflow: auto;
}
.grid p{
    text-overflow: ellipsis;
    height: 42px;
    overflow: hidden;
    margin: 4px 0 16px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 400px;
    color: #b5bac1;
}
.grid h2{
    font-size: 16px;
    line-height: 1.2;
    font-weight: 600;
    color: #f2f3f5;
    margin-top: 3px;
    margin-bottom: 6px;
    /* 超出一行省略号 */
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}
.grid{
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    grid-column-gap: 16px;
    -moz-column-gap: 16px;
    column-gap: 16px;
    grid-row-gap: 16px;
    row-gap: 16px;
    padding: 16px 2px;
}


.avatar{
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 50%;
}
.user-info span{
    margin-right: 12px;
    cursor: pointer;
    color: #9a9a9a;
}
.user-info span:hover{
    color: #333;
}
.user-info p{
    font-size: 13px;
    margin-top: 6px;
    color: #9a9a9a;
}
.user-info h3{
    width: 150px;
    height: 20px;
    font-size: 16px;
    color: #333;
    /* 超出省略号 */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.user-info img{
    width: 38px;
    height: 38px;
    border-radius: 8px;
    object-fit: cover;
    margin-left: 10px;
    margin-right: 10px;
}
.user-info-inside{
    width: 100%;
}
.user-info{
    position: absolute;
    bottom: 0px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 58px;
    width: 100%;
    background: #ffffff;
    border-top: 1px solid #e8e8e8;
}
.room-status p{
    font-size: 12px;
    margin-top: 6px;
    color: #10e353;
}
.room-status i{
    display: block;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #27c459;
    margin: 0 auto;
}
.room-status{
    margin-left: 5px;
    margin-right: 5px;
    text-align: center;
}
.room-info p{
    width: 168px;
    font-size: 13px;
    color: #9a9a9a;
    margin-top: 8px;
    /* 超出省略号 */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.room-info h3{
    font-size: 16px;
    color: #333;
}
.room-info{
    width: 100%;
    margin-left: 10px;
}
.room-list li img{
    width: 50px;
    height: 50px;
    border-radius: 10px;
    object-fit: cover;
    margin-left: 10px;
}
.room-list li{
    height: 76px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #e8e8e8;
    cursor: pointer;
    background: #ffffff;
    transition: all .2s ease;
}
.active{
    background: #f8f8f8 !important;
}
.room-list li:hover{
    background: #f8f8f8;
}
.room-list{
    height: calc(100vh - 280px);
    overflow: auto;
}
.add-room span{
    margin-left: 10px;
    color: #333;
    font-size: 15px;
}
.add-room li{
    height: 48px;
    display: flex;
    align-items: center;
    background: #ffffff;
    cursor: pointer;
}
.add-room li:hover{
    background: #f1f1f1;
}
.add-room{
    height: 144px;
    background: #f7f7f7;
    border-bottom: 1px solid #e8e8e8;
    /* box-shadow: 0px 1px 3px rgba(0, 0, 0, .25); */
}
/* banner */
.banner-item{
    display: inline-block;
    width: 238px;
    height: 88px;
    background: #E3FAFF;
    margin: 0 auto;
    border-radius: 8px;
    flex-shrink: 0;
    /* overflow: auto; */
}
.banner-item img{
    width: 238px;
    height: 88px;
    /* border-radius: 8px; */
    object-fit: cover;
}
.banner-inside{
    display: flex;
    position: relative;
    transition: all 0.3s;
    /* 过度 */
    -moz-transition: all 0.3s;
    /* Firefox */
    -webkit-transition: all 0.3s;
    /* Safari 和 Chrome */
}
.banner-box{
    width: 238px;
    margin: 0 auto;
    overflow-x: scroll;
    cursor: pointer;
    box-shadow: 0px 10px 5px #02171d0d;
    overflow: hidden;
}
.friends-box{
    position: relative;
    width: 100%;
    height: 100%;
}
</style>