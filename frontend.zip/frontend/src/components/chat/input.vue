<script setup>
import { reactive, ref, onMounted } from 'vue';
import { IconPark } from '@icon-park/vue-next/es/all';
import Axios from '../../../utils/request';
import { useRoute } from 'vue-router';
import { marked } from 'marked';
import { useMainStore } from "../../store/index";

const stores = useMainStore();
const data = reactive({
    msg: '',
    bqb:{
        visible: true,
        select_bqb: 0,
        menu:[],
        bqb_list:[]
    },

    select_app: 0,
    apps:[],

    msgType: 'text',

    command:{
        visible: false,
        select: 0,
        select_text: '斜杠命令',
        list: [
            {
                name: '发送 Markdown 消息',
                type: 'md',
                value: 'markdown'
            },
            {
                name: '普通消息',
                type: 'text',
                value: '斜杠命令'
            },
            {
                name: '发红包',
                type: 'redpack',
                value: '发红包'
            },
            {
                name: '发文件',
                type: 'file',
                value: '发文件'
            }
        ]
    },


})

const route = useRoute();



// 发送text/md消息和斜杠命令拦截
let isSending = false;   // 防止重复发送
function sendMsg(event) {
    event.preventDefault();
    if(data.command.list[data.command.select].type === 'redpack'){
        ElMessage({
            message: '红包功能暂未开放',
            type: 'info',
        })
        return;
    }

    if(data.command.list[data.command.select].type === 'file'){
        data.command.visible = false;
        data.msg = ''
        uploadFile();
        return;
    }

    // 斜杠命令
    if(data.command.visible){
        data.msgType = data.command.list[data.command.select].type;
        data.command.select_text = data.command.list[data.command.select].value;
        data.command.visible = false;
        data.msg = ''
        return;
    }

    if(data.msgType === 'md'){
        data.msg = marked(data.msg);
        // console.log(data.msg);
    }


    // 判断空字符或者只有空格
    if(!data.msg||data.msg.trim().length === 0){
        ElMessage({
            message: '还没有输入消息哦~',
            type: 'error',
        })
        return;
    }


    // 如果正在发送消息，直接返回，限制 1 秒内只能发送一次
    if (isSending) {
        ElMessage({
            message: '摸友，莫要刷屏~',
            type: 'info',
        });
        return;
    }

    // 设置正在发送的标志
    isSending = true;
    let msg_data = {
        msg_id: '',
        user_id: stores.user.user_id,
        username: stores.user.username,
        room_id: route.params.id,
        nickname: stores.user.nickname,
        ymsg: data.msg,
        msg: data.msg,
        type: data.msgType,
        status: 1,
        source: "web",
        interact: [],
        ip: ''
    }
    stores.select_room.messages.push(msg_data);

    Axios.post('/api/v1/chats/sendMessage', {
        room_id: route.params.id,
        nickname: stores.user.nickname,
        source: "web",
        msg: data.msg,
        type: data.msgType
    })
    .then(response => {
        stores.select_room.messages[stores.select_room.messages.length - 1].msg_id = response.data.msg_id;
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

    data.msg = '';
    // 1秒后恢复发送标志为false，允许再次发送
    setTimeout(() => {
        isSending = false;
    }, 1500);
}




// 发送文件消息
function uploadFile() {
    // console.log('上传文件');
    const input = document.createElement('input');
    input.type = 'file';
    input.onchange = e => {
        const file = e.target.files[0];
        // 超过10m的文件不允许上传
        if(file.size > 10 * 1024 * 1024){
            ElMessage({
                message: '文件大小不能超过10M',
                type: 'error',
            })
            return;
        }


        // console.log(file, '上传文件');
        // 获取图片临时本地连接
        const url = URL.createObjectURL(file);

        let msg_data = {
            msg_id: '',
            user_id: stores.user.user_id,
            username: stores.user.username,
            room_id: route.params.id,
            nickname: stores.user.nickname,
            type: 'file',
            json_msg: {
                file_name: file.name,
                file_url: url,  // 转base64
                size: file.size,
                format: file.type,
            },
            status: 1,
            source: "web",
            interact: [],
            ip: ''
        }
        stores.select_room.messages.push(msg_data);

        const form = new FormData();
        form.append('file', file);
        form.append('room_id', route.params.id);
        form.append('nickname', stores.user.nickname);
        form.append('source', 'web');

        console.log(form)

        Axios.post('/api/v1/chats/sendFile', form, {
            'Content-Type': 'multipart/form-data',
        })
        .then(response => {
            // console.log(response.data)
            ElMessage({
                message: '文件发送成功',
                type:'success',
            })

            stores.select_room.messages[stores.select_room.messages.length - 1].msg_id = response.data.msg_id;
            stores.select_room.messages[stores.select_room.messages.length - 1].json_msg = response.data.json_msg;
        })
        .catch(error => {
            console.log(error)
            ElMessage({
                message: '上传失败',
                type: 'error',
            })
        });
        
    };
    input.click();
}


// 发送表情消息
const popoverRef = ref(null);
function sendBqb(emoticon_id) {
    popoverRef.value.hide();
    Axios.post('/api/v1/chats/sendEmoticon', {
        room_id: route.params.id,
        nickname: stores.user.nickname,
        source: "web",
        emoticon_id: emoticon_id
    })
    .catch(error => {
        ElMessage({
            message: '发送失败',
            type: 'error',
        })
        console.log(error);
    });

}


// 处理鼠标滚轮事件
const scrollableRef = ref(null); // 滚动容器的 ref
const handleWheel = (event) => {
  if (scrollableRef.value) {
    event.preventDefault(); // 防止默认的垂直滚动
    // 根据鼠标滚轮的方向调整 scrollLeft
    scrollableRef.value.scrollLeft += event.deltaY; // deltaY 表示垂直滚动的距离
  }
};


// 请求表情分组数据
function getEmojiCategory() {

    Axios.post('/api/v1/chats/getEmojiCategory', {})
    .then(response => {
        data.bqb.menu = response.data;
    })
    .catch(error => {
        console.log(error)
        ElMessage({
            message: '请求失败',
            type: 'error',
        })
    });

}

onMounted(() => {
    // 延迟两秒请求表情分组数据
    if(data.bqb.menu.length === 0){
        setTimeout(() => {
            getEmojiCategory()
        }, 2000);
    }
})


// 请求表情包
function getEmoji(category_name) {
    data.bqb.visible = false;

    Axios.post('/api/v1/chats/getEmoji', {
        category_name: category_name
    })
    .then(response => {
        // console.log(response)
        data.bqb.bqb_list = response.data;
        data.bqb.visible = true;
    })
    .catch(error => {
        console.log(error)
        ElMessage({
            message: '表情包请求失败',
            type: 'error',
        })
    });

}


// 滚动条横向滚动
const scrollableRefApp = ref(null); // 滚动容器的 ref
const handleWheelApp = (event) => {
    if (scrollableRefApp.value) {
    event.preventDefault(); // 防止默认的垂直滚动
    // 根据鼠标滚轮的方向调整 scrollLeft
    scrollableRefApp.value.scrollLeft += event.deltaY; // deltaY 表示垂直滚动的距离
  }
};


// 请求应用数据
function getApps() {

    Axios.post('/api/v1/chatApps/getApp', {})
    .then(response => {
        data.apps = response.data;
    })
    .catch(error => {
        console.log(error)
        ElMessage({
            message: '应用请求失败',
            type: 'error',
        })
    });

}

// 输入框输入内容
function msgChange() {
    // console.log(data.msg);
    if(data.msg === '/'){
        data.command.visible = true;
    }else{
        data.command.visible = false;
    }
}


// 监听上下键
function inputKeydown(event) {
    if (event.keyCode === 38) { // 上键
        event.preventDefault();
        // console.log('上键');
        data.command.select = (data.command.select - 1 + data.command.list.length) % data.command.list.length;
    } else if (event.keyCode === 40) { // 下键
        // console.log('下键');
        event.preventDefault();
        data.command.select = (data.command.select + 1) % data.command.list.length;
    }
}



// 添加应用到房间
function addApp(app_id) {
    
    Axios.post('/api/v1/chats/addAppToRoom', {
        room_id: route.params.id,
        app_id: app_id
    })
    .then(response => {
        stores.getRoomApps(route.params.id);
        ElMessage({
            message: '应用添加成功',
            type:'success',
        })
    })
    .catch(error => {
        console.log(error);
        ElMessage({
            message: err.response.data.message,
            type: 'error',
        })
    });

}


// 粘贴图片上传
function handlePaste(event) {
    const items = (event.clipboardData || event.originalEvent.clipboardData).items;
    for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
            const file = items[i].getAsFile();
            // 超过10m的文件不允许上传
            if(file.size > 10 * 1024 * 1024){
                ElMessage({
                    message: '文件大小不能超过10M',
                    type: 'error',
                })
                return;
            }

            const form = new FormData();
            form.append('file', file);
            form.append('room_id', route.params.id);
            form.append('nickname', stores.user.nickname);
            form.append('source', 'web');

            Axios.post('/api/v1/chats/sendCustomImage', form, {
                'Content-Type':'multipart/form-data',
            })
            .then(response => {
                ElMessage({
                    message: '图片发送成功',
                    type:'success',
                })

                // stores.select_room.messages[stores.select_room.messages.length - 1].msg_id = response.data.msg_id;
                // stores.select_room.messages[stores.select_room.messages.length - 1].json_msg = response.data.json_msg;
            })
            .catch(error => {
                console.log(error);
                ElMessage({
                    message: err.response.data.message,
                    type: 'error',
                })
            });

        }
    }
}


// 应用消息发送
const popoverRefApp = ref(null);
function sendAppMsg(app_id) {

    Axios.post('/api/v1/chats/sendAppMessage', {
        room_id: route.params.id,
        app_id: app_id,
        nickname: stores.user.nickname,
        source: "web",
    })
    .then(response => {
        popoverRefApp.value.hide();
    })
    .catch(error => {
        console.log(error);
        ElMessage({
            message: 'APP消息发送失败',
            type: 'error',
        })
    });

}


// 开玩
function startPlay(item) {
    popoverRefApp.value.hide();
    // console.log('play'+item);
    stores.browser.tabs.push({
        title: item.title,
        desc: item.desc,
        url: item.url
    })
    stores.browser.visible = true
}


// 点击命令
function commandClick(item, index) {
    if(item.type != 'redpack'){
        data.command.select = index
        data.msgType = item.type
        data.command.select_text = item.value
        data.msg = ''
        data.command.visible = false
    }else{
        ElMessage({
            message: '红包功能暂未开放',
            type: 'info',
        })
    }
}

</script>

<template>
<div class="chat-input">

    <div class="chat-input-top">
        <div class="chat-input-left">
            
            <!-- 表情包 -->
            <el-popover
                ref="popoverRef"
                placement="top-start"
                :width="380"
                trigger="click"
                :hide-after="0"
            >
                <template #reference>
                    <icon-park @click="getEmoji(data.bqb.menu[data.bqb.select_bqb].category)" type="grinning-face-with-tightly-closed-eyes" size="20" />
                </template>

                <template #default>
                    <div style="height: 300px;">
                        <ul class="chat-emoji-list">
                            <div v-if="data.bqb.visible" class="chat-emoji-list-container">
                                <li @click="sendBqb(item.emoticon_id)" v-for="(item, index) in data.bqb.bqb_list" :key="index">
                                    <img :src="'https://mychat.bqb.zhuayuya.com'+item.url" alt="">
                                </li>
                            </div>
                        </ul>

                        <div @wheel="handleWheel" ref="scrollableRef" class="chat-emoji-menu">
                            <span
                                v-for="(item, index) in data.bqb.menu"
                                :class="{'chat-emoji-menu-active': index === data.bqb.select_bqb}"
                                @click="() => {
                                    data.bqb.select_bqb = index
                                    getEmoji(item.category)
                                }"
                                :key="index"
                            >
                                {{ item.category }}
                            </span>
                        </div>
                    </div>
                </template>
            </el-popover>

            <!-- 应用 -->
            <el-popover
                placement="top-start"
                :width="500"
                trigger="click"
                :hide-after="0"
                ref="popoverRefApp"
            >
                <template #reference>
                    <icon-park @click="() => {
                        if(data.apps.length === 0){
                            getApps()
                        }
                        if(stores.roomApps.length === 0){
                            // console.log(stores.roomApps);
                            stores.getRoomApps(route.params.id);
                        }
                    }" type="application-one" size="20" />
                </template>

                <template #default>
                    <div style="height: 380px;">
                        <!-- <div class="app-input">
                            <input type="text" class="form-control" placeholder="搜索应用" aria-label="Recipient's username" aria-describedby="button-addon2">
                            <el-icon class="el-icon-search"><Search /></el-icon>
                        </div> -->

                        <div class="apps-box">
                            <h3>房间内应用</h3>
                            <ul v-if="stores.roomApps.length > 0" class="no-apps">
                                <li v-for="(item, index) in stores.roomApps" :key="index">
                                    <img v-if="item.icon === ''" :src="'https://icon.bqb.cool?url='+item.url" alt="">
                                    <img v-else :src="stores.config.port + '/app/'+item.icon" alt="">
                                    <div class="app-info">
                                        <h1>{{ item.title }}</h1>
                                        <p>{{item.desc}}</p>
                                    </div>
                                    <div class="app-btn">
                                        <div @click="startPlay(item)">开玩</div>
                                        <span @click="sendAppMsg(item.app_id)">发送到聊天</span>
                                    </div>
                                </li>
                            </ul>

                            <h3>推荐应用</h3>
                            <div ref="scrollableRefApp" @wheel="handleWheelApp" class="apps-tabs">
                                <span v-for="(item, index) in data.apps" :class="{'apps-tabs-active': index === data.select_app}" @click="data.select_app = index" :key="index">{{ item.tag }}</span>
                            </div>
                            <ul v-if="data.apps.length > 0">
                                <li v-for="(item, index) in data.apps[data.select_app].apps" :key="index">
                                    <img v-if="item.icon === ''" :src="'https://icon.bqb.cool?url='+item.url" alt="">
                                    <img v-else :src="stores.config.port + '/app/'+item.icon" alt="">
                                    
                                    <div @click="addApp(item.app_id)" v-if="stores.isOwner" class="position-relative">
                                        应用添加到房间
                                    </div>

                                    <div class="app-info">
                                        <h1>{{ item.title }}</h1>
                                        <p>{{item.desc}}</p>
                                    </div>
                                    <div class="app-btn">
                                        <div @click="startPlay(item)">开玩</div>
                                        <span @click="sendAppMsg(item.app_id)">发送到聊天</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </template>
            </el-popover>


            <!-- /斜杠命令 -->
            <el-popover
                placement="top"
                :width="300"
                trigger="click"
                :hide-after="0"
                :visible="data.command.visible"
            >
                <template #reference>
                    <p @click="data.command.visible = !data.command.visible" class="chat-input-slash">/ {{data.command.select_text}}</p>
                </template>

                <template #default>
                    <div class="chat-command">
                        <p v-for="(item, index) in data.command.list" :class="{'chat-command-active': index === data.command.select}" @click="commandClick(item, index)" :key="index">{{ item.name }}</p>
                    </div>
                </template>
            </el-popover>


            <!-- 成就 -->
            <div @click="stores.drawer.visible = true" class="chat-input-achievement">
                <div class="chat-input-achievement-icon">
                    <icon-park type="medal-one" size="20" />
                    <p>摸鱼成就</p>
                </div>
                <i class="user-badge">{{stores.badge.badge_name}}</i>
            </div>
        </div>

        <span @click="sendMsg" class="send-btn">发送</span>
    </div>

    <div class="chat-input-textarea">
        <textarea @input="msgChange" @keydown.enter="sendMsg" @keydown="inputKeydown" @paste="handlePaste" v-model="data.msg" v-if="stores.user.username !== ''" placeholder="请输入消息"></textarea>
        <div v-if="stores.user.username === ''" @click="stores.login.visible = true" class="chat-input-nologin">
            登录后开始摸鱼
        </div>
    </div>

</div>
</template>
<style scoped>
.position-relative{
    position: absolute;
    top: 0;
    height: 68px;
    width: 60%;
    background: rgba(0, 0, 0, .5);
    border-radius: 10px 0px 0px 10px;
    display: none;
    color: #fff;
    font-size: 18px;
    text-align: center;
    line-height: 68px;
    cursor: pointer;
}
.apps-box li:hover .position-relative{
    display: block;
}
.chat-command p{
    height: 36px;
    line-height: 36px;
    padding-left: 10px;
    cursor: pointer;
    border-radius: 3px;
    font-size: 14px;
}
.chat-command p:hover{
    background: #eeeeee;
    color: #3d3d3d;
}
.chat-command-active{
    background: #f1f1f1;
    color: #3d3d3d;
}
.chat-input-slash{
    text-align: center;
    font-size: 15px;
    color: #333 !important;
    cursor: pointer;
    padding: 3px 5px;
    border-radius: 3px;
    margin-left: 10px;
}
.chat-input-slash:hover{
    background: #ebebeb;
}
.apps-tabs span{
    font-size: 13px;
    color: #818181;
    padding: 5px 8px;
    border-radius: 5px;
    margin-right: 8px;
    background: #f1f1f1;
    cursor: pointer;
    display: block;
    flex-shrink: 0;
}
.apps-tabs span:hover{
    background: #e3e3e3;
}
.apps-tabs-active{
    background: #313338 !important;
    color: #fff !important;
}
.apps-tabs{
    overflow-x: auto;
    overflow-y: hidden;
    display: flex;
    margin-bottom: 10px;
}
.apps-tabs::-webkit-scrollbar{
    display: none;
}
.app-btn span{
    font-size: 12px;
    color: #818181;
    margin-top: 5px;
    cursor: pointer;
}
.app-btn span:hover{
    color: #3bb6c2;
}
.app-btn div{
    width: 42px;
    height: 25px;
    line-height: 25px;
    background: #3bb6c2;
    border-radius: 3px;
    text-align: center;
    cursor: pointer;
    color: #fff;
}
.app-btn div:hover{
    background: #429aca;
}
.app-btn{
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.app-info p{
    font-size: 13px;
    color: #818181;
    margin-top: 5px;
    /* 超出一行省略 */
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}
.app-info{
    width: calc(100% - 138px);
}
.apps-box h1{
    font-size: 14px;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
    /* 超出一行省略 */
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}
.apps-box li img{
    width: 50px;
    height: 50px;
    border-radius: 5px;
    margin-right: 10px;
    margin-left: 10px;
    object-fit: cover;
}
.apps-box li{
    height: 68px;
    width: 100%;
    background: #f6f6f6;
    border-bottom: 1px solid #e4e4e4;
    display: flex;
    align-items: center;
    position: relative;
}
/* 第一个li */
.apps-box li:first-child{
    border-radius: 6px 6px 0 0;
}
/* 最后一个li */
.apps-box li:last-child{
    border-radius: 0 0 6px 6px;
}
.apps-box h3{
    font-size: 16px;
    margin-bottom: 10px;
    font-weight: 600;
    color: #333;
}
.apps-box{
    width: 100%;
    height: calc(100% - 38px);
    margin-top: 8px;
    overflow: auto;
}
.el-icon-search{
    font-size: 20px;
}
.app-input input{
    height: 30px;
    border: none;
    outline: none;
    width: calc(100% - 38px);
    margin-left: 6px;
    background: #e9e9e9;
}
.app-input{
    width: 100%;
    height: 38px;
    background: #e9e9e9;
    border-radius: 5px;
    display: flex;
    align-items: center;
}




.chat-emoji-menu-active{
    background: #f1f1f1;
}
.chat-emoji-menu span{
    font-size: 13px;
    color: #5b5b5b;
    padding: 6px 10px;
    cursor: pointer;
    flex-shrink: 0;
    border-radius: 3px;
}
.chat-emoji-menu{
    height: 50px;
    display: flex;
    align-items: center;
    width: 100%;
    overflow-x: auto;
}
.chat-emoji-menu::-webkit-scrollbar{
    display: none;
}
.chat-emoji-list li{
    width: 78px;
    height: 78px;
    padding: 5px;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}
.chat-emoji-list li:hover{
    background: #e3e3e3;
}
.chat-emoji-list li img{
    max-width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 6px;
}
.chat-emoji-list-container{
    width: 100%;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(78px, 1fr));
    grid-column-gap: 1px;
    -moz-column-gap: 1px;
    column-gap: 1px;
    grid-row-gap:1px;
    row-gap: 1px;
}
.chat-emoji-list{
    height: 262px;
    overflow: auto;
    overflow-x: hidden;
}
.chat-input-nologin{
    cursor: pointer;
    color: #fff;
}
.chat-input-nologin:hover{
    color: #3bb6c2;
}
.user-badge {
    height: 20px;
    margin-left: 10px;
    padding: 0 3px !important;
    background: linear-gradient(to right, #3bb6c2, #34abb6);
    font-size: 12px !important;
    border-radius: 3px;
    color: #fff !important;
    border: 1px solid #2591cf;
    box-shadow: 0 2px 3px #0000001a;
    line-height: 20px;
    cursor: pointer;
}
.chat-input-achievement p{
    font-size: 14px;
    color: #333;
    margin-left: 5px;
}
.chat-input-achievement{
    display: flex;
    align-items: center;
    cursor: pointer;
}
.chat-input-achievement-icon{
    display: flex;
    align-items: center;
    border-radius: 5px;
}
.chat-input-left span{
    font-size: 15px;
    color: #949ba4;
    cursor: pointer;
    margin-left: 12px;
}
.chat-input-left span:hover{
    color: #333;
}
.send-btn{
    margin-right: 10px;
    font-size: 15px;
    color: #333;
    cursor: pointer;
}
.chat-input-left{
    display: flex;
}
.chat-input-top{
    width: 100%;
    height: 38px;
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: .5px solid #e8e8e8;
}
.chat-input{
    width: 100%;
    border-top: 1px solid #e8e8e8;
}
.chat-input-textarea textarea{
    width: calc(100% - 20px);
    height: 100px;
    border: none;
    outline: none;
    resize: none;
    font-size: 15px;
    color: #333;
    background: #ffffff;
    font-family: "Microsoft YaHei";
    overflow: auto;
}
.chat-input-textarea{
    width: 100%;
    height: 120px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ffffff;
}
::-webkit-scrollbar{
    width: 6px;
}
::-webkit-scrollbar-thumb{
    background: #4d4f54;
    border-radius: 3px;
}

@media (max-width: 768px) {
    .chat-input-slash{
        display: none;
    }
}
</style>
