<script setup>
import { useMainStore } from "../../store/index";
import { IconPark } from '@icon-park/vue-next/es/all';
import { reactive, ref, watchEffect } from "vue";
import { useRoute } from "vue-router";
import Axios from '../../../utils/request';
import { useClipboard } from '@vueuse/core';
const stores = useMainStore();
const route = useRoute();

const data = reactive({
    roomFiles: [],    // 房间内文件
    announcementList: [],    // 公告列表

    announcementContent: '',    // 公告内容

    // 修改房间信息
    roomEdit:{
        visible: false,
        name: '',
        desc: '',
        avatar: '',
        room_id: ''
    }
})


// 获取房间内所有文件
function getRoomFiles() {
    Axios.post('/api/v1/chats/getRoomFiles', {
        room_id: route.params.id
    })
    .then(response => {
        data.roomFiles = response.data
    })
    .catch(error => {
        console.error('Error:', error);
    });

}

// 获取公告列表
function getAnnouncementList() {
    Axios.post('/api/v1/chats/getAnnouncementList', {
        room_id: route.params.id
    })
    .then(response => {
        data.announcementList = response.data
    })
    .catch(error => {
        console.error('Error:', error);
    });

}


// 发公告
function addAnnouncement() {
    if(data.announcementContent === '') {
        ElMessage.error('公告内容不能为空');
        return;
    }

    Axios.post('/api/v1/chats/writeAnnouncement', {
        room_id: route.params.id,
        content: data.announcementContent
    })
    .then(response => {
        data.announcementList = res.data;
        data.announcementContent = '';
    })
    .catch(error => {
        console.error('Error:', error);
    });

}

// 删除公告
function deleteAnnouncement(id, index) {
    Axios.post('/api/v1/chats/deleteAnnouncement', {
        room_id: route.params.id,
        announcement_id: id
    })
    .then(response => {
        data.announcementList.splice(index, 1);
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// 修改房间信息房间名称，房间描述，房间头像
function sendRoomEdit() {
    Axios.post('/api/v1/chats/modifyRoomInfo', {
        room_id: data.roomEdit.room_id,
        name: data.roomEdit.name,
        desc: data.roomEdit.desc,
        avatar: data.roomEdit.avatar
    })
    .then(response => {
        stores.rooms[stores.select_room.index].name = response.data.name;
        stores.rooms[stores.select_room.index].desc = response.data.desc;
        stores.rooms[stores.select_room.index].avatar = response.data.avatar;
        data.roomEdit.visible = false;
    })
    .catch(error => {
        console.error('Error:', error);
    });

}


// 复制房间链接
function shareRoom() {
    const { copy, isSupported } = useClipboard();
    if (isSupported) {
        // 获取jwt解码
        const token = localStorage.getItem('mychatToken');
        const user = JSON.parse(atob(token.split('.')[1]))

        // 获取根路径
        let rootPath = new URL(window.location.href).origin;
        // console.log(rootPath + `/invite/${route.params.id}?ac=${user.user_id}`)
        copy(rootPath + `/invite/${route.params.id}?ac=${user.user_id}`);
        ElMessage.success('复制成功');
    } else {
        ElMessage.error('浏览器不支持复制功能');
    }
}


// 开玩
const popoverRefApp = ref(null);
function startPlay(item) {
    popoverRefApp.value.hide();
    stores.browser.tabs.push({
        title: item.title,
        desc: item.desc,
        url: item.url
    })
    stores.browser.visible = true
}


function sendAppMsg(app_id) {
    Axios.post('/api/v1/chats/sendAppMessage', {
        room_id: route.params.id,
        app_id: app_id,
        nickname: stores.user.nickname,
        source: "web",
    })
    .then(response => {
        popoverRefApp.value.hide();
    })
    .catch(error => {
        console.error('Error:', error);
    });

}

watchEffect(() => {
    const room_id = route.params.id
    if (room_id) {
        // 获取公告
        getAnnouncementList();
        stores.roomApps = []
    }
})
</script>

<template>

    <el-dialog
            v-model="data.roomEdit.visible"
            title="修改房间信息"
            width="500"
    >
        <div class="dialog-content">
            <el-form :model="data.roomEdit" ref="form" label-width="80px">
                <el-form-item label="房间头像" prop="avatar">
                    <el-upload
                        class="avatar-uploader"
                        :action="stores.config.port + '/api/v1/chats/uploadGroupAvatar'"
                        :headers="{'Authorization': 'Bearer '+stores.getToken()}"
                        
                        :show-file-list="false"
                        :on-success="(res, file) => {
                            data.roomEdit.avatar = res.data.file.newFilename
                        }"
                    >
                        <el-avatar :src="stores.config.port + '/group/'+data.roomEdit.avatar" size="large"></el-avatar>
                    </el-upload>
                    
                </el-form-item>

                <el-form-item label="房间名称" prop="name">
                    <el-input v-model="data.roomEdit.name" placeholder="请输入房间名称"></el-input>
                </el-form-item>

                <el-form-item label="房间描述" prop="desc">
                    <el-input v-model="data.roomEdit.desc" placeholder="请输入房间描述"></el-input>
                </el-form-item>
            </el-form>

        </div>

        <template #footer>
        <div class="dialog-footer">
            <el-button @click="data.roomEdit.visible = false">取消</el-button>
            <el-button type="primary" @click="sendRoomEdit">保存修改</el-button>
        </div>
        </template>
    </el-dialog>


    <div class="chat-header">

        <el-tooltip
            class="box-item"
            effect="dark"
            content="房主可以点击修改房间信息"
            placement="right"
        >
            <div @click="() => {
                if(stores.isOwner){
                    data.roomEdit = {
                        visible: true,
                        name: stores.rooms[stores.select_room.index].name,
                        desc: stores.rooms[stores.select_room.index].desc,
                        avatar: stores.rooms[stores.select_room.index].avatar,
                        room_id: route.params.id
                    }
                }
            }" class="chat-header-left">
                <img :src="stores.config.port + '/group/'+stores.rooms[stores.select_room.index].avatar" alt="">
                <h1>{{ stores.rooms[stores.select_room.index].name }}</h1>
            </div>
        </el-tooltip>

        <div class="chat-header-right">
            <ul>
                <!-- 应用 -->
                <el-popover
                    placement="top"
                    title="房间内应用"
                    :width="380"
                    trigger="click"
                    ref="popoverRefApp"
                >
                    <template #reference>
                        <li @click="() => {
                            if(stores.roomApps.length === 0){
                                stores.getRoomApps(route.params.id);
                            }
                        }">
                            <icon-park type="application-one" size="24" fill="#333" />
                            <h6>应用</h6>
                        </li>
                    </template>

                    <template #default>
                        <ul class="apps-list">
                            <li v-for="(item, index) in stores.roomApps" :key="index">
                                <img v-if="item.icon === ''" :src="'https://icon.bqb.cool?url='+item.url" alt="">
                                <img v-else :src="stores.config.port + '/app/'+item.icon" alt="">
                                <div class="app-info">
                                    <h1>{{ item.title }}</h1>
                                    <p>{{item.desc}}</p>
                                </div>
                                <div class="app-btn">
                                    <div @click=startPlay(item)>开玩</div>
                                    <span @click=sendAppMsg(item.app_id)>发送到聊天</span>
                                </div>
                            </li>
                        </ul>
                    </template>
                </el-popover>

                <!-- 公告 -->
                <el-popover
                    placement="top"
                    title="公告"
                    :width="380"
                    trigger="click"
                >
                    <template #reference>
                        <el-badge :value="data.announcementList.length" :max="99">
                            <li>
                                <icon-park type="speaker-one" size="24" fill="#333" />
                                <h6>公告</h6>
                            </li>
                        </el-badge>
                    </template>

                    <template #default>
                        <template v-if="stores.isOwner">
                            <div class="chat-header-right-popover">
                                <textarea v-model="data.announcementContent" placeholder="请输入公告内容"></textarea>
                            </div>
                            <el-button @click="addAnnouncement" type="primary" style="margin-top: 8px; width: 100%;">发送</el-button>
                        </template>

                        <ul class="announcement-list">
                            <li v-for="(item, index) in data.announcementList" :key="index">
                                <p>{{ item.content }}</p>
                                <span>{{ stores.formatDate(item.createdAt) }}</span>
                                <span v-if="stores.isOwner" @click="deleteAnnouncement(item.announcement_id, index)" style="cursor: pointer; color: brown;"> 删除</span>
                            </li>
                        </ul>

                        <span v-if="data.announcementList.length === 0">暂无公告</span>
                      
                    </template>
                </el-popover>
                

                <!-- 文件 -->
                <el-popover
                    placement="top"
                    title="文件"
                    :width="380"
                    trigger="click"
                >
                    <template #reference>
                        <li @click="getRoomFiles">
                            <icon-park type="save-one" size="24" fill="#333" />
                            <h6>文件</h6>
                        </li>
                    </template>

                    <template #default>
                        <ul class="file-list">
                            <li v-for="(item, index) in data.roomFiles" :key="index">
                                <i>{{ item.json_msg.format }}</i>
                                <div style="width: 250px;">
                                    <p>{{ item.json_msg.file_name }}</p>
                                    <span>{{ item.nickname }} {{stores.formatDate(item.createdAt)}}</span>
                                </div>

                                <div>
                                    <a :href="stores.config.port + '/chatFiles/'+item.json_msg.file_url" target="_blank">
                                        <el-button link size="small">下载</el-button>
                                    </a>
                                </div>
                                
                            </li>
                        </ul>
                    </template>
                </el-popover>

                <!-- 分享 -->
                <li @click="shareRoom">
                    <icon-park type="share-two" size="24" fill="#333" />
                    <h6>分享房间</h6>
                </li>
            </ul>
        </div>
        
    </div>
</template>

<style scoped>
.app-btn span{
    font-size: 12px;
    color: #818181;
    margin-top: 5px;
    cursor: pointer;
}
.app-btn span:hover{
    color: #3bb6c2;
}
.app-btn div{
    width: 42px;
    height: 25px;
    line-height: 25px;
    background: #3bb6c2;
    color: #fff;
    border-radius: 3px;
    text-align: center;
    cursor: pointer;
}
.app-btn div:hover{
    background: rgb(66, 154, 202);
}
.app-btn{
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.app-info p{
    font-size: 13px;
    color: #818181;
    margin-top: 5px;
    /* 超出一行省略 */
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}
.app-info{
    width: calc(100% - 138px);
}
.apps-list h1{
    font-size: 14px;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
    /* 超出一行省略 */
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}
.apps-list li img{
    width: 50px;
    height: 50px;
    border-radius: 5px;
    margin-right: 10px;
    margin-left: 10px;
    object-fit: cover;
}
.apps-list li{
    height: 68px;
    width: 100%;
    border-bottom: 1px solid #e4e4e4;
    display: flex;
    align-items: center;
}
.file-list li span{
    color: #9b9b9b;
}
.file-list li p{
    font-size: 16px;
    color: #333;
    margin-bottom: 3px;
    /* 超过一行省略号 */
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}
.file-list li i{
    width: 45px;
    height: 45px;
    background: #5ea2e2;
    border-radius: 8px;
    text-align: center;
    line-height: 45px;
    color: #fff;
    font-size: 20px;
    font-weight: 700;
    margin-right: 10px;
}
.file-list li{
    height: 50px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #f1f1f1;
    padding: 10px 0;
}
.file-list{
    margin-top: 10px;
    max-height: 380px;
    overflow: auto;
}
.announcement-list li p{
    font-size: 14px;
    color: #333;
    margin-bottom: 6px;
}
.announcement-list li span{
    font-size: 13px;
    color: #9b9b9b;
}
.announcement-list li{
    border-bottom: 1px solid #f1f1f1;
    padding: 10px 0;
}
/* 最后一个li */
.announcement-list li:last-child{
    border-bottom: none;
}
.announcement-list{
    margin-top: 10px;
    max-height: 380px;
    overflow: auto;
}
.chat-header-right-popover textarea{
    display: block;
    width: 95%;
    height: 80px;
    margin: 0 auto;
    border: none;
    outline: none;
    border-radius: 5px;
    background: #f1f1f1;
    resize: none;
    font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
}
.chat-header-right-popover{
    width: 100%;
    padding-top: 6px;
    padding-bottom: 6px;
    background: #f1f1f1;
    border-radius: 5px;
}
.chat-header-right ul li h6 {
    color: #2a2a51;
    margin-left: 8px;
}
.chat-header-right ul li{
    margin-left: 10px;
    display: flex;
    align-items: center;
    padding: 5px 12px;
    border-radius: 5px;
    background: #a5d6e5;
    cursor: pointer;
    transition: all 0.2s;
}
.chat-header-right ul li:hover{
    background: #9ac9d7;
}
.chat-header-right ul{
    display: flex;
    align-items: center;
}
.chat-header-left h1{
    font-size: 18px;
    margin-left: 10px;
    color: #2a2a2a;
}
.chat-header-left{
    display: flex;
    align-items: center;
    cursor: pointer;
}
.chat-header img{
    width: 40px;
    height: 40px;
    border-radius: 10px;
    object-fit: cover;
}
.chat-header{
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 60px;
    background-color: #b7e4f2;
    padding: 0 16px;
    box-shadow: 0 1px 2px rgba(7, 149, 147, 0.1);
}

@media (max-width: 768px) {
    .chat-header-right{
        display: none;
    }
}
</style>