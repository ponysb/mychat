<script setup>
import { ref, reactive, onMounted, nextTick, watch } from 'vue';
import Axios from '../../../utils/request';
import { useRouter, useRoute } from 'vue-router';
import { useMainStore } from '../../store/index'
const stores = useMainStore()

const state = reactive({
    output: [], // 输出内容,消息列表

    term: null, // Xterm 实例
    
    command: '', // 输入命令

    popup: false,

    seleRoomIndex: 0, // 选择的房间索引
});

const terminal = ref(null);  // 获取终端dom
const router = useRouter();
const route = useRoute();
state.seleRoomIndex = stores.select_room.index

// 查询是否为vip
function checkVip(username) {
    let reg_vip = new RegExp(stores.badgeData.vip)
    let reg_pro = new RegExp(stores.badgeData.pro)
    // vip有数据就返回vip，pro有数据就返回pro，都没有就返回普通用户
    if (stores.badgeData.vip && reg_vip.test(username)) {
        return "vip"
    } else if (stores.badgeData.pro && reg_pro.test(username)) {
        return "pro"
    } else {
        return "普通用户"
    }
}

onMounted(() => {
    ElMessage({
        message: '刷新返回普通模式',
        type: 'success',
    })
});



// 跳转
function toRoom(room_id, index){
    router.push({path: '/chat/' + room_id})
    state.output = []
    // 延迟渲染，防止闪屏
    stores.select_room = {  // 当前选择的房间id
        room_id: room_id,  // 当前选择的房间id
        index: index,  // 当前选择的房间索引
        messages: [],  // 当前房间消息列表
    }
    setTimeout(() => {
        getChatRecord()
    }, 0)
}


//文字消息发送
function send_msg(){

    if(state.popup){
        toRoom(stores.rooms[state.seleRoomIndex].room_id, state.seleRoomIndex)

        state.popup = false
        state.command = ''

        ElMessage({
            message: `已切换到${stores.rooms[stores.select_room.index].name}房间`,
            type: 'success',
        })
        return
    }


    // 判断文本里是否存在链接
    const url = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/g;
    if(url.test(state.command)){
        ElMessage.error('不能发送链接哦~')
        return
    }

    // 过滤空格换行符和特殊字符
    state.command = state.command.replace(/[\r\n\s]/g, '');
    if(state.command == ''||state.command.length > 500){
        ElMessage.error('输入1-500字再发送哦~')
        return
    }

    if(!localStorage.getItem('mychatToken')){
        ElMessage.error('先登录再发送消息哦~')
        return
    }

    Axios.post('/api/v1/chats/sendMessage', {
        room_id: route.params.id,
        nickname: stores.user.nickname,
        source: "web",
        msg: state.command,
        type: 'text'
    })
    .then(response => {
        // console.log(response.data.users)
        render_msg(stores.select_room.messages)
        state.command = ''
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });
    
}




// 返回时间，存在数据库里的有时间，mqtt及时返回的没有
function return_time(date){
    // 判断有没有createdAt
    if(date.createdAt){
        return new Date(date.createdAt).toLocaleString()
    }else{
        return new Date().toLocaleString()
    }
}


// 消息渲染处理
render_msg(stores.select_room.messages)
function render_msg(data){
    data.map((data, index) => {
        // type = 'text'
        if(data.type === 'text'){
            // pro股东
            if (checkVip(data.username) === 'pro') {
                state.output.push(`
                <span style="color:yellow; font-weight:bold" class="command">
                    ${data.nickname}(嚣张的摸鱼Pro会员): <span style="color:#fe8d51; font-weight:bold">${data.msg}</span> 
                    <span style="color: #999;">${return_time(data)}</span>
                </span>`);
            }
            

            // 普通股东
            if (checkVip(data.username) === 'vip') {
                state.output.push(`<span style="color:red; font-weight:bold" class="command">
                    ${data.nickname}(嚣张的摸鱼会员): <span style="color:#fe8d51; font-weight:bold">${data.msg}</span> 
                    <span style="color: #999;">${return_time(data)}</span>
                </span>`);
            }

            // 普通用户
            if (checkVip(data.username) === '普通用户') {
                state.output.push(`<span class="command">${data.nickname}: 
                    <span style="color:#fe8d51;">${data.msg}</span> 
                    <span style="color: #999;">${return_time(data)}</span>
                </span>`);
            }
        }

        // type = 'bqb'
        if(data.type === 'bqb'){
            // pro股东
            if (checkVip(data.username) === 'pro') {
                state.output.push(`<span style="color:yellow; font-weight:bold" class="command">
                    ${data.nickname}: 
                    <a href="https://mychat.bqb.zhuayuya.com${data.json_msg.emoticon_url}" target="_blank">[表情]</a> 
                    <span style="color: #999;">${return_time(data)}</span>
                <span>`); // 输出接收到的消息
            }

            // 普通股东
            if (checkVip(data.username) === 'vip') {
                state.output.push(`<span style="color:red; font-weight:bold" class="command">
                    ${data.nickname}: 
                    <a href="https://mychat.bqb.zhuayuya.com${data.json_msg.emoticon_url}" target="_blank">[表情]</a> 
                    <span style="color: #999;">${return_time(data)}</span>
                <span>`); // 输出接收到的消息
            }

            // 普通用户
            if (checkVip(data.username) === '普通用户') {
                state.output.push(`<span class="command">
                    ${data.nickname}: 
                    <a href="https://mychat.bqb.zhuayuya.com${data.json_msg.emoticon_url}" target="_blank">[表情]</a> 
                    <span style="color: #999;">${return_time(data)}</span>
                <span>`);
            }
        }

        // type = 'app'
        if(data.type === 'app'){
            // pro股东
            if (checkVip(data.username) === 'pro') {
                state.output.push(`<span style="color:yellow; font-weight:bold" class="command">
                    ${data.nickname}: 
                    <a href="${data.json_msg.app_url}" target="_blank">[${data.json_msg.app_title}]</a> 
                    <span style="color: #999;">${return_time(data)}</span>
                </span>`); // 输出接收到的消息
            }

            // 普通股东
            if (checkVip(data.username) === 'vip') {
                state.output.push(`<span style="color:red; font-weight:bold" class="command">
                    ${data.nickname}: 
                    <a href="${data.json_msg.app_url}" target="_blank">[${data.json_msg.app_title}]</a> 
                    <span style="color: #999;">${return_time(data)}</span>
                </span>`); // 输出接收到的消息
            }

            // 普通用户
            if (checkVip(data.username) === '普通用户') {
                state.output.push(`<span class="command">
                    ${data.nickname}: 
                    <a href="${data.json_msg.app_url}" target="_blank">[${data.json_msg.tapp_title}]</a> 
                    <span style="color: #999;">${return_time(data)}</span>
                </span>`);
            }
        }
    })

    nextTick(() => {
        terminal.value.scrollTop = terminal.value.scrollHeight;
    });
}


// 获取聊天记录
function getChatRecord() {

    Axios.post('/api/v1/chats/getChatRecords', {
        room_id: route.params.id,
        page: 1,
        limit: 100,
    })
    .then(response => {
        // console.log(response.data.users)
        stores.select_room.messages = response.data.reverse()        // 倒序
        nextTick(() => {
            setTimeout(() => {
                state.output = []
                render_msg(stores.select_room.messages)
            }, 100)
        })
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}




// 上下键切换房间，回车键确定
function switch_room(event){
    if (event.keyCode === 38) { // 上键
        event.preventDefault();
        // console.log('上键');
        state.seleRoomIndex = (state.seleRoomIndex - 1 + stores.rooms.length) % stores.rooms.length;
    } else if (event.keyCode === 40) { // 下键
        // console.log('下键');
        event.preventDefault();
        state.seleRoomIndex = (state.seleRoomIndex + 1) % stores.rooms.length;
    }

    // 获取当前选中的房间元素
    const selectedRoomElement = document.getElementById(`room-${state.seleRoomIndex}`);
    
    // 确保选中的房间元素在视口内
    if (selectedRoomElement) {
        selectedRoomElement.scrollIntoView({
            behavior: 'smooth', // 平滑滚动
            block: 'center',    // 将选中项居中显示
        });
    }
}

</script>

<template>
    <div ref="terminal" class="terminal">
        <div v-for="(line, index) in state.output" :key="index" v-html="line" class="output"></div>

        <div class="input-line">
            <span class="prompt">></span>
            <input @keydown="switch_room" v-model="state.command" @input="() => {
                if(state.command === '/'){
                    state.popup = true;
                }else{
                    state.popup = false;
                }
            }" @keydown.enter="send_msg" type="text" placeholder="Enter command" />
            <div v-if="state.popup" class="popup-box">
                <p :id="'room-'+ index" v-for="(room, index) in stores.rooms" :key="index" :class="{active: state.seleRoomIndex === index}" @click="toRoom(room.room_id, index)">{{ room.name }}</p>
            </div>
        </div>
    </div>
</template>


<style scoped>
.active{
    background: #0f0f0f;
}
.popup-box p{
    color: #00be00;
    font-size: 13px;
    margin-bottom: 5px;
    cursor: pointer;
    padding: 6px;
    border-radius: 3px;
}
.popup-box{
    position: absolute;
    top: 20px;
    max-width: 200px;
    max-height: 150px;
    background: #161616;
    padding: 10px;
    box-sizing: border-box;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    overflow: auto;
}
.terminal {
    background-color: black;
    color: white;
    font-family: 'Courier New', Courier, monospace;
    padding: 10px;
    box-sizing: border-box;
    /* max-width: 600px; */
    height: 100vh;
    overflow: scroll;
    margin: 0 auto;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
}

/* 滚动条样式 */
.terminal::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

.terminal::-webkit-scrollbar-thumb {
    background: #4d4d4d;
    border-radius: 5px;
}

.output {
    margin-bottom: 10px;
}

.line {
    margin: 5px 0;
}
.line::selection {
    background: #4d4d4d;
}

.input-line {
    display: flex;
    align-items: center;
    position: relative;
    margin-bottom: 150px;
}

.prompt {
    color: lightblue;
    margin-right: 5px;
}

input {
    background: none;
    border: none;
    outline: none;
    color: white;
    flex-grow: 1;
    font-size: 16px;
    font-family: 'Courier New', Courier, monospace;
    letter-spacing: 1px;
    /* 控制字母间距 */
    position: relative;
}

input::placeholder {
    color: #bbb;
}

</style>

<style>
.command {
    color: #00ff00;
    line-height: 20px;
    font-size: 15px;
}
.command a{
    color: rgb(237, 93, 68);
    text-decoration: none;
}
.command a:hover{
    text-decoration: underline;
}
.command::selection {
    background: #4d4d4d !important;
}
</style>