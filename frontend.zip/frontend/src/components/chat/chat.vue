<script setup>
import { reactive, ref, nextTick, onMounted, onUnmounted, watchEffect, watch } from "vue";
import { useMainStore } from "../../store/index";
import { useRoute } from "vue-router";
import Axios from '../../../utils/request';
const stores = useMainStore();
import Header from './header.vue'
import Input from './input.vue'
import Online from './online.vue'
import 'github-markdown-css'
import '../../github-markdown.css'
const data = reactive({
    interactEmoticons: [],

    interactVisible: false,  // 互动表情包显示状态

    badgeData: [],    // 徽章数据

    reportForm: {    // 举报表单
        visible: false,  // 是否显示举报表单
        msg_id: '',  // 消息id
        reason: '',  // 举报原因
        content: ''  // 举报内容
    },
})

const chat_operation = ref(null)
const chat_border = ref(null)

const route = useRoute();


// 获取互动表情包
function getInteractEmoticons() {

    Axios.post('/api/v1/chats/getInteractEmoticons', {
        room_id: route.params.id
    })
    .then(response => {
        data.interactEmoticons = response.data
    })
    .catch(error => {
        console.error('Error:', error);
    });

}


// 互动计算去重算法
function deduplicateAndCount(data) {
    const result = [];
    const emoticonMap = {};

    data.forEach(item => {
        // 使用emoticon_id作为唯一标识符
        const key = item.emoticon_id;

        if (emoticonMap[key]) {
        // 如果已经有这个emoticon_id，增加计数
        emoticonMap[key].count += 1;
        } else {
        // 如果没有该emoticon_id，初始化计数为1
        emoticonMap[key] = {
            ...item,
            count: 1
        };
        // 把去重后的对象加入结果数组
        result.push(emoticonMap[key]);
        }
    });

    return result;
}

// 消息互动
let lastCallTime = 0;
function sendInteract(msg_id, emoticon_id, url, index) {
    const now = Date.now();
    if (now - lastCallTime < 3000) {
        ElMessage.error('请勿频繁点击');
        return;
    }
    lastCallTime = now;

    Axios.post('/api/v1/chats/chatRecordInteract', {
        msg_id: msg_id,
        emoticon_id: emoticon_id,
        url: url
    })
    .then(response => {
        stores.select_room.messages[index].interact.push({
            emoticon_id: res.data.emoticon_id,
            url: res.data.url,
            username: res.data.username,
            emoticon_id: res.data.emoticon_id
        })
    })
    .catch(error => {
        console.error('Error:', error);
    });

}


// 字节转换成KB、MB、GB、TB单位
function formatFileSize(size) {
    if (size === 0) return '0 B';
    var unitArr = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    var index = Math.floor(Math.log(size) / Math.log(1024));
    var sizeStr = (size / Math.pow(1024, index)).toFixed(2);
    return sizeStr + unitArr[index];
}



stores.getBadgeData()


// 查询我的徽章
function checkIdAttributes(id) {
    const attributes = [];

    // 检查数据是否存在
    if (!stores.badgeData.badge || typeof data !== "object") {
        return "数据格式错误";
    }

    // 动态遍历所有字段
    for (const key in stores.badgeData.badge) {
        if (Array.isArray(stores.badgeData.badge[key])) {
            // 检查是否是 stockholder 字段
            if (key === "stockholder") {
                const isStockholder = stores.badgeData.badge[key].some(item => item.includes(id));
                if (isStockholder) {
                    attributes.push(key);
                }
            } else {
                // 检查 id 是否在数组中
                if (stores.badgeData.badge[key].includes(id)) {
                    attributes.push(key);
                }
            }
        }
    }

    // 返回结果
    return attributes.length > 0 ? attributes : "该 ID 无任何属性";
}


// 查询是否为vip
function checkVip(username) {
    let reg_vip = new RegExp(stores.badgeData.vip)
    let reg_pro = new RegExp(stores.badgeData.pro)
    // vip有数据就返回vip，pro有数据就返回pro，都没有就返回普通用户
    if (stores.badgeData.vip && reg_vip.test(username)) {
        return "vip"
    } else if (stores.badgeData.pro && reg_pro.test(username)) {
        return "pro"
    } else {
        return "普通用户"
    }
}


// 举报提交
function reportSubmit() {
    // console.log(data.reportForm)
    if (data.reportForm.reason === '' || data.reportForm.content === '') {
        ElMessage.error('请填写完整信息');
        return;
    }

    Axios.post('/api/v1/chats/chatRecordReport', {
        msg_id: data.reportForm.msg_id,
        reason: data.reportForm.reason,
        content: data.reportForm.content
    })
    .then(response => {
        // console.log(response)
        ElMessage.success('举报成功');
        data.reportForm.visible = false;
    })
    .catch(error => {
        ElMessage.error('举报失败');
    });

}


// 获取聊天记录
function getChatRecord() {
    Axios.post('/api/v1/chats/getChatRecords', {
        room_id: route.params.id,
        page: 1,
        limit: 100,
    })
    .then(response => {
        stores.select_room.messages = response.data.reverse()        // 倒序
        nextTick(() => {
            setTimeout(() => {
                const chat_box = document.getElementById('chat_box')
                chat_box.scrollTop = chat_box.scrollHeight;
            }, 100)
        })
    })
    .catch(error => {
        console.error('Error:', error);
    });
}


watchEffect(() => {
    const room_id = route.params.id
    if (room_id) {
        getChatRecord()
        stores.isOwnerQuery(route.params.id)
    }
})

// 监听聊天记录的变化
watch(() => stores.select_room.messages.length, async() => {
    const chat_box = document.getElementById('chat_box');
    if (chat_box.scrollHeight - chat_box.scrollTop - chat_box.clientHeight < 250) {
        await nextTick()
        setTimeout(() => {
            chat_box.scrollTop = chat_box.scrollHeight;
        }, 100);
    }
});



// 浏览器切换标签页恢复页面状态
const handleVisibilityChange = () => {
    if (document.visibilityState === 'visible') {
        getChatRecord()
        // console.log('切入摸鱼聊天室');
    } else {
        console.log('切出摸鱼聊天室');
    }
};

onUnmounted(() => {
    document.removeEventListener('visibilitychange', handleVisibilityChange);
});


onMounted(() => {
    document.addEventListener('visibilitychange', handleVisibilityChange);
    // getChatRecord()
})


// pro点击事件
function vip_click(e){
    e.stopPropagation()
    stores.stockholder.visible = true
}

</script>

<template>
    <el-dialog
        v-model="data.reportForm.visible"
        title="消息举报"
        width="500"
    >
        <span>举报的内容：{{ data.reportForm.content }}</span>
        <h1 style="margin-top: 16px; font-size: 15px; margin-bottom: 10px;">举报原因:</h1>
        <el-radio-group v-model="data.reportForm.reason">
            <!-- 单选 -->
            <el-radio label="涉黄暴政">涉黄暴政</el-radio>
            <el-radio label="垃圾信息">垃圾信息</el-radio>
            <el-radio label="广告">广告</el-radio>
            <el-radio label="谩骂">谩骂</el-radio>
            <el-radio label="刷屏">刷屏</el-radio>

        </el-radio-group>

        <template #footer>
        <div class="dialog-footer">
            <el-button @click="data.reportForm.visible = false">取消</el-button>
            <el-button type="primary" @click="reportSubmit">举报</el-button>
        </div>
        </template>
    </el-dialog>

    <Header />
    <div class="chat-box">
        <ul id="chat_box">
            <template v-for="(item, index) in stores.select_room.messages" :key="index">
                <!-- 普通文本消息 -->
                <li v-if="item.type === 'text'" ref="chat_border" class="chat-text chat">
                    <img class="chat-avatar" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">
                    <div>

                        <!-- 昵称 -->
                        <div class="chat-nickname-box">
                            
                            <!-- 普通用户 -->
                            <h3 v-if="checkVip(item.username) == '普通用户'" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- 普通会员 -->
                            <h3 v-if="checkVip(item.username) == 'vip'" @click="vip_click($event)" style="color: #ff0000;" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- pro会员 -->
                            <h3 v-if="checkVip(item.username)  == 'pro'" class="pro-nickname">{{ item.nickname }} <a href="#" @click="vip_click($event)"> 嚣张的摸鱼超级股东</a> </h3>
    
                            

                            <div class="chat-badge">
                                <template v-for="(badge, badgeIndex) in checkIdAttributes(item.username)" :key="badgeIndex">
                                    <img v-if="badge === 'vip'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸鱼股东徽章">
                                    <img v-if="badge === 'pro'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="超级摸鱼股东徽章">
                                    <img v-if="badge === 'clock'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="连续打卡徽章">
                                    <img v-if="badge === 'message'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="水群狂魔徽章">
                                    <img v-if="badge === 'age'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸龄1年徽章">
                                </template>
                                
                            </div>
                        </div>
                        

                        <!-- 普通消息 -->
                        <div v-if="checkVip(item.username) != 'pro'" style="display: flex;">
                            <p>{{ item.msg }}</p>
                            <div class="msg-warn">
                                <el-icon v-if="item.msg_id === ''"><Loading /></el-icon>
                                <span v-if="item.msg_id === '发送失败'">失败</span>
                            </div>
                        </div>

                        <!-- 摸鱼会员消息 -->
                        <div v-if="checkVip(item.username) == 'pro'" class="chat-content-pro" style="display: flex;">
                            <img src="../../assets/chat/pro.png" alt="">
                            <p>{{ item.msg }}</p>
                            <div class="msg-warn">
                                <el-icon v-if="item.msg_id === ''"><Loading /></el-icon>
                                <span v-if="item.msg_id === '发送失败'">失败</span>
                            </div>
                        </div>

                        <!-- 互动 -->
                        <div v-if="item.interact && item.interact.length > 0" class="chat-interact-box">
                            <template 
                                v-for="(interact, subindex) in deduplicateAndCount(item.interact)" 
                                :key="subindex" 
                            >
                                <el-popover
                                    placement="top-start"
                                    :width="120"
                                    trigger="hover"
                                    content="this is content, this is content, this is content"
                                >
                                    <template #reference>
                                        <div class="chat-interact" @click="sendInteract(item.msg_id, interact.emoticon_id, interact.url, index)" >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                            <span>+{{ interact.count }}</span>
                                        </div>
                                    </template>

                                    <template #default>
                                        <img
                                            style="width: 120px; height: 120px; object-fit: cover; border-radius: 5px;"
                                        :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                    </template>
                                </el-popover>
                            </template>
                        </div>


                    </div>

                    <!-- 操作 -->
                    <div ref="chat_operation" class="chat-operation">
                        <div class="chat-operation-content">
                            <el-popover
                                placement="bottom"
                                title="与消息互动"
                                :width="310"
                                trigger="hover"
                                @show="() => {
                                    chat_operation[index].style = 'display: block';
                                    chat_border[index].style = 'background: #fff;';
                                    data.interactVisible = true;
                                    if(data.interactEmoticons.length === 0){
                                        getInteractEmoticons()
                                    }
                                }"
                                @hide="chat_operation[index].style = ''; chat_border[index].style = ''; data.interactVisible = false;"
                            >
                                <template #reference>
                                    <span>☺️互动</span>
                                </template>

                                <template #default>
                                    <ul v-if="data.interactVisible" class="chat-interact-popup">
                                        <li 
                                            v-for="(emoticon, subsubindex) in data.interactEmoticons" 
                                            :key="subsubindex" 
                                            @click="sendInteract(item.msg_id, emoticon.emoticon_id, emoticon.url, index)"
                                        >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+emoticon.url" alt="">
                                        </li>

                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </ul>
                           
                                </template>
                            </el-popover>
                            
                            <span @click="() => {
                                data.reportForm = {
                                    visible: true,
                                    msg_id: item.msg_id,
                                    reason: '',
                                    content: item.msg
                                }
                            }">🙋举报</span>
                        </div>
                    </div>
                </li>

                <!-- 应用消息 -->
                <li v-if="item.type === 'app'" ref="chat_border" class="chat-app chat">
                    <img class="chat-avatar" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">

                    <div>

                        <!-- 昵称 -->
                        <div class="chat-nickname-box">
                            
                            <!-- 普通用户 -->
                            <h3 v-if="checkVip(item.username) == '普通用户'" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- 普通会员 -->
                            <h3 v-if="checkVip(item.username) == 'vip'" @click="vip_click($event)" style="color: #ff0000;" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- pro会员 -->
                            <h3 v-if="checkVip(item.username)  == 'pro'" style="padding-left: 8px;" class="pro-nickname">{{ item.nickname }} <a href="#" @click="vip_click($event)"> 嚣张的摸鱼超级股东</a> </h3>
    
                            

                            <div class="chat-badge">
                                <template v-for="(badge, badgeIndex) in checkIdAttributes(item.username)" :key="badgeIndex">
                                    <img v-if="badge === 'vip'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸鱼股东徽章">
                                    <img v-if="badge === 'pro'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="超级摸鱼股东徽章">
                                    <img v-if="badge === 'clock'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="连续打卡徽章">
                                    <img v-if="badge === 'message'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="水群狂魔徽章">
                                    <img v-if="badge === 'age'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸龄1年徽章">
                                </template>
                                
                            </div>
                        </div>
                        
                        <!-- 消息体 -->
                        <div style="display: flex;">
                            <a :href="item.json_msg.app_url" target="_blank" class="chat-app-content">
                                <h3>{{ item.json_msg.app_title }}</h3>
                                <div style="display: flex;">
                                    <p>{{ item.json_msg.app_desc }}</p>
                                     <img v-if="item.json_msg.app_icon" :src="stores.config.port + '/app/'+item.json_msg.app_icon" alt="">
                                     <img v-else :src="'https://icon.bqb.cool?url='+item.json_msg.app_url" alt="">
                                </div>
                                <h6>{{ item.json_msg.app_url }}</h6>
                            </a>
                            <div class="msg-warn">
                                <el-icon v-if="item.msg_id === ''"><Loading /></el-icon>
                                <span v-if="item.msg_id === '发送失败'">失败</span>
                            </div>
                        </div>
                        
                        <!-- 互动 -->
                        <div v-if="item.interact && item.interact.length > 0" class="chat-interact-box">
                            <template 
                                v-for="(interact, subindex) in deduplicateAndCount(item.interact)" 
                                :key="subindex" 
                            >
                                <el-popover
                                    placement="top-start"
                                    :width="120"
                                    trigger="hover"
                                    content="this is content, this is content, this is content"
                                >
                                    <template #reference>
                                        <div class="chat-interact" @click="sendInteract(item.msg_id, interact.emoticon_id, interact.url, index)" >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                            <span>+{{ interact.count }}</span>
                                        </div>
                                    </template>

                                    <template #default>
                                        <img
                                            style="width: 120px; height: 120px; object-fit: cover; border-radius: 5px;"
                                        :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                    </template>
                                </el-popover>
                            </template>
                        </div>


                    </div>
                    <!-- 操作 -->
                    <div ref="chat_operation" class="chat-operation">
                        <div class="chat-operation-content">
                            <el-popover
                                placement="bottom"
                                title="与消息互动"
                                :width="310"
                                trigger="hover"
                                @show="() => {
                                    chat_operation[index].style = 'display: block';
                                    chat_border[index].style = 'background: #fff;';
                                    data.interactVisible = true;
                                    if(data.interactEmoticons.length === 0){
                                        getInteractEmoticons()
                                    }
                                }"
                                @hide="chat_operation[index].style = ''; chat_border[index].style = ''; data.interactVisible = false;"
                            >
                                <template #reference>
                                    <span>☺️互动</span>
                                </template>

                                <template #default>
                                    <ul v-if="data.interactVisible" class="chat-interact-popup">
                                        <li 
                                            v-for="(emoticon, subsubindex) in data.interactEmoticons" 
                                            :key="subsubindex" 
                                            @click="sendInteract(item.msg_id, emoticon.emoticon_id, emoticon.url, index)"
                                        >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+emoticon.url" alt="">
                                        </li>

                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </ul>
                           
                                </template>
                            </el-popover>
                            
                            <span @click="() => {
                                data.reportForm = {
                                    visible: true,
                                    msg_id: item.msg_id,
                                    reason: '',
                                    content: item.json_msg.app_title + '：' + item.json_msg.app_url
                                }
                            }">🙋举报</span>
                        </div>
                    </div>
                </li>

                <!-- 图片消息 -->
                <li v-if="item.type === 'image'" ref="chat_border" class="chat-image chat">
                    <img class="chat-avatar" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">

                    <div>
                        <!-- 昵称 -->
                        <div class="chat-nickname-box">
                            
                            <!-- 普通用户 -->
                            <h3 v-if="checkVip(item.username) == '普通用户'" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- 普通会员 -->
                            <h3 v-if="checkVip(item.username) == 'vip'" @click="vip_click($event)" style="color: #ff0000;" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- pro会员 -->
                            <h3 v-if="checkVip(item.username)  == 'pro'" style="padding-left: 8px;" class="pro-nickname">{{ item.nickname }} <a href="#" @click="vip_click($event)"> 嚣张的摸鱼超级股东</a> </h3>
    
                            

                            <div class="chat-badge">
                                <template v-for="(badge, badgeIndex) in checkIdAttributes(item.username)" :key="badgeIndex">
                                    <img v-if="badge === 'vip'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸鱼股东徽章">
                                    <img v-if="badge === 'pro'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="超级摸鱼股东徽章">
                                    <img v-if="badge === 'clock'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="连续打卡徽章">
                                    <img v-if="badge === 'message'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="水群狂魔徽章">
                                    <img v-if="badge === 'age'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸龄1年徽章">
                                </template>
                                
                            </div>
                        </div>
                        
                        <!-- 消息体 -->
                        <div class="chat-image-content">
                            <!-- 带尺寸 -->
                            <el-image
                                class="chat-image-content-img"
                                v-if="item.json_msg.width"
                                :style="`width: ${item.json_msg.width}px; height: ${item.json_msg.height}px`"
                                :src="stores.config.port + '/chatImages/'+item.json_msg.file_url+'.webp'"
                                :alt="item.json_msg.file_name"
                                :zoom-rate="1.2"
                                :max-scale="7"
                                :min-scale="0.2"
                                show-progress
                                :preview-src-list="[stores.config.port + '/chatImages/'+item.json_msg.file_url+'.webp']"
                                :initial-index="4"
                                fit="cover"
                            />

                            <!-- 不带尺寸 -->
                            <el-image
                                style="max-width: 380px; max-height: 450px; object-fit: cover;"
                                class="chat-image-content-img"
                                v-if="!item.json_msg.width"
                                :src="stores.config.port + '/chatImages/'+item.json_msg.file_url"
                                :alt="item.json_msg.file_name"
                                :zoom-rate="1.2"
                                :max-scale="7"
                                :min-scale="0.2"
                                show-progress
                                :preview-src-list="[stores.config.port + '/chatImages/'+item.json_msg.file_url]"
                                :initial-index="4"
                                fit="cover"
                            />
                        </div>

                        <!-- 互动 -->
                        <div v-if="item.interact && item.interact.length > 0" class="chat-interact-box">
                            <template 
                                v-for="(interact, subindex) in deduplicateAndCount(item.interact)" 
                                :key="subindex" 
                            >
                                <el-popover
                                    placement="top-start"
                                    :width="120"
                                    trigger="hover"
                                    content="this is content, this is content, this is content"
                                >
                                    <template #reference>
                                        <div class="chat-interact" @click="sendInteract(item.msg_id, interact.emoticon_id, interact.url, index)" >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                            <span>+{{ interact.count }}</span>
                                        </div>
                                    </template>

                                    <template #default>
                                        <img
                                            style="width: 120px; height: 120px; object-fit: cover; border-radius: 5px;"
                                        :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                    </template>
                                </el-popover>
                            </template>
                        </div>


                    </div>

                    <!-- 操作 -->
                    <div ref="chat_operation" class="chat-operation">
                        <div class="chat-operation-content">
                            <el-popover
                                placement="bottom"
                                title="与消息互动"
                                :width="310"
                                trigger="hover"
                                @show="() => {
                                    chat_operation[index].style = 'display: block';
                                    chat_border[index].style = 'background: #fff;';
                                    data.interactVisible = true;
                                    if(data.interactEmoticons.length === 0){
                                        getInteractEmoticons()
                                    }
                                }"
                                @hide="chat_operation[index].style = ''; chat_border[index].style = ''; data.interactVisible = false;"
                            >
                                <template #reference>
                                    <span>☺️互动</span>
                                </template>

                                <template #default>
                                    <ul v-if="data.interactVisible" class="chat-interact-popup">
                                        <li 
                                            v-for="(emoticon, subsubindex) in data.interactEmoticons" 
                                            :key="subsubindex" 
                                            @click="sendInteract(item.msg_id, emoticon.emoticon_id, emoticon.url, index)"
                                        >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+emoticon.url" alt="">
                                        </li>

                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </ul>
                           
                                </template>
                            </el-popover>
                            
                            <span @click="() => {
                                data.reportForm = {
                                    visible: true,
                                    msg_id: item.msg_id,
                                    reason: '',
                                    content: item.json_msg.file_url + '：' + item.json_msg.file_name
                                }
                            }">🙋举报</span>
                        </div>
                    </div>
                </li>

                <!-- 表情消息 -->
                <li v-if="item.type === 'bqb'" ref="chat_border" class="chat-image chat">
                    <img class="chat-avatar" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">

                    <div>
                        
                        <!-- 昵称 -->
                        <div class="chat-nickname-box">
                            
                            <!-- 普通用户 -->
                            <h3 v-if="checkVip(item.username) == '普通用户'" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- 普通会员 -->
                            <h3 v-if="checkVip(item.username) == 'vip'" @click="vip_click($event)" style="color: #ff0000;" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- pro会员 -->
                            <h3 v-if="checkVip(item.username)  == 'pro'" style="padding-left: 8px;" class="pro-nickname">{{ item.nickname }} <a href="#" @click="vip_click($event)"> 嚣张的摸鱼超级股东</a> </h3>
    
                            

                            <div class="chat-badge">
                                <template v-for="(badge, badgeIndex) in checkIdAttributes(item.username)" :key="badgeIndex">
                                    <img v-if="badge === 'vip'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸鱼股东徽章">
                                    <img v-if="badge === 'pro'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="超级摸鱼股东徽章">
                                    <img v-if="badge === 'clock'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="连续打卡徽章">
                                    <img v-if="badge === 'message'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="水群狂魔徽章">
                                    <img v-if="badge === 'age'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸龄1年徽章">
                                </template>
                                
                            </div>
                        </div>
                        
                        
                        <!-- 消息体 -->
                        <div class="chat-bqb-content">
                            <img :src="'https://mychat.bqb.zhuayuya.com'+item.json_msg.emoticon_url" alt="">
                            <div class="msg-warn">
                                <el-icon v-if="item.msg_id === ''"><Loading /></el-icon>
                                <span v-if="item.msg_id === '发送失败'">失败</span>
                            </div>
                        </div>


                        <!-- 互动 -->
                        <div v-if="item.interact && item.interact.length > 0" class="chat-interact-box">
                            <template 
                                v-for="(interact, subindex) in deduplicateAndCount(item.interact)" 
                                :key="subindex" 
                            >
                                <el-popover
                                    placement="top-start"
                                    :width="120"
                                    trigger="hover"
                                    content="this is content, this is content, this is content"
                                >
                                    <template #reference>
                                        <div class="chat-interact" @click="sendInteract(item.msg_id, interact.emoticon_id, interact.url, index)" >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                            <span>+{{ interact.count }}</span>
                                        </div>
                                    </template>

                                    <template #default>
                                        <img
                                            style="width: 120px; height: 120px; object-fit: cover; border-radius: 5px;"
                                        :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                    </template>
                                </el-popover>
                            </template>
                        </div>


                    </div>

                    <!-- 操作 -->
                    <div ref="chat_operation" class="chat-operation">
                        <div class="chat-operation-content">
                            <el-popover
                                placement="bottom"
                                title="与消息互动"
                                :width="310"
                                trigger="hover"
                                @show="() => {
                                    chat_operation[index].style = 'display: block';
                                    chat_border[index].style = 'background: #fff;';
                                    data.interactVisible = true;
                                    if(data.interactEmoticons.length === 0){
                                        getInteractEmoticons()
                                    }
                                }"
                                @hide="chat_operation[index].style = ''; chat_border[index].style = ''; data.interactVisible = false;"
                            >
                                <template #reference>
                                    <span>☺️互动</span>
                                </template>

                                <template #default>
                                    <ul v-if="data.interactVisible" class="chat-interact-popup">
                                        <li 
                                            v-for="(emoticon, subsubindex) in data.interactEmoticons" 
                                            :key="subsubindex" 
                                            @click="sendInteract(item.msg_id, emoticon.emoticon_id, emoticon.url, index)"
                                        >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+emoticon.url" alt="">
                                        </li>

                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </ul>
                           
                                </template>
                            </el-popover>
                            
                            <span @click="() => {
                                data.reportForm = {
                                    visible: true,
                                    msg_id: item.msg_id,
                                    reason: '',
                                    content: item.json_msg.emoticon_id + '：' + item.json_msg.emoticon_url + '：' + item.json_msg.emoticon_name
                                }
                            }">🙋举报</span>
                        </div>
                    </div>
                </li>

                <!-- 自定义消息 -->
                <li v-if="item.type === 'custom'" ref="chat_border" class="chat-custom chat">
                    <img class="chat-avatar" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">

                    <div>
                        <!-- 昵称 -->
                        <div class="chat-nickname-box">
                            
                            <!-- 普通用户 -->
                            <h3 v-if="checkVip(item.username) == '普通用户'" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- 普通会员 -->
                            <h3 v-if="checkVip(item.username) == 'vip'" @click="vip_click($event)" style="color: #ff0000;" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- pro会员 -->
                            <h3 v-if="checkVip(item.username)  == 'pro'" style="padding-left: 8px;" class="pro-nickname">{{ item.nickname }} <a href="#" @click="vip_click($event)"> 嚣张的摸鱼超级股东</a> </h3>
    
                            

                            <div class="chat-badge">
                                <template v-for="(badge, badgeIndex) in checkIdAttributes(item.username)" :key="badgeIndex">
                                    <img v-if="badge === 'vip'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸鱼股东徽章">
                                    <img v-if="badge === 'pro'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="超级摸鱼股东徽章">
                                    <img v-if="badge === 'clock'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="连续打卡徽章">
                                    <img v-if="badge === 'message'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="水群狂魔徽章">
                                    <img v-if="badge === 'age'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸龄1年徽章">
                                </template>
                                
                            </div>
                        </div>
                        
                        <!-- 消息体 -->
                        <div class="chat-custom-content">
                            <div style="margin-top: 10px;" v-html="item.msg"></div>
                            <div class="msg-warn">
                                <el-icon v-if="item.msg_id === ''"><Loading /></el-icon>
                                <span v-if="item.msg_id === '发送失败'">失败</span>
                            </div>
                        </div>

                        <!-- 互动 -->
                                                <div v-if="item.interact && item.interact.length > 0" class="chat-interact-box">
                            <template 
                                v-for="(interact, subindex) in deduplicateAndCount(item.interact)" 
                                :key="subindex" 
                            >
                                <el-popover
                                    placement="top-start"
                                    :width="120"
                                    trigger="hover"
                                    content="this is content, this is content, this is content"
                                >
                                    <template #reference>
                                        <div class="chat-interact" @click="sendInteract(item.msg_id, interact.emoticon_id, interact.url, index)" >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                            <span>+{{ interact.count }}</span>
                                        </div>
                                    </template>

                                    <template #default>
                                        <img
                                            style="width: 120px; height: 120px; object-fit: cover; border-radius: 5px;"
                                        :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                    </template>
                                </el-popover>
                            </template>
                        </div>


                    </div>

                    <!-- 操作 -->
                    <div ref="chat_operation" class="chat-operation">
                        <div class="chat-operation-content">
                            <el-popover
                                placement="bottom"
                                title="与消息互动"
                                :width="310"
                                trigger="hover"
                                @show="() => {
                                    chat_operation[index].style = 'display: block';
                                    chat_border[index].style = 'background: #fff;';
                                    data.interactVisible = true;
                                    if(data.interactEmoticons.length === 0){
                                        getInteractEmoticons()
                                    }
                                }"
                                @hide="chat_operation[index].style = ''; chat_border[index].style = ''; data.interactVisible = false;"
                            >
                                <template #reference>
                                    <span>☺️互动</span>
                                </template>

                                <template #default>
                                    <ul v-if="data.interactVisible" class="chat-interact-popup">
                                        <li 
                                            v-for="(emoticon, subsubindex) in data.interactEmoticons" 
                                            :key="subsubindex" 
                                            @click="sendInteract(item.msg_id, emoticon.emoticon_id, emoticon.url, index)"
                                        >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+emoticon.url" alt="">
                                        </li>

                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </ul>
                           
                                </template>
                            </el-popover>
                            
                            <span @click="() => {
                                data.reportForm = {
                                    visible: true,
                                    msg_id: item.msg_id,
                                    reason: '',
                                    content: item.json_msg.custom_content
                                }
                            }">🙋举报</span>
                        </div>
                    </div>
                </li>

                <!-- md消息 -->
                <li v-if="item.type === 'md'" ref="chat_border" class="chat-md chat">
                    <img class="chat-avatar" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">
                    <div>
                        <!-- 昵称 -->
                        <div class="chat-nickname-box">
                            
                            <!-- 普通用户 -->
                            <h3 v-if="checkVip(item.username) == '普通用户'" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- 普通会员 -->
                            <h3 v-if="checkVip(item.username) == 'vip'" @click="vip_click($event)" style="color: #ff0000;" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- pro会员 -->
                            <h3 v-if="checkVip(item.username)  == 'pro'" style="padding-left: 8px;" class="pro-nickname">{{ item.nickname }} <a href="#" @click="vip_click($event)"> 嚣张的摸鱼超级股东</a> </h3>

                            <div class="chat-badge">
                                <template v-for="(badge, badgeIndex) in checkIdAttributes(item.username)" :key="badgeIndex">
                                    <img v-if="badge === 'vip'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸鱼股东徽章">
                                    <img v-if="badge === 'pro'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="超级摸鱼股东徽章">
                                    <img v-if="badge === 'clock'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="连续打卡徽章">
                                    <img v-if="badge === 'message'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="水群狂魔徽章">
                                    <img v-if="badge === 'age'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸龄1年徽章">
                                </template>
                            </div>
                        </div>
                        

                        <!-- md消息 -->
                        <div style="display: flex;">
                            <article class="markdown-body" v-html="item.msg"></article>
                            <div class="msg-warn">
                                <el-icon v-if="item.msg_id === ''"><Loading /></el-icon>
                                <span v-if="item.msg_id === '发送失败'">失败</span>
                            </div>
                        </div>

                        <!-- 互动 -->
                        <div v-if="item.interact && item.interact.length > 0" class="chat-interact-box">
                            <template 
                                v-for="(interact, subindex) in deduplicateAndCount(item.interact)" 
                                :key="subindex" 
                            >
                                <el-popover
                                    placement="top-start"
                                    :width="120"
                                    trigger="hover"
                                    content="this is content, this is content, this is content"
                                >
                                    <template #reference>
                                        <div class="chat-interact" @click="sendInteract(item.msg_id, interact.emoticon_id, interact.url, index)" >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                            <span>+{{ interact.count }}</span>
                                        </div>
                                    </template>

                                    <template #default>
                                        <img
                                            style="width: 120px; height: 120px; object-fit: cover; border-radius: 5px;"
                                        :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                    </template>
                                </el-popover>
                            </template>
                        </div>


                    </div>

                    <!-- 操作 -->
                    <div ref="chat_operation" class="chat-operation">
                        <div class="chat-operation-content">
                            <el-popover
                                placement="bottom"
                                title="与消息互动"
                                :width="310"
                                trigger="hover"
                                @show="() => {
                                    chat_operation[index].style = 'display: block';
                                    chat_border[index].style = 'background: #fff;';
                                    data.interactVisible = true;
                                    if(data.interactEmoticons.length === 0){
                                        getInteractEmoticons()
                                    }
                                }"
                                @hide="chat_operation[index].style = ''; chat_border[index].style = ''; data.interactVisible = false;"
                            >
                                <template #reference>
                                    <span>☺️互动</span>
                                </template>

                                <template #default>
                                    <ul v-if="data.interactVisible" class="chat-interact-popup">
                                        <li 
                                            v-for="(emoticon, subsubindex) in data.interactEmoticons" 
                                            :key="subsubindex" 
                                            @click="sendInteract(item.msg_id, emoticon.emoticon_id, emoticon.url, index)"
                                        >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+emoticon.url" alt="">
                                        </li>

                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </ul>
                           
                                </template>
                            </el-popover>
                            
                            <span @click="() => {
                                data.reportForm = {
                                    visible: true,
                                    msg_id: item.msg_id,
                                    reason: '',
                                    content: item.msg
                                }
                            }">🙋举报</span>
                        </div>
                    </div>
                </li>

                <!-- file消息 -->
                <li v-if="item.type === 'file'" ref="chat_border" class="chat-file chat">
                    <img class="chat-avatar" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">
                    <div>

                        <!-- 昵称 -->
                        <div class="chat-nickname-box">
                            
                            <!-- 普通用户 -->
                            <h3 v-if="checkVip(item.username) == '普通用户'" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- 普通会员 -->
                            <h3 v-if="checkVip(item.username) == 'vip'" @click="vip_click($event)" style="color: #ff0000;" class="chat-nickname">{{ item.nickname }}</h3>

                            <!-- pro会员 -->
                            <h3 v-if="checkVip(item.username)  == 'pro'" style="padding-left: 8px;" class="pro-nickname">{{ item.nickname }} <a href="#" @click="vip_click($event)"> 嚣张的摸鱼超级股东</a> </h3>
                            
                            
                            <div class="chat-badge">
                                <template v-for="(badge, badgeIndex) in checkIdAttributes(item.username)" :key="badgeIndex">
                                    <img v-if="badge === 'vip'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸鱼股东徽章">
                                    <img v-if="badge === 'pro'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="超级摸鱼股东徽章">
                                    <img v-if="badge === 'clock'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="连续打卡徽章">
                                    <img v-if="badge === 'message'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="水群狂魔徽章">
                                    <img v-if="badge === 'age'" src="https://mychat.bqb.zhuayuya.com/bqb/万恶vtb/72104f1ab294919b12925486bba2b5f08119f961.jpg476w_248h.jpg" alt="" title="摸龄1年徽章">
                                </template>
                            </div>
                        </div>
                        

                        <!-- 文件消息 -->
                        <div style="display: flex;">
                            <a :href="stores.config.port + '/chatFiles/'+item.json_msg.file_url" target="_blank" class="chat-file-content">
                                <i>{{ item.json_msg.format }}</i>
                                <div>
                                    <h5>{{ item.json_msg.file_name }}</h5>
                                    <p>{{  formatFileSize(item.json_msg.size) }}</p>
                                </div>
                            </a>
                            <div class="msg-warn">
                                <el-icon v-if="item.msg_id === ''"><Loading /></el-icon>
                                <span v-if="item.msg_id === '发送失败'">失败</span>
                            </div>
                        </div>

                        <!-- 互动 -->
                        <div v-if="item.interact && item.interact.length > 0" class="chat-interact-box">
                            <template 
                                v-for="(interact, subindex) in deduplicateAndCount(item.interact)" 
                                :key="subindex" 
                            >
                                <el-popover
                                    placement="top-start"
                                    :width="120"
                                    trigger="hover"
                                    content="this is content, this is content, this is content"
                                >
                                    <template #reference>
                                        <div class="chat-interact" @click="sendInteract(item.msg_id, interact.emoticon_id, interact.url, index)" >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                            <span>+{{ interact.count }}</span>
                                        </div>
                                    </template>

                                    <template #default>
                                        <img
                                            style="width: 120px; height: 120px; object-fit: cover; border-radius: 5px;"
                                        :src="'https://mychat.bqb.zhuayuya.com'+interact.url" alt="">
                                    </template>
                                </el-popover>
                            </template>
                        </div>



                    </div>

                    <!-- 操作 -->
                    <div ref="chat_operation" class="chat-operation">
                        <div class="chat-operation-content">
                            <el-popover
                                placement="bottom"
                                title="与消息互动"
                                :width="310"
                                trigger="hover"
                                @show="() => {
                                    chat_operation[index].style = 'display: block';
                                    chat_border[index].style = 'background: #fff;';
                                    data.interactVisible = true;
                                    if(data.interactEmoticons.length === 0){
                                        getInteractEmoticons()
                                    }
                                }"
                                @hide="chat_operation[index].style = ''; chat_border[index].style = ''; data.interactVisible = false;"
                            >
                                <template #reference>
                                    <span>☺️互动</span>
                                </template>

                                <template #default>
                                    <ul v-if="data.interactVisible" class="chat-interact-popup">
                                        <li 
                                            v-for="(emoticon, subsubindex) in data.interactEmoticons" 
                                            :key="subsubindex" 
                                            @click="sendInteract(item.msg_id, emoticon.emoticon_id, emoticon.url, index)"
                                        >
                                            <img :src="'https://mychat.bqb.zhuayuya.com'+emoticon.url" alt="">
                                        </li>

                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </ul>
                           
                                </template>
                            </el-popover>
                            
                            <span @click="() => {
                                data.reportForm = {
                                    visible: true,
                                    msg_id: item.msg_id,
                                    reason: '',
                                    content: item.json_msg.file_name +': '+ item.json_msg.file_url
                                }
                            }">🙋举报</span>
                        </div>
                    </div>
                </li>
            </template>
        </ul>

        <Online />
    </div>
    <Input />
</template>

<style scoped>
.msg-warn{
    font-size: 12px;
    color: red;
}
.msg-warn{
    display: flex;
    align-items: center;
    margin-left: 5px;
}
.chat-file-content p{
    margin-top: 14px;
    font-size: 12px;
    color: #b5bac1;
}
.chat-file-content h5{
    width: 138px;
    font-size: 15px;
    color: #333;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.chat-file-content i{
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: #5daecf;
    margin-right: 10px;
    font-size: 17px;
    font-weight: 600;
    color: #efefef;
    margin-left: 10px;
}
.chat-file-content{
    display: flex;
    width: 220px;
    height: 72px;
    background: #ffffff;
    margin-top: 10px;
    align-items: center;
    border-radius: 8px;
    cursor: pointer;
    text-decoration: none;
    border: 1px solid #ebebeb;
}
.chat-file-content:hover{
    background: #f8f8f8;
}

/* pro消息样式 */
.chat-content-pro{
    position: relative;
}
.chat-content-pro img{
    position: absolute;
    width: 50px;
    top: -28px;
    left: 3px;
}

.chat-content-pro p{
    background: linear-gradient(271deg, #ffd175 -9%, #e89e3e 99%) !important;
    border: 1px solid #ed9f10 !important;
    box-shadow: -2px 4px 12px #1051650d !important;
    color: #5b3d05 !important;
}
.chat-content-pro p{
    padding-left: 52px !important;
}
/* 结束↑↑↑↑↑↑ */



/* pro会员昵称样式 */
.pro-nickname{
    border-radius: 16px;
    color: #513a06 !important;
    font-weight: bold;
    padding: 4px 8px;
    font-size: 14px;
    padding-left: 38px;
    background: linear-gradient(271deg, #ffda91 -9%, #f7ab40 99%);
    position: relative;
    display: inline-block;
    border: none;
    overflow: hidden;
    transition: color 0.3s ease;
}

.pro-nickname:hover {
    color: #ffffff  !important;
}

/* 伪元素实现背景动画 */
.pro-nickname::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 300%;
    height: 100%;
    background: linear-gradient(120deg, rgb(255, 166, 0), rgb(225, 255, 0), rgb(255, 55, 0));
    transition: transform 0.3s ease;
    z-index: 0;
    transform: translateX(-100%);
    opacity: .5;
    pointer-events: none;
}

.pro-nickname:hover::before {
    transform: translateX(0);
    animation: flow 2s linear infinite;
}

/* 按钮文字层 */
.pro-nickname span {
    position: relative;
    z-index: 1;
}
.pro-nickname a{
    color: #8b4513;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
}

/* 背景水流动动画 */
@keyframes flow {
    0% {
    background-position: 0% 50%;
    }
    100% {
    background-position: 200% 50%;
    }
}
/* 结束↑↑↑↑↑↑ */






.chat-badge img{
    width: 15px;
    height: 15px;
    border-radius: 20px;
    object-fit: cover;
    margin-left: 6px;
    border: 2px solid #fff;
}
.chat-badge{
    display: flex;
}
.chat-nickname-box{
    display: flex;
    align-items: center;
    margin-top: 6px;
}




.chat-interact-popup li img{
    max-width: 58px;
    height: 58px;
    object-fit: cover;
}
.chat-interact-popup i{
    width: 66px;
}
.chat-interact-popup li{
    width: 66px;
    height: 66px;
    margin-top: 6px;
    /* margin-right: 10px; */
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
    cursor: pointer;
}
.chat-interact-popup li:hover{
    background: #eaeaea;
}
.chat-interact-popup{
    max-height: 228px;
    width: 100%;
    overflow: auto;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}
.chat-interact-box div span{
    font-size: 12px;
    color: #b5bac1;
    font-weight: 600;
}
.chat-interact-box div img{
    width: 20px;
    height: 20px;
    margin-right: 5px;
    border-radius: 5px;
    /* background: #b5bac1; */
    object-fit: cover;
}
.chat-interact-box div {
    height: 28px;
    display: flex;
    align-items: center;
    background: #ffffff;
    border: 1px solid #ebebeb;
    border-radius:5px;
    padding-left: 6px;
    padding-right: 6px;
    margin-right: 6px;
    margin-bottom: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
}
.chat-interact-box div:hover{
    background: #f8f8f8;
}
.chat-interact-box{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    margin-top: 5px;
}
.chat-custom-content{
    display: flex;
}
.chat-image-content-img{
    border-radius: 8px;
    object-fit: cover;
    margin-top: 10px;
}
.chat-image{
    max-height: 450px;
}
.chat-bqb-content img{
    max-height: 200px;
    border-radius: 8px;
    object-fit: cover;
    margin-top: 10px;
}
.chat:hover .chat-report{
    display: block;
}
.chat-report:hover{
    color: #ff5722;
}
.chat-report{
    font-size: 12px;
    color: #a3a3a3;
    display: block;
    margin-top: 12px;
    margin-left: 6px;
    display: none;
    cursor: pointer;
}
.chat-app-content h6{
    width: 260px;
    font-size: 13px;
    color: #3597f3;
    margin-top: 13px;
    border-top: 1px solid #e9e9e9;
    padding-top: 12px;
    /* 超出省略号 */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.chat-app-content p{
    width: 190px;
    margin-right: 10px;
    font-size: 13px;
    color: #8b8b8b;
    line-height: 18px;
    /* 最多三行超出... */
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.chat-app-content img{
    width: 50px;
    height: 50px;
    border-radius: 10px;
}
.chat-app-content h3{
    font-size: 16px;
    font-weight: 500;
    line-height: 1.4;
    margin-bottom: 10px;
    color: #333;
}
.chat-app-content{
    width: 260px;
    background: #fff;
    padding: 13px;
    border-radius: 8px;
    box-shadow: 0 0 10px #1051650d;
    margin-top: 10px;
    text-decoration: none;
}
.chat-text p{
    max-width: 100%;
    padding: 3px 10px;
    white-space: pre-wrap;
    word-break: break-all;
    line-height: 28px;
    font-size: 13px;
    font-weight: 400;
    background: #ffffff;
    border: 1px solid #dbdbdb;
    box-shadow: -2px 4px 12px #1051650d;
    border-radius: 3px 8px 8px;
    color: #525252;
    margin-bottom: 0;
    margin-top: 10px;
}
.chat-nickname{
    display: inline-block;
    font-size: 12px;
    color: #999;
}
.chat-avatar{
    width: 40px;
    height: 40px;
    margin-right: 6px;
    margin-top: 5px;
    border-radius: 10px;
    object-fit: cover;
    background: #d3d3d3;
}
.chat-operation-content span{
    color: #333;
    font-size: 12px;
    padding: 5px;
    margin-left: 5px;
    background: #efefef;
    border-radius: 3px;
    cursor: pointer;
    display: flex;
    align-items: center;
}
.chat-operation-content span:hover{
    background: #e3e3e3;
}
.chat-operation-content span{
    display: block;
    height: 12px;
}
.chat-operation-content{
    display: flex;
    align-items: center;
    height: 100%;
}
.chat-operation{
    border-radius: 7px;
    width: 116px;
    height: 32px;
    background: #ffffff;
    border: 1px solid #dbdbdb;
    box-shadow: 0 5px 15px rgba(0, 0, 0, .1);
    position: absolute;
    bottom: -15px;
    right: 20px;
    display: none;
}
.chat{
    display: flex;
    margin-bottom: 6px;
    padding:6px 5px;
    position: relative;
}
.chat:hover{
    background: #ffffff;
    border-radius: 5px;
}
.chat:hover .chat-operation{
    display: block;
}
.chat-box ul{
    width: calc(100% - 220px);
    height: calc(100% - 20px);
    padding: 10px;
    overflow: auto;
}
.chat-box{
    height: calc(100% - 220px);
    display: flex;
}
::-webkit-scrollbar{
    width: 6px;
}
::-webkit-scrollbar-thumb{
    background: #c3c4c7;
    border-radius: 3px;
}

@media (max-width: 750px) {
    .chat-image-content-img{
        width: 95% !important;
        height: 300px !important;
        border-radius: 8px;
        object-fit: cover;
        margin-top: 10px;
    }
    .chat-image-content-img img{
        width: 100% !important;
        height: 100% !important;
    }
    .chat-app-content{
        width: 200px;
    }
    .chat-app-content h6{
        width: 200px;
    }
}
@media (max-width: 880px) {
    .chat-box ul{
        width: 100%;
    }
}
</style>
