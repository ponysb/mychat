<script setup>
import { ref, reactive, watchEffect } from "vue";
import { useMainStore } from "../../store/index";
import { useRoute } from "vue-router";
import Axios from '../../../utils/request';
const stores = useMainStore();
const route = useRoute();
const data = reactive({
    online_users: 100,
    isLoading: false,
    room_online: [],  // 在线房间用户列表
    room_offline: '加载中...',  // 离线房间用户列表
})



// 获取在线用户列表
function get_online_users() {

    Axios.post('/api/v1/chats/getRoomUsers', {
        room_id: route.params.id,
    })
    .then(response => {
        // console.log(response.data.users)
        data.room_online = response.data.online;
        data.room_offline = response.data.offline;
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}

// 监听滚轮，滚到底部加载更多用户
let onlineBox = ref(null);
// 监听滚轮事件
function handleWheel(e) {
    const scrollTop = onlineBox.value.scrollTop; // 当前滚动位置
    const clientHeight = onlineBox.value.clientHeight; // 可视区域高度
    const scrollHeight = onlineBox.value.scrollHeight; // 内容区域高度

    // 判断是否滚动到底部
    if (scrollTop + clientHeight >= scrollHeight - 10) { // 可以根据实际情况调整 10 的值
        // console.log('滚动到底部');
        loadMoreUsers(); // 滚动到底部时，加载更多数据
    }
}


// 加载更多用户的函数
function loadMoreUsers() {
    // 防止重复加载
    if (data.isLoading) return;

    data.isLoading = true;

    // 模拟异步加载数据（如从 API 获取）
    setTimeout(() => {
        data.online_users += 100; // 加载更多用户
        // 这里添加新的用户数据

        data.isLoading = false; // 加载完成后，允许再次加载
    }, 500); // 1秒模拟加载时间
}


watchEffect(() => {
    const room_id = route.params.id
    if (room_id) {
        get_online_users()
    }
})

</script> 

<template>
    <div ref="onlineBox" @wheel="handleWheel" class="online-box">
        <div class="online-content">
            <h1>在线用户 — {{ data.room_online.length }}<i class="online"></i></h1>
            <ul>
                <li v-for="(item, index) in data.room_online" :key="index">
                    <img :src="stores.config.port + '/api/v1/users/getUserAvatar/'+item.username" alt="">
                    <span>{{item.nickname}}</span>
                    <i class="online"></i>
                </li>
            </ul>

            <h1>离线用户 — {{ data.room_offline }}<i class="away"></i></h1>
            <!-- <ul>
                <li v-for="(item, index) in stores.room_offline.slice(0, data.online_users)" :key="index">
                    <span>{{item.nickname}}</span>
                    <i v-if="item.online" class="online"></i>
                    <i v-if="!item.online" class="away"></i>
                </li>
            </ul> -->
        </div>
        
    </div>
</template>

<style scoped>
.away{
    display: block;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    margin-left: 6px;
    background: #818181;
}
.online{
    display: block;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    margin-left: 6px;
    background: #27c459;
}
.online-content h1{
    display: flex;
    align-items: center;
}
.online-box img{
    width: 30px;
    height: 30px;
    border-radius: 50%;
    object-fit: cover;
}
.online-box ul li span{
    width: 80%;
    margin-left: 8px;
    font-size: 15px;
    color: #949ba4;
    /* 超出长度省略 */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.online-box ul li{
    display: flex;
    align-items: center;
    margin-bottom: 12px;
    line-height: 1.3;
}
.online-box ul{
    margin-top: 16px;
}
.online-box h1{
    font-size: 14px;
    font-weight: 600;
    letter-spacing: .5px;
    color: #949ba4;
}
.online-content{
    padding: 16px;
}
.online-box{
    width: 220px;
    height: 100%;
    background: #f7f7f7;
    border-left: 1px solid #e8e8e8;
    overflow: auto;
}

@media screen and (max-width: 880px) {
    .online-box{
        display: none;
    }
}
</style>