<template>
    <div class="not-found-container">
      <!-- 插图 -->
      <div class="illustration">💬</div>
  
      <!-- 标题 -->
      <h1 class="title">404</h1>
      <p class="subtitle">哎呀，页面不见了！</p>

      <p id="timer">将在 <span id="countdown">3</span> 秒后跳转到首页...</p>
  
      <!-- 返回首页按钮 -->
      <router-link to="/" class="home-button">返回首页</router-link>
    </div>
  </template>
  
  <script setup>
  import { onMounted } from 'vue';
  onMounted(() => {
       // 设置倒计时并进行跳转
       let countdown = 3;
    const countdownElement = document.getElementById('countdown');

    const timer = setInterval(() => {
        countdown--;
        countdownElement.textContent = countdown;

        if (countdown <= 0) {
            clearInterval(timer);
            window.location.href = '/';
        }
    }, 1000);
  })

  </script>
  
  <style scoped>
  #timer{
    margin-bottom: 30px;
  }
  /* 容器样式 */
  .not-found-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background: linear-gradient(135deg, #b7e4f2, #409eff);
    color: white;
    font-family: Arial, sans-serif;
    text-align: center;
  }
  
  /* 插图样式 */
  .illustration {
    font-size: 100px;
    margin-bottom: 20px;
  }
  
  /* 标题样式 */
  .title {
    font-size: 72px;
    font-weight: bold;
    margin: 0;
  }
  
  /* 副标题样式 */
  .subtitle {
    font-size: 24px;
    margin: 10px 0 16px;
  }
  
  /* 返回首页按钮样式 */
  .home-button {
    padding: 16px 38px;
    background: white;
    color: #409eff;
    text-decoration: none;
    border-radius: 25px;
    font-size: 15px;
    transition: background 0.3s ease, color 0.3s ease;
  }
  
  .home-button:hover {
    background: #ececec;
    color: #409eff;
  }
  </style>