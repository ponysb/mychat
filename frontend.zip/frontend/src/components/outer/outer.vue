<script setup>
import Axios from '../../../utils/request';
import { useRoute, useRouter } from 'vue-router';
import { useMainStore } from "../../store/index";
const stores = useMainStore();
const route = useRoute();
const router = useRouter();
// eyJ1c2VyX2lkIjoiNDg4MCIsIm5pY2tuYW1lIjoiUG9ueeaJjeaYr-ecn-ato-eahOeuoeeQhiIsImVtYWlsIjoiMTA5MDg3OTExNUBxcS5jb20ifQ
// http://localhost:5173/outer?zhuayuya=eyJ1c2VyX2lkIjoiNDg4MCIsIm5pY2tuYW1lIjoiUG9ueeaJjeaYr-ecn-ato-eahOeuoeeQhiIsImVtYWlsIjoiMTA5MDg3OTExNUBxcS5jb20ifQ
zhuayuyaCheck()
function zhuayuyaCheck(){
    let zhuayuya = route.query.zhuayuya
    if(zhuayuya){
        try {
            let zhuayuyaToJson = decodeFromURL(zhuayuya)
            console.log(zhuayuyaToJson)

            if(!zhuayuyaToJson.email||!zhuayuyaToJson.nickname||!zhuayuyaToJson.user_id){
                console.log('zhuayuya参数不完整')
                router.push({path: '/login'})
                return
            }

            Axios.post('/api/v1/users/zhuayuya_check', {
                username: zhuayuyaToJson.user_id,
                nickname: zhuayuyaToJson.nickname,
                email: zhuayuyaToJson.email,
            })
            .then(response => {
                console.log(response)
                localStorage.setItem('mychatToken', response.data.token)
                router.push({path: '/'})
            })
            .catch(error => {
                console.log(error)
                // 解析错误，跳转到登录页面
                router.push({path: '/login'});
            });
            
        } catch (error) {
            console.log(error)
            // 解析错误，跳转到登录页面
            router.push({path: '/login'});
        }

    }else{
        // 没有token也没有zhuayuya参数，跳转到登录页面
        router.push({path: '/login'});
    }

}


// 解码
function decodeFromURL(base64String) {
    // 将 URL 安全的 Base64 字符串还原回标准的 Base64 格式
    let base64StringRestored = base64String.replace(/-/g, '+').replace(/_/g, '/');

    // 使用 atob 解码 Base64 字符串
    let decodedStr = atob(base64StringRestored);

    // 将解码后的字节字符串转换为字节数组
    let byteArray = new Uint8Array(decodedStr.split('').map(char => char.charCodeAt(0)));

    // 使用 TextDecoder 将字节数组转换回 UTF-8 字符串
    let decoder = new TextDecoder('utf-8');
    let jsonString = decoder.decode(byteArray);

    // 将字符串转换为 JSON 对象
    return JSON.parse(jsonString);
}
</script>

<template>
    <div class="outer"></div>
</template>