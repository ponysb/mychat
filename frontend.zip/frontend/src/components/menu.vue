<script setup>
import { useRouter, useRoute } from "vue-router";
import { useMainStore } from "../store/index";
import { IconPark } from '@icon-park/vue-next/es/all';
import { reactive } from "vue";
import Axios from '../../utils/request';
const stores = useMainStore();
const Router = useRouter();
const Route = useRoute();


const data = reactive({
    // 股东
    stockholder: {
        visible: false,
        goods: '摸鱼股东',
        out_trade_no: '',
        qrcode: ''
    },

    // 签到信息
    SignInfo:{
        today: true,
		continuous: 1
    }
})

// 点击成为股东
function becomeStockholder(goods) {
    data.stockholder.qrcode = ''

    Axios.post('/api/v1/pay/jsapi_wxpay', {
        goods: goods
    })
    .then(response => {
        // console.log(response)
        if(response.code === 200){
            data.stockholder.qrcode = response.data.QRcode_url
            data.stockholder.out_trade_no = response.data.out_trade_no
        }
    })
    .catch(error => {
        console.log(error)
    });

}


// 轮询订单状态
function checkOrderStatus() {
    Axios.post('/api/v1/pay/order', {
        out_trade_no: data.stockholder.out_trade_no
    })
    .then(response => {
        // console.log(response)
        if(response.message === 'success'){
            ElMessage({
                message: '入股成功，恭喜成为尊贵的摸鱼股东，刷新页面查看状态！',
                type: 'success',
            })
            stores.stockholder.visible = false
            data.stockholder.qrcode = ''
            data.stockholder.out_trade_no = ''
        }else{
            ElMessage({
                message: '未查询到入股信息，系统可能有延迟，请支付后30秒再试！',
                type: 'warning',
            })
        }
    })
    .catch(error => {
        console.log(error)
    });
}


// 点击用户头像
function user_click() {
    if(stores.user.username === ''){
        stores.login.visible = true
    }else{
        stores.drawer.visible = true
    }
}

// 点击内置浏览器
function browserChange() {
    if(stores.browser.tabs.length === 0){
        ElMessage({
            message: '当前没有打开的网站，可以在应用里打开一个网站后再试！',
            type: 'info',
        })
    }else{
        stores.browser.visible = true
    }
}


// 切换菜单
function switchMenu(type) {
    if(type === 'app'){
        Router.push({path: '/'+type})
    }else{
        Router.push({path:`/${type}/${stores.rooms[0].room_id}`})
    }
    
}


// 获取签到信息
function getSignInfo() {
    Axios.post('/api/v1/timed/getSignData', {})
    .then(response => {
        data.SignInfo.today = response.data.today
        data.SignInfo.continuous = response.data.continuous
    })
    .catch(error => {
        console.log(error)
    });

}


// 切换简洁模式
function Terminal() {
    if(Route.name === 'chat'){
        stores.terminal = true
    }else{
        ElMessage.error('切换到房间页面后才能切换到简洁模式哦~')
    }

}

 
</script>

<template>

<el-dialog
    v-model="stores.stockholder.visible"
    title="助力摸鱼聊天室"
    width="500"
>
    <div>
        <div class="sponsor-box">
            <h1>特殊赞助：</h1>
            <div class="sponsor-list">
                <a href="https://www.asiayun.com/aff/SANETFVH" target="_blank">
                    <div>
                        <img src="../assets/menu/asiayun.png" alt="">
                        <h3>亚洲云</h3>
                    </div>
                    <p>提供的服务器赞助</p>
                </a>
                
                <a href="https://www.tsyvps.com/aff/HSEDOWWY" target="_blank">
                    <div>
                        <img src="../assets/menu/lanyiyun.png" alt="">
                        <h3>蓝易云</h3>
                    </div>
                    <p>提供的高防CDN赞助</p>
                </a>
            </div>
        </div>
        <p style="font-size: 13px; color: #333; line-height: 1.5; color: #ff0000; margin-top: 10px;">摸鱼聊天室的长久运营离不开各位股东们的鼎力支持，为摸鱼事业助力，会吸取各位股东提出的建议来完善摸鱼事业，感谢支持！</p>
        
        <!-- 分割线 -->
        <div style="height: 1px; background: #e1e1e1; margin: 10px 0;"></div>

        <el-radio-group v-model="data.stockholder.goods" size="large">
            <el-radio-button label="摸鱼股东" value="摸鱼股东" />
            <el-radio-button label="超级摸鱼股东" value="超级摸鱼股东" />
            <el-radio-button label="合作赞助" value="合作赞助" />
        </el-radio-group>

        <div style="margin-top: 10px;" v-if="data.stockholder.goods === '摸鱼股东'">
            <p
                style="color: #333; font-size: 13px; line-height: 1.5; padding: 10px; background: #f0f0f0;"
            >赋予您摸鱼股东头衔，并加入摸鱼股东交流群，股东赞助名单，还有<a href="https://vip.zhuayuya.com/" target="_blank">更多福利</a>可以选择</p>

            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="margin-top: 16px; display: flex;">
                    <span style="font-size: 18px; color: #a85f07; font-weight: 600;">68元/永久</span>
                    <span style="margin-left: 10px; font-size: 13px; color: #07c160; margin-top: 3px; display: flex; align-items: center;">
                        <icon-park type="wechat" theme="filled" size="16" fill="#09bb07"/>
                        微信支付
                    </span>
                </div>
                <el-button type="primary" style="margin-top: 10px;" @click="becomeStockholder('摸鱼股东')">成为股东</el-button>
            </div>
        </div>

        <div style="margin-top: 10px;" v-if="data.stockholder.goods === '超级摸鱼股东'">
            <p
                style="color: #333; font-size: 13px; line-height: 1.5; padding: 10px; background: #f0f0f0;"
            >赋予您超级摸鱼股东头衔，并加入摸鱼股东交流群，股东赞助名单，还有<a href="https://vip.zhuayuya.com/" target="_blank">更多福利</a>可以选择</p>
        
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="margin-top: 16px; display: flex;">
                    <span style="font-size: 18px; color: #a85f07; font-weight: 600;">88元/永久</span>
                    <span style="margin-left: 10px; font-size: 13px; color: #07c160; margin-top: 3px; display: flex; align-items: center;">
                        <icon-park type="wechat" theme="filled" size="16" fill="#09bb07"/>
                        微信支付
                    </span>
                </div>
                <el-button type="primary" style="margin-top: 10px;" @click="becomeStockholder('超级摸鱼股东')">成为超级股东</el-button>
            </div>
        </div>

        <div style="margin-top: 10px;" v-if="data.stockholder.goods === '合作赞助'">
            <p
                style="color: #333; font-size: 13px; line-height: 1.5; padding: 10px; background: #f0f0f0;"
            >如果您是某品牌商家，可以通过赞助来获得摸鱼聊天室广告位，详情加开发者微信沟通，<a href="https://home.zhuayuya.com/docs/%E8%81%94%E7%B3%BB%E6%88%91%E4%BB%AC.html" target="_blank">获取微信点我</a></p>
        </div>

        <div style="margin-top: 10px;">
            <el-button size="small" type="primary" style="display: block; margin-bottom: 6px;" v-if="data.stockholder.qrcode!== ''" @click="checkOrderStatus">我已支付</el-button>
            <img style="width: 150px; height: 150px;" v-if="data.stockholder.qrcode!== ''" :src="data.stockholder.qrcode" alt="">
        </div>
    </div>
</el-dialog>

<div class="menu-box">
    <div class="logo-box">
        <a rel="nofollow" href="javascript:
            (function() {
                var url = window.location.href;
                var videoReg = /^https?:\/\/(www\.)?(iqiyi\.com|youku\.com|v\.qq\.com).*/i;
                if (videoReg.test(url)) {
                    window.open('https://jx.playerjy.com/?url=' + encodeURIComponent(url));
                } else {
                    alert('当前链接不支持视频解析，仅支持爱奇艺、优酷、腾讯视频');
                }
            })();" 
        target="_blank">
        <img src="../assets/logo.svg" title alt="🎬 视频解析">
    </a>
    </div>


    <ul class="menu-list">
        <template v-for="(item, index) in stores.menu.menu_list" :key="index">
            <li @click="switchMenu(item.type)" v-if="item.type != 'browser'">
                <i :class="{'active': item.type === Route.name}"><img :src="item.icon" alt=""></i>
                <span>{{item.name}}</span>
            </li>

            <li @click="browserChange" v-else>
                <i><img :src="item.icon" alt=""></i>
                <span>{{item.name}}</span>
            </li>
        </template>
    </ul>

    
    <ul class="menu-button">
        <li @click="Terminal">
            <i><img src="../assets/menu/terminal.svg" alt=""></i>
            <span>简洁模式</span>
        </li>

        <el-popover
            placement="right"
            :width="175"
            trigger="hover"
        >
            <template #reference>
                <li>
                    <i><img src="../assets/menu/wxqrcode.svg" alt=""></i>
                    <span>公众号</span>
                </li>
            </template>

            <template #default>
                <img style="width: 150px;" src="../assets/menu/qrcode.jpeg" alt="">
            </template>
        </el-popover>


        <el-tooltip
            class="box-item"
            effect="light"
            trigger="click"
            :content="'发送一条消息签到，今日'+ (data.SignInfo.today ? '已签到' : '未签到') + '，签到天数' + data.SignInfo.continuous + '天'"
            placement="right"
        >
            <!-- 鼠标移入 -->
            <li @click="getSignInfo">
                <i><img src="../assets/menu/qiandao.svg" alt=""></i>
                <span>签到</span>
            </li>
        </el-tooltip>


        <el-tooltip
            class="box-item"
            effect="light"
            content="摸鱼聊天室的成长离不开各位股东，感谢您的支持！"
            placement="right"
        >
            <li @click="stores.stockholder.visible = true">
                <i><img src="../assets/menu/gudong.svg" alt=""></i>
                <span>股东计划</span>
            </li>
        </el-tooltip>


        <li @click="user_click">
            <i v-if="stores.user.username === ''"><img src="../assets/menu/user.svg" alt=""></i>
            <i v-else><img :src="stores.config.port + '/api/v1/users/getUserAvatar/'+stores.user.username" alt=""></i>
            <span>{{ stores.user.username === '' ? '登录' : stores.user.username }}</span>
        </li>
    </ul>
</div>
</template>

<style scoped>
.sponsor-box h1{
    font-size: 16px;
    color: #333;
    font-weight: 600;
}
.sponsor-list{
    display: flex;
    margin-top: 10px;
    justify-content: space-between;
}
.sponsor-list a{
    width: calc(50% - 5px);
    height: 60px;
    border-radius: 6px;
    text-align: center;
    background: #cdf1f9;
    cursor: pointer;
    text-decoration: none;
}
.sponsor-list a div{
    display: flex;
    justify-content: center;
}
.sponsor-list a div img{
    width: 16px;
    height: 16px;
    margin-right: 5px;
    margin-top: 10px;
}
.sponsor-list a:hover{
    background: #b7e4f2;
}
.sponsor-list h3{
    display: block;
    margin-top: 10px;
    font-size: 15px;
    color: #076692;
    font-weight: 600;
}
.sponsor-list p{
    margin-top: 10px;
    font-size: 13px;
    color: #0d9ec6;
}


.menu-button img{
    width: 32px;
    height: 32px;
    border-radius: 6px;
}
.menu-button i{
    width: 50px;
    height: 50px;
    background: #f0f0f0;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 auto;
    margin-top: 16px;
}
.menu-button span{
    display: block;
    margin-top: 8px;
    font-size: 12px;
    color: #878787;
}
.menu-button li{
    cursor: pointer;
}
.menu-button{
    margin-bottom: 20px;
    text-align: center;
}
.menu-list i{
    width: 50px;
    height: 50px;
    background: #f0f0f0;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 auto;
    margin-top: 16px;
}
.menu-list i:hover{
    background: #e1e1e1;
}
.active{
    background: #b7e4f2 !important;
    box-shadow: 0 5px 15px #02837633;
    outline: 3px solid #ffffff;
}
.menu-list span{
    display: block;
    margin-top: 8px;
    font-size: 12px;
    color: #878787;
}
.menu-list li{
    width: 100%;
    margin: 0 auto;
    text-align: center;
    cursor: pointer;
}
.menu-list img{
    width: 24px;
}
.menu-list{
    /* background: #676767; */
    height: 100%;
    overflow: auto;
}
.logo-box img{
    width: 42px;
    margin-top: 12px;
}
.logo-box{
    width: 100%;
    height: 98px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.menu-box{
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
</style>