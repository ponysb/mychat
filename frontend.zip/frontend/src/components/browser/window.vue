<script setup>
import { ref, reactive } from "vue";
import { useMainStore } from "../../store/index";
const stores = useMainStore();
const data = reactive({
    state: "最大化",
})

let windowContent = ref(null);

// 关闭窗口
function closeWindow() {
    stores.browser.visible = false;
}

// 最大化最小化窗口
function maxHeaderSize() {
    if (data.state === "最大化") {
        windowContent.value.style.width = "100%"
        windowContent.value.style.height = "100%"
        data.state = "恢复"
    }else{
        windowContent.value.style.width = ""
        windowContent.value.style.height = ""
        data.state = "最大化"
    }
}


// 最小化窗口
function minHeaderSize() {
    stores.browser.visible = false;
}

// 关闭标签页
function closeTab(index) {
    stores.browser.tabs.splice(index, 1);
    
    // 关闭当前标签页后，关闭窗口
    if (stores.browser.tabs.length === 0) {
        stores.browser.visible = false;
    }

    // 关掉自动切换到临近的
    if (index === stores.browser.select_tab) {
        if (index === stores.browser.tabs.length) {
            stores.browser.select_tab = index - 1;
        } else {
            stores.browser.select_tab = index;
        }
    }
}
</script>

<template>
    <div class="window" @click="closeWindow" v-if="stores.browser.visible">
        <div ref="windowContent" class="window-content" @click.stop>
            <div class="tabs-container">
                <ul class="tabs-box">

                    <li v-for="(item,index) in stores.browser.tabs" :title="item.desc" :class="{active: index === stores.browser.select_tab}" style="border-radius: 8px 0 0 0;">
                        <div @click="stores.browser.select_tab = index" style="display: flex; align-items: center;">
                            <img v-if="item.icon === ''||item.icon === undefined" :src="'https://icon.bqb.cool?url='+item.url" alt="">
                            <img v-else :src="'http://localhost:8080/app/'+item.icon" alt="">
                            <span>{{item.title}}</span>
                        </div>
                        <el-icon @click="closeTab(index)" class="close-icon"><Close /></el-icon>
                    </li>
                </ul>
                <!-- 状态栏 -->
                <div class="status-bar">
                    <el-icon @click="maxHeaderSize"><FullScreen /></el-icon>
                    <el-icon @click="minHeaderSize"><SemiSelect /></el-icon>
                </div>
            </div>

            <template v-for="(item,index) in stores.browser.tabs" :key="index">
                <iframe
                    v-show="index === stores.browser.select_tab"
                    style="width: 100%; height: 100%; border-radius: 0 0 8px 8px; border: none;" 
                    :src="item.url"
                ></iframe>
            </template>
            
        </div>
    </div>
</template>

<style scoped>
.status-bar .el-icon{
    margin-right: 12px;
    padding: 3px;
    cursor: pointer;
    transition: all 0.3s ease;
}
.status-bar .el-icon:hover{
    padding: 3px;
    background: #d3d3d3;
    border-radius: 3px;
}
.status-bar{
    height: 36px;
    display: flex;
    align-items: center;
}
.close-icon:hover{
    background: #d3d3d3;
    border-radius: 3px;
}
.tabs-box li span{
    max-width: 120px;
    font-size: 14px;
    margin-right: 12px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.tabs-box li img{
    width: 18px;
    height: 18px;
    margin-right: 6px;
}
.tabs-box li {
    max-width: 200px;
    height: 36px;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 10px;
    border-right: 1px solid #e5e5e5;
    cursor: pointer;
    flex-shrink: 0;
}
.active{
    background: #fff !important;
}
.tabs-box{
    width: calc(100% - 160px);
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    overflow-y: hidden;
}
.tabs-container{
    width: 100%;
    display: flex;
    justify-content: space-between;
}
.window-content {
    width: 1200px;
    height: 72%;
    background: #fff;
    box-shadow: 0px 12px 32px 4px rgba(0, 0, 0, .2), 0px 8px 20px rgba(0, 0, 0, .3);
    border-radius: 8px;
}
.window {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, .5);
    z-index: 999;
    display: flex;
    justify-content: center;
    align-items: center;
}
@media screen and (max-width: 1600px) {
    .window-content{
        width: 80%;
    }
}

@media screen and (max-width: 1500px) {
    .window-content{
        width: 90%;
    }
}
</style>
