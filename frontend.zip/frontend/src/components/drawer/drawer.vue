<script setup>
import { reactive, onMounted, watchEffect } from "vue";
import { useRouter } from "vue-router";
import { useMainStore } from "../../store/index";
import Axios from '../../../utils/request';
const stores = useMainStore();
const router = useRouter();
const data = reactive({
    tabs: 0,
    userEdit:{
        visible: false,
        nickname: '',
        signature: '',
        avatar: '',
    }
});


// 提交修改
function sendUserEdit() {

    Axios.post('/api/v1/users/modifyUserInfo', {
        nickname: data.userEdit.nickname,
        signature: data.userEdit.signature,
        avatar: data.userEdit.avatar,
    })
    .then(response => {
        // console.log(response.data.users)
        stores.user.nickname = response.data.nickname;
        stores.user.signature = response.data.signature;
        stores.user.avatar = response.data.avatar;
        data.userEdit.visible = false;
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}

// 上传头像返回结果
function handleAvatarSuccess(res, file) {
    ElMessage({
        message: '上传成功，刷新页面查看效果',
        type:'success'
    });
    data.userEdit.avatar = data.userEdit.avatar + '?timestamp=' + new Date().getTime();
}


// 退出登录
function outLogin() {
    localStorage.removeItem('mychatToken');
    // 刷新页面
    window.location.reload();
}

// 悬浮球开关
function floatChange() {
    localStorage.setItem('float', JSON.stringify({visible: stores.float.visible}));
}


// 获取徽章数据
function get_badge() {

    Axios.post('/api/v1/timed/getBadgeData', {})
    .then(response => {
        // console.log(response.data.users)
        stores.badge.fish_catch = response.data.fish_catch;
        stores.badge.online_time = response.data.online_time;
        stores.badge.chat_times = response.data.chat_times;
        stores.badge.fish_age = response.data.fish_age;
        stores.badge.badge_name = response.data.badge_name;
        stores.badge.sign_in_days = response.data.sign_in_days;
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}


// 获取排行榜数据
function get_ranks() {

    Axios.post('/api/v1/timed/getBadgeRank', {})
    .then(response => {
        // console.log(response.data.users)
        stores.drawer.ranks = response.data;
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}


// 获取股东信息
function getStockholderInfo() {

    Axios.post('/api/v1/timed/getShareholderList', {})
    .then(response => {
        // console.log(response.data.users)
        stores.drawer.stockholder = response.data.stockholder;
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}


watchEffect(() => {
    if (stores.drawer.visible) {
        if (stores.drawer.ranks.length === 0) {
            get_ranks()
        }
        if(stores.drawer.stockholder.length === 0){
            getStockholderInfo()
        }
    }
})



// 加载完毕
onMounted(() => {
    if (localStorage.getItem('mychatToken')) {
        // 延迟加载
        setTimeout(() => {
            get_badge()
        }, 2000)
    }
})
</script>

<template>

    <!-- 修改个人信息 -->
    <el-dialog
            v-model="data.userEdit.visible"
            title="修改我的信息"
            width="500"
    >
        <div class="dialog-content">
            <el-form :model="data.userEdit" ref="form" label-width="80px">
                <el-form-item label="我的头像" prop="avatar">
                    <el-upload
                        class="avatar-uploader"
                        :action="stores.config.port + '/api/v1/users/uploadUserAvatar'"
                        :headers="{'Authorization': 'Bearer '+stores.getToken()}"
                        :show-file-list="false"
                        :on-success="handleAvatarSuccess"
                    >
                        <el-avatar :src="data.userEdit.avatar" size="large"></el-avatar>
                    </el-upload>
                    
                </el-form-item>

                <el-form-item label="我的昵称" required prop="nickname">
                    <el-input v-model="data.userEdit.nickname" placeholder="请输入昵称"></el-input>
                </el-form-item>

                <el-form-item label="个性签名" prop="signature">
                    <el-input v-model="data.userEdit.signature" placeholder="请输入个性签名"></el-input>
                </el-form-item>
            </el-form>

        </div>

        <template #footer>
        <div class="dialog-footer">
            <el-button @click="data.userEdit.visible = false">取消</el-button>
            <el-button type="primary" @click="sendUserEdit">保存修改</el-button>
        </div>
        </template>
    </el-dialog>


    <el-drawer size="380px" :with-header="false" v-model="stores.drawer.visible">
        <div class="user-nickname">
            <span @click="login_show">😘 Hi, 「<span style="color: #3bb6c2; cursor: pointer;"  @click="() => {
                    if(stores.user.nickname !== ''){
                        data.userEdit = {
                            visible: true,
                            nickname: stores.user.nickname,
                            signature: stores.user.signature || '',
                            avatar: stores.config.port + '/api/v1/users/getUserAvatar/'+stores.user.username,
                        }
                    }
                }">{{ stores.user.nickname == '' ?
                '未登录' : stores.user.nickname }}</span>」 您好！</span>
            <!-- <img :src="stores.config.port + '/group/'+stores.user.avatar" alt=""> -->
        </div>

        <div class="tabs-box">
            <li @click="data.tabs = 0" :class="{ active: data.tabs === 0 }">
                <span>我的信息</span>
                <i v-if="data.tabs === 0"></i>
            </li>

            <li @click="data.tabs = 1;" :class="{ active: data.tabs === 1 }">
                <span>摸鱼榜</span>
                <i v-if="data.tabs === 1"></i>
            </li>

            <li @click="data.tabs = 2">
                <span>抓鱼鸭~</span>
                <i v-if="data.tabs === 2"></i>
            </li>

        </div>

        <div v-if="data.tabs === 0" class="user-bottom-box">
            <div class="user-box">
                <div style="display: flex;">
                    <i><img :src="stores.config.port + '/api/v1/users/getUserAvatar/'+stores.user.username" alt=""></i>
                    <div class="user-info">
                        <span>{{ stores.user.nickname == '' ? '未登录' : stores.user.nickname }}</span>
                        <span>ID:{{ stores.user.username == '' ? '未登录' : stores.user.username }}</span>
                    </div>
                </div>
                
                <span @click="() => {
                    data.userEdit = {
                        visible: true,
                        nickname: stores.user.nickname,
                        signature: stores.user.signature || '',
                        avatar: stores.config.port + '/api/v1/users/getUserAvatar/'+stores.user.username,
                    }
                }" class="nickname-btn">修改</span>
            </div>

            <div class="user-list">
                <div class="float-box">
                    <h3>悬浮球</h3>
                    <li>
                        <span>摸到 <span style="font-weight: 700; font-size: 16px; color: #ca2edf;">{{stores.badge.fish_catch}}</span> 条🐟️</span>
                        <span>签到天数 <span style="font-weight: 700; font-size: 16px; color: #4515d7;">{{ stores.badge.sign_in_days }}</span> 天</span>
                    </li>

                    <li>
                        <span>显示悬浮球</span>
                        <el-switch
                            @change="floatChange"
                            v-model="stores.float.visible"
                            class="ml-2"
                            style="--el-switch-on-color: #13ce66; --el-switch-off-color: #b3b3b3;"   
                        />
                    </li>

                </div>


                <div class="user-achievement">
                    <h3>摸鱼成就</h3>
                    <li>
                        <span>综合成就</span>
                        <div>
                            <a style="text-decoration: none;" href="https://home.zhuayuya.com/docs/%E6%91%B8%E9%B1%BC%E7%A4%BE%E5%8C%BA%E6%88%90%E5%B0%B1.html"
                                target="_blank">
                                <span class="user-badge">{{ stores.badge.badge_name }}</span>
                            </a>
                        </div>
                    </li>

                    <div>
                        <div>
                            <li>
                                <i>
                                    <img src="../../assets/drawer/naozhong.svg" alt="">
                                    <span>摸鱼时间</span>
                                </i>
                                <span class="user-count">{{ (stores.badge.online_time / 60).toFixed(1) }}
                                    分钟</span>
                            </li>

                            <li>
                                <i>
                                    <img src="../../assets/drawer/yu.svg" alt="">
                                    <span>摸到</span>
                                </i>
                                <span class="user-count">{{ stores.badge.fish_catch }} 条🐟️</span>
                            </li>
                        </div>

                        <div>
                            <li>
                                <i>
                                    <img src="../../assets/drawer/nianling.svg" alt="">
                                    <span>摸龄</span>
                                </i>
                                <span class="user-count">{{stores.badge.fish_age}} 天</span>
                            </li>

                            <li>
                                <i>
                                    <img src="../../assets/drawer/liaotian.svg" alt="">
                                    <span>摸鱼聊天</span>
                                </i>
                                <span class="user-count">{{ stores.badge.chat_times }} 次</span>
                            </li>
                        </div>
                    </div>
                </div>


                <!-- <div class="user-bind">
                    <h3>绑定信息</h3>
                    <li>
                        <span>邮箱：{{ stores.user.email == '' ? '未登录' : stores.user.email }}</span>
                        <span class="unbind-btn">{{ stores.user.email == '' ? '' : '已绑定' }}</span>
                    </li>
        
                    <li>
                        <span>手机：{{ stores.user.phone == '' ? '未绑定' : stores.user.phone }}</span>
                        <span class="unbind-btn">{{ stores.user.phone == '' ? '绑定' : '修改' }}</span>
                    </li>
                </div> -->

                <span 
                    @click="outLogin" 
                    v-if="stores.user.user_id != '' && stores.user.token != ''"
                    class="logout-btn"
                >
                    退出登录
                </span>

            </div>

        </div>


        <div v-if="data.tabs === 1" class="user-bottom-box">
            <ul>
                <li class="new-season">
                    <span>新赛季开启，此前榜单全部清空！(
                        <a href="https://home.zhuayuya.com/docs/%E6%91%B8%E9%B1%BC%E7%A4%BE%E5%8C%BA%E6%88%90%E5%B0%B1.html" target="_blank">赛季规则</a>
                    )</span>
                </li>
                <li v-for="(item, index) in stores.drawer.ranks" :key="index" class="fish-box">
                    <div style="display: flex; position: relative;">
                        <i v-if="index == 0" class="guan">
                            <img src="../../assets/drawer/1ming.svg" alt="">
                        </i>
                        <i v-if="index == 1" class="guan">
                            <img src="../../assets/drawer/2ming.svg" alt="">
                        </i>
                        <i v-if="index == 2" class="guan">
                            <img src="../../assets/drawer/3ming.svg" alt="">
                        </i>
                        <div v-if="index > 2" class="guan-rank">
                            {{ index }}
                        </div>
                        <i><img src="https://img.zyy.muo.cc/icon_/128.png" alt=""></i>
                        <div class="fish-info">
                            <span>{{ item.nickname }} ID:{{ item.username }}</span>
                            <p class="user-level">{{ item.badge_name }}</p>
                        </div>
                    </div>

                    <div class="honor-box">
                        <span style="color: #ca2edf;">摸到：{{ item.fish_catch }}条鱼</span>
                        <span style="color: #00a6ed;">签到天数：{{ item.sign_in_days }}天</span>
                        <!-- 保留小数点后一位 -->
                        <span style="color: #3bb6c2;">摸鱼时间：{{ (item.online_time / 60).toFixed(1) }}分钟</span>
                        <span style="color: rgb(229, 133, 16);">聊天数：{{ item.chat_times }}</span>
                        <span style="color: blue;">摸龄：{{ item.fish_age }}</span>

                    </div>

                </li>

            </ul>
        </div>

        <div v-if="data.tabs === 2" class="user-bottom-box">
            <div class="with-top">
                <div class="qun">
                    <li>
                        <i></i>
                        <h3>公众号</h3>
                        <img src="../../assets/drawer/dingyue.jpeg" alt="">
                    </li>

                    <li>
                        <i></i>
                        <h3>QQ群</h3>
                        <img src="../../assets/drawer/qqqun.png" alt="">
                    </li>
                </div>

                <div class="meiti">
                    <a href="https://home.zhuayuya.com" target="_blank" rel="noopener noreferrer">
                        <li>
                            <div class="meiti-icon">
                                <i style="margin-top: 3px;"><img src="../../assets/drawer/web.svg" alt=""></i>
                                <span>抓鱼鸭官网</span>
                            </div>
                            <i><img src="../../assets/you.svg" alt=""></i>
                        </li>
                    </a>

                    <a href="https://space.bilibili.com/7318180?spm_id_from=333.1007.0.0" target="_blank"
                        rel="noopener noreferrer">
                        <li>
                            <div class="meiti-icon">
                                <i><img src="../../assets/drawer/bilibili.svg" alt=""></i>
                                <span>Blibili</span>
                            </div>
                            <i><img src="../../assets/you.svg" alt=""></i>
                        </li>
                    </a>

                    <a href="https://vip.zhuayuya.com" target="_blank" rel="noopener noreferrer">
                        <li>
                            <div class="meiti-icon">
                                <i><img src="../../assets/drawer/naicha.svg" alt=""></i>
                                <span>支持我们~</span>
                            </div>
                            <i><img src="../../assets/you.svg" alt=""></i>
                        </li>
                    </a>
                    <div class="zanzhu">
                        <h3>抓鱼鸭的“股东”们</h3>
                        <div style="display: flex; justify-content: space-between; margin-top: 16px;">
                            <a href="https://www.asiayun.com/" target="_blank">亚洲云提供的服务器</a>
                            <a href="https://www.tsyvps.com/" target="_blank">蓝易云提供的CDN</a>
                        </div>

                        <div class="zanzhu-body">
                            <p v-for="(item, index) in stores.drawer.stockholder" :key="index">{{item}}</p>
                        </div>

                    </div>
                </div>
            </div>

            <div class="with-bottom">
                <h3>关于抓鱼鸭&摸鱼聊天室</h3>
                <p>抓鱼鸭是Pony&月落独立作品，不仅仅是一个摸鱼网站，还是一个有趣的新 标签页，聚合搜索帮你快速找到自己想要的,
                    还有弹幕功能，摸鱼聊天室作为摸鱼的重要板块，被作为重点功能单独开发，祝大家摸鱼快乐！</p>
                <div class="icon-list">

                    <a href="https://home.zhuayuya.com/docs/%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98.html"
                        target="_blank">
                        <li>
                            <i><img src="../../assets/drawer/wenti.svg" alt=""></i>
                            <span>使用问题</span>
                        </li>
                    </a>

                    <a href="https://home.zhuayuya.com/docs/%E6%B5%8F%E8%A7%88%E5%99%A8%E6%8F%92%E4%BB%B6.html"
                        target="_blank">
                        <li>
                            <i><img src="../../assets/drawer/chajian.svg" alt=""></i>
                            <span>安装扩展</span>
                        </li>
                    </a>

                    <a href="https://home.zhuayuya.com/docs/%E5%85%B3%E6%B3%A8%E6%88%91%E4%BB%AC.html"
                        target="_blank">
                        <li>
                            <i><img src="../../assets/drawer/fankui.svg" alt=""></i>
                            <span>问题反馈</span>
                        </li>
                    </a>

                    <a href="https://home.zhuayuya.com/docs/%E8%81%94%E7%B3%BB%E6%88%91%E4%BB%AC.html"
                        target="_blank">
                        <li>
                            <i><img src="../../assets/drawer/kefu.svg" alt=""></i>
                            <span>联系作者</span>
                        </li>
                    </a>
                </div>
            </div>
        </div>
    </el-drawer>
</template>

<style scoped>
.zanzhu-body{
    width: 100%;
    margin-top: 12px;
    border-radius: 10px;
    padding-bottom: 10px;
    background: #f9f9f9;
}
.zanzhu-body p{
    padding-top: 10px;
    margin-left: 20px;
    margin-bottom: 6px;
    font-size: 14px;
    color: #515151;
}
.new-season {
    margin-bottom: 26px;
    text-align: center;
    font-size: 14px;
    color: #462e01;
    padding: 8px 8px;
    background: #f2dda1;
    border-radius: 10px;
}

.float-box li {
    display: flex;
    height: 50px;
    background: #f6f6f6;
    margin-top: 12px;
    border-radius: 50px;
    justify-content: space-between;
    align-items: center;
    padding: 0px 18px;
}

.float-box h3 {
    font-size: 16px;
    font-weight: 600;
    color: #353535;
    margin-bottom: 10px;
    margin-top: 10px;
}

/* 摸鱼榜 */
.guan-rank {
    width: 30px;
    height: 20px;
    background: #ea2a0c;
    box-shadow: inset 0 -3px 0 0 rgba(23, 29, 33, 0.3);
    border-radius: 12px;
    text-align: center;
    line-height: 17px;
    color: #fff;
    font-weight: 600;
    position: absolute;
    left: 10px;
    top: -12px;
}

.guan img {
    width: 40px !important;
}

.guan {
    background: none !important;
    width: 40px !important;
    height: 40px !important;
    position: absolute;
    top: -23px;
    left: 6px;

}

.fish-info span {
    font-size: 14px;
    font-weight: 600;
    line-height: 22px;
    color: #353535;
}

.fish-info {
    margin-left: 10px;
}

.fish-box i img {
    width: 42px;
    height: 42px;
}

.fish-box i {
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    background: #f5f5f5;
}

.fish-box {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 1px solid #e8e8e8;
}

.honor-box span {
    font-size: 12px;
    line-height: 18px;
}

.honor-box {
    display: flex;
    flex-direction: column;
}

.user-level {
    font-size: 11px !important;
    width: 50px;
    height: 18px;
    text-align: center;
    margin-top: 3px;
    margin-left: 2px;
    background: linear-gradient(to right, #3bb6c2, #34abb6);
    border-radius: 3px;
    color: #fff !important;
    border: 1px solid #2591cf;
    box-shadow: 0px 2px 3px rgba(0, 0, 0, .1);
    line-height: 16px;
    cursor: pointer;
}


/* 抓鱼鸭 */
.meiti-icon i img {
    width: 16px;
}

.meiti-icon i {
    width: 16px;
    margin-right: 6px;
}

.meiti-icon {
    display: flex;
    align-items: center;
}
.icon-list a{
    text-decoration: none;
}
.icon-list li img {
    width: 68px;
    height: 68px;
    border-radius: 13px;
}

.icon-list li span {
    margin-top: 8px;
    font-size: 14px;
    color: #515151;
}

.icon-list li {
    list-style: none;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.icon-list {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 20px;
}

.with-bottom p {
    line-height: 24px;
    font-size: 13.5px;
    color: #515151;
    margin-top: 12px;
    letter-spacing: .5px;
}

.with-bottom h3 {
    font-size: 18px;
    font-weight: 600;
    color: #353535;
}

.with-bottom {
    margin-top: 20px;
}


.zanzhu a {
    margin-bottom: 8px;
    cursor: pointer;
    display: inline;
    padding: 15px 12px;
    font-size: 14px;
    border-radius: 30px;
    color: #21858e;
    text-decoration: none;
    background: rgba(89, 209, 236, 0.3);
}

.zanzhu h3 {
    font-size: 18px;
    font-weight: 600;
    color: #353535;
}

.zanzhu {
    margin-top: 26px;

}

.meiti li span {
    color: #515151;
    
}
.meiti a{
    text-decoration: none;
}
.meiti li {
    list-style: none;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-radius: 50px;
    padding: 0 20px;
    height: 50px;
    background: #f5f5f5;
    margin-top: 12px;
}

.meiti {
    width: 100%;
    margin-top: 26px;
}

.qun li img {
    width: 112px;
}

.qun li h3 {
    font-size: 15px;
    margin-bottom: 4px !important;
    margin-top: 10px;
}

.qun li i {
    display: block;
    width: 18px;
    height: 6px;
    border-radius: 10px;
    background: #2c2c2c;
}

.qun li {
    width: 110px;
    height: 145px;
    border-radius: 10px;
    border: 1px solid #e8e8e8;
    list-style: none;
    padding: 10px;
}

.qun {
    margin: 0 auto;
    background: #fff;
    box-shadow: 0px 4px 20px 0px rgba(0, 0, 0, 0.1);
    border-radius: 15px;
    display: flex;
    padding-top: 12px;
    padding-left: 12px;
    padding-right: 12px;
    justify-content: space-between;
    padding-bottom: 10px;
}




/* 内部组件 */
.Wallpaper {
    width: 100%;
    height: 180px;
    margin: 0 auto;
    margin-top: 5px;
    border-radius: 10px;
    object-fit: cover;
}

.Wallpaper-img {
    width: 100%;
    height: 100%;
    background: #3bb6c2;
    margin: 0 auto;
    margin-top: 5px;
    border-radius: 10px;
    object-fit: cover;
}

.Wallpaper:hover {
    cursor: pointer;
}

.Wallpaper-click:hover {
    background: rgba(255, 255, 255, 0.6);
}

.Wallpaper-click {
    position: absolute;
    width: 100px;
    height: 38px;
    text-align: center;
    margin: 0 auto;
    left: 50%;
    line-height: 38px;
    border-radius: 8px;
    margin-left: -50px;
    margin-top: -56px;
    font-size: 16px;
    color: #585858;
    font-weight: 500;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.8);
    transition: all 0.3s;
    /* 过度 */
    -moz-transition: all 0.3s;
    /* Firefox */
    -webkit-transition: all 0.3s;
    /* Safari 和 Chrome */
}

.logout-btn:hover {
    background: #3bb6c2;
    color: #fff;
}

.logout-btn {
    display: block;
    height: 50px;
    line-height: 50px;
    margin-top: 28px;
    border-radius: 50px;
    background: #ededed;
    text-align: center;
    width: 100%;
    font-size: 14px;
    color: #2f2f2f;
    cursor: pointer;
    transition: all .2s;
}

.user-bind li span:last-child {
    color: #3bb6c2;
}

.user-bind li span {
    font-size: 14px;
    color: #939393;
}

.user-bind li {
    list-style: none;
    display: flex;
    justify-content: space-between;
    padding-bottom: 20px;
    border-bottom: 0.5px solid #eeeeee;
    margin-top: 26px;
}

.user-bind h3 {
    font-size: 16px;
    font-weight: 600;
    color: #353535;
    margin-bottom: 28px;
}

.user-bind {
    margin-top: 38px;
}

.user-count {
    font-size: 16px;
    background: linear-gradient(to right, #3bb6c2, #34abb6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 600;
}

.user-badge {
    padding: 1px 2px;
    background: linear-gradient(to right, #3bb6c2, #34abb6);
    font-size: 11px;
    border-radius: 3px;
    color: #fff;
    border: 1px solid #3bb6c2;
    box-shadow: 0px 2px 3px rgba(0, 0, 0, .1);
    line-height: 25px;
    cursor: pointer;
}

.user-achievement i img {
    width: 24px;
}

.user-achievement i span {
    margin-left: 8px;
    font-size: 15px;
    color: #858585;
    margin-top: 5px;
}

.user-achievement i {
    display: flex;
    height: 50px;
    align-items: center;
    /* width: 20px; */
}

.user-achievement li {
    display: flex;
    height: 50px;
    background: #f6f6f6;
    margin-top: 12px;
    border-radius: 50px;
    justify-content: space-between;
    align-items: center;
    padding: 0px 18px;
}

.user-achievement h3 {
    font-size: 16px;
    font-weight: 600;
    color: #353535;
    margin-bottom: 20px;
}

.user-achievement {
    margin-top: 20px;
}

.user-list {
    margin-top: 10px;
}

.nickname-btn {
    display: block;
    height: 26px;
    width: 68px;
    text-align: center;
    line-height: 26px;
    border-radius: 5px;
    border: 1px solid #3bb6c2;
    font-size: 12px;
    color: #3bb6c2;
    cursor: pointer;
    transition: all .2s;
}

.nickname-btn:hover {
    background: #3bb6c2;
    color: #fff;
}

.user-info span:first-child {
    display: block;
    width: 180px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 16px;
    color: #2f2f2f;
    font-weight: 600;
}

.user-info span {
    font-size: 14px;
    color: #939393;
    line-height: 28px;
}


.user-info {
    display: flex;
    flex-direction: column;
    margin-left: 15px;
}

.user-box i img {
    width: 100%;
    border-radius: 8px;
}

.user-box i {
    width: 48px;
    height: 48px;
    /* padding: 5px; */
    border-radius: 8px;
    background: #f5f5f5;
}

.user-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-bottom: 20px;
    border-bottom: 0.5px solid #eeeeee;
}

.user-bottom-box {
    height: calc(100% - 125px);
    background: #ffffff;
    margin-top: 20px;
    border-radius: 18px;
    padding: 18px;
    overflow: auto;
}

.tabs-box i {
    display: block;
    height: 10px;
    width: 110%;
    margin-top: -5px;
    border-radius: 10px;
    background: #3bb6c2;
}

.tabs-box li {
    display: flex;
    flex-direction: column;
    align-items: center;
    cursor: pointer;
}

.tabs-box span {
    font-size: 18px;
    color: #ffffff;
    z-index: 1;
    text-shadow: 0px 4px 19px rgba(0, 0, 0, .2);
}

.tabs-box {
    width: 88%;
    font-weight: 600;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    margin-top: 28px;
    list-style: none;
}

.user-nickname span {
    font-size: 16px;
    font-weight: 500;
    color: #2f2f2f;
    letter-spacing: .5px;
}

.user-nickname img {
    width: 35px;
}

.user-nickname {
    height: 50px;
    border-radius: 12px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 15px;
    box-shadow: 1px 10px 15px rgba(0, 0, 0, .05);
}


.drawer-content{
    width: 100%;
    height: 100%;
    background: #fff;
    border-radius: 18px;
}
</style>

<style>
.el-drawer {
    background-color: #f5f5f599;
    box-shadow: -2px 10px 15px rgba(0, 0, 0, 0.5);
    -webkit-backdrop-filter: saturate(200%) blur(15px);
    backdrop-filter: saturate(200%) blur(15px);
}
</style>