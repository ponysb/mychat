<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useMainStore } from "../../store/index";
import { IconPark } from '@icon-park/vue-next/es/all';
import Axios from '../../../utils/request';
import axios from 'axios';
import '../../assets/gt3.js'
import { useRoute, useRouter } from 'vue-router';
import msgList from '../../assets/msg_list.json';
const Route = useRoute();
const Router = useRouter();
const stores = useMainStore();
const data = reactive({
    visible: true,
    form: {
        email: '',   // 邮箱
        code: ''    // 验证码
    },
    banner:[
        {img:'https://img.zyy.muo.cc/element_icon/liuliangka_chang.png',src:'https://haokawx.lot-ml.com/Product/Index/229080'},
        {img:'https://img.zyy.muo.cc/element_icon/ailunwen.png',src:'https://wen.zhuayuya.com/'},
    ],

    chat:[
    {
        "id": 484210,
        "msg_id": "MSG_t4WZAQyA_J8NrEiO1CNWD",
        "room_id": "",
        "user_id": "1215752",
        "nickname": "kyokimi",
        "avatar": "",
        "msg": "",
        "ymsg": "",
        "type": "bqb",
        "img": "",
        "app": {},
        "bqb": {
            "bqb_id": "BQB00000008",
            "title": "e0cdeb6a6f9bf9989d8bb7d150d808e0.jpg",
            "tag": null,
            "url": "/bqb/万恶vtb/e0cdeb6a6f9bf9989d8bb7d150d808e0.jpg",
            "category": "万恶vtb"
        },
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "未设置昵称",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T07:07:24.425Z",
        "updatedAt": "2025-01-29T07:07:47.146Z"
    },
    {
        "id": 484209,
        "msg_id": "MSG_i6X0sfSG4JDUwTjAWJaAB",
        "room_id": "",
        "user_id": "1210313",
        "nickname": "风净轩",
        "avatar": "",
        "msg": "今年第一个瑟琴谜语哦~~有要猜猜看的吗？",
        "ymsg": "今年第一个瑟琴谜语哦~~有要猜猜看的吗？",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "风净轩",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T07:05:01.897Z",
        "updatedAt": "2025-01-29T07:05:01.897Z"
    },
    {
        "id": 484208,
        "msg_id": "MSG_JmByzlzUY_S1WvqoLsE2H",
        "room_id": "",
        "user_id": "1210313",
        "nickname": "风净轩",
        "avatar": "",
        "msg": "大家过年好吖~~",
        "ymsg": "大家过年好吖~~",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "风净轩",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T07:04:37.880Z",
        "updatedAt": "2025-01-29T07:04:37.880Z"
    },
    {
        "id": 484207,
        "msg_id": "MSG_JssLOmMmhCFA6FCwa9L8y",
        "room_id": "",
        "user_id": "1210313",
        "nickname": "风净轩",
        "avatar": "",
        "msg": "给大家拜年了",
        "ymsg": "给大家拜年了",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "风净轩",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T07:04:29.687Z",
        "updatedAt": "2025-01-29T07:04:29.687Z"
    },
    {
        "id": 484206,
        "msg_id": "MSG_Cb3itMJx6sZCpUvDAk6Dx",
        "room_id": "",
        "user_id": "1215751",
        "nickname": "未设置昵称",
        "avatar": "",
        "msg": "不好玩",
        "ymsg": "不好玩",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "未设置昵称",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T05:06:29.090Z",
        "updatedAt": "2025-01-29T05:06:29.090Z"
    },
    {
        "id": 484205,
        "msg_id": "MSG__bY8QjSXLRueP1XqdkKAW",
        "room_id": "",
        "user_id": "1204146",
        "nickname": "迎着阳光盛大逃亡",
        "avatar": "",
        "msg": "大家新年好",
        "ymsg": "大家新年好",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "迎着阳光盛大逃亡",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T04:16:31.946Z",
        "updatedAt": "2025-01-29T04:16:31.946Z"
    },
    {
        "id": 484204,
        "msg_id": "MSG_JpCS_h0ng89X9C-TfG9yR",
        "room_id": "",
        "user_id": "1213760",
        "nickname": "咕噜咕噜嘟🤖",
        "avatar": "",
        "msg": "不如2025首届大学生春晚",
        "ymsg": "不如2025首届大学生春晚",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "咕噜咕噜嘟🤖",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T03:03:39.637Z",
        "updatedAt": "2025-01-29T03:03:39.637Z"
    },
    {
        "id": 484203,
        "msg_id": "MSG_Fr2YpnkaprxbTM3mtjLLE",
        "room_id": "",
        "user_id": "1213760",
        "nickname": "咕噜咕噜嘟🤖",
        "avatar": "",
        "msg": "流量明星一堆一堆的，看的都没意思。",
        "ymsg": "流量明星一堆一堆的，看的都没意思。",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "咕噜咕噜嘟🤖",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T03:03:18.777Z",
        "updatedAt": "2025-01-29T03:03:18.777Z"
    },
    {
        "id": 484202,
        "msg_id": "MSG_o1B8BhMgsUxKrAoj1N79N",
        "room_id": "",
        "user_id": "1215456",
        "nickname": "图元",
        "avatar": "",
        "msg": "今年春晚怎么唱歌的节目十几个人参加，一人一句我怎么感觉都不够呢",
        "ymsg": "今年春晚怎么唱歌的节目十几个人参加，一人一句我怎么感觉都不够呢",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "图元",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T01:22:11.158Z",
        "updatedAt": "2025-01-29T01:22:11.158Z"
    },
    {
        "id": 484201,
        "msg_id": "MSG_QvnPsqqUB43zXr_n0QC9U",
        "room_id": "",
        "user_id": "1215456",
        "nickname": "图元",
        "avatar": "",
        "msg": "快乐快乐",
        "ymsg": "快乐快乐",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "图元",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-29T01:21:42.501Z",
        "updatedAt": "2025-01-29T01:21:42.501Z"
    },
    {
        "id": 484200,
        "msg_id": "MSG_LosTyNU3Kk67Ilf7Bs4Xp",
        "room_id": "",
        "user_id": "1215739",
        "nickname": "未设置昵称",
        "avatar": "",
        "msg": "新年快乐！",
        "ymsg": "新年快乐！",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "未设置昵称",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T16:27:43.410Z",
        "updatedAt": "2025-01-28T16:27:43.410Z"
    },
    {
        "id": 484199,
        "msg_id": "MSG_oJXjbHkkfuVktRqnML4RX",
        "room_id": "",
        "user_id": "1215744",
        "nickname": "未设置昵称",
        "avatar": "",
        "msg": "先给大家拜个早年",
        "ymsg": "先给大家拜个早年",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "未设置昵称",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T15:52:48.668Z",
        "updatedAt": "2025-01-28T15:52:48.668Z"
    },
    {
        "id": 484198,
        "msg_id": "MSG_YKW4zUIelgJEr3-zoo1EI",
        "room_id": "",
        "user_id": "1213760",
        "nickname": "咕噜咕噜嘟🤖",
        "avatar": "",
        "msg": "不看春晚",
        "ymsg": "不看春晚",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "咕噜咕噜嘟🤖",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T13:25:53.548Z",
        "updatedAt": "2025-01-28T13:25:53.548Z"
    },
    {
        "id": 484197,
        "msg_id": "MSG_ZGF_EE5QYHp7nnRM65I_R",
        "room_id": "",
        "user_id": "46977",
        "nickname": "友爱部",
        "avatar": "",
        "msg": "有没有春晚的瓜",
        "ymsg": "有没有春晚的瓜",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "友爱部",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T13:12:34.431Z",
        "updatedAt": "2025-01-28T13:12:34.431Z"
    },
    {
        "id": 484196,
        "msg_id": "MSG_HJpS047_UuKNb0QpNZ_ve",
        "room_id": "",
        "user_id": "1213760",
        "nickname": "咕噜咕噜嘟🤖",
        "avatar": "",
        "msg": "",
        "ymsg": "",
        "type": "bqb",
        "img": "",
        "app": {},
        "bqb": {
            "bqb_id": "BQB00000033",
            "title": "中国春节00003-给您拜个年.jpg",
            "tag": null,
            "url": "/bqb/中国春节/中国春节00003-给您拜个年.jpg",
            "category": "中国春节"
        },
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "咕噜咕噜嘟🤖",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T12:47:43.178Z",
        "updatedAt": "2025-01-28T12:47:43.178Z"
    },
    {
        "id": 484195,
        "msg_id": "MSG_RquiiEXrdtlic3sQXjxUn",
        "room_id": "",
        "user_id": "1215603",
        "nickname": "蛋糕1215",
        "avatar": "",
        "msg": "就睡了四个小时不到，还要帮忙做家务，要似了（",
        "ymsg": "就睡了四个小时不到，还要帮忙做家务，要似了（",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "蛋糕1215",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T01:51:11.315Z",
        "updatedAt": "2025-01-28T01:51:11.315Z"
    },
    {
        "id": 484194,
        "msg_id": "MSG_ZyOAL3jj5eXHh_uqXir1z",
        "room_id": "",
        "user_id": "1215729",
        "nickname": "Shizuka静",
        "avatar": "",
        "msg": "还有toheart系列",
        "ymsg": "还有toheart系列",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "Shizuka静",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T01:05:54.865Z",
        "updatedAt": "2025-01-28T01:05:54.865Z"
    },
    {
        "id": 484193,
        "msg_id": "MSG_yKM8vyOXudXJA8scuMeOJ",
        "room_id": "",
        "user_id": "1215729",
        "nickname": "Shizuka静",
        "avatar": "",
        "msg": "传颂之物一生推，小时候玩的时候可*是太喜欢了",
        "ymsg": "传颂之物一生推，小时候玩的时候可真是太喜欢了",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "Shizuka静",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T01:05:34.060Z",
        "updatedAt": "2025-01-28T01:05:34.060Z"
    },
    {
        "id": 484192,
        "msg_id": "MSG_bRT-NKJqdDlEOayUPyz4z",
        "room_id": "",
        "user_id": "1215456",
        "nickname": "图元",
        "avatar": "",
        "msg": "除夕快乐",
        "ymsg": "除夕快乐",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "图元",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-28T01:00:25.080Z",
        "updatedAt": "2025-01-28T01:00:25.080Z"
    },
    {
        "id": 484191,
        "msg_id": "MSG_8WOWJWQQmyH3YUgLakfmi",
        "room_id": "",
        "user_id": "1215738",
        "nickname": "捏哈哈",
        "avatar": "",
        "msg": "实在不行就去玩I社的捏妹子游戏",
        "ymsg": "实在不行就去玩I社的捏妹子游戏",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "捏哈哈",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-27T17:59:05.021Z",
        "updatedAt": "2025-01-27T17:59:05.021Z"
    },
    {
        "id": 484190,
        "msg_id": "MSG_4cfiAzgUQHtBHrCmfAJPr",
        "room_id": "",
        "user_id": "1215738",
        "nickname": "捏哈哈",
        "avatar": "",
        "msg": "柚子社的都不错（",
        "ymsg": "柚子社的都不错（",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "未设置昵称",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-27T17:56:51.513Z",
        "updatedAt": "2025-01-27T17:57:36.252Z"
    },
    {
        "id": 484189,
        "msg_id": "MSG_6hteZL3yGywuiWWoaH9lv",
        "room_id": "",
        "user_id": "1215603",
        "nickname": "蛋糕1215",
        "avatar": "",
        "msg": "多娜多娜",
        "ymsg": "多娜多娜",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "蛋糕1215",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-27T17:23:50.189Z",
        "updatedAt": "2025-01-27T17:23:50.189Z"
    },
    {
        "id": 484188,
        "msg_id": "MSG_o1eCM6LqQMeQjSJbb87Pu",
        "room_id": "",
        "user_id": "1215737",
        "nickname": "未设置昵称",
        "avatar": "",
        "msg": "",
        "ymsg": "",
        "type": "bqb",
        "img": "",
        "app": {},
        "bqb": {
            "bqb_id": "BQB00000089",
            "title": "乌龟00001-暗香王八.png",
            "tag": null,
            "url": "/bqb/乌龟/乌龟00001-暗香王八.png",
            "category": "乌龟"
        },
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "未设置昵称",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-27T16:13:24.599Z",
        "updatedAt": "2025-01-27T16:13:24.599Z"
    },
    {
        "id": 484187,
        "msg_id": "MSG_Y3AEpJK_8BIooEpgP2Avp",
        "room_id": "",
        "user_id": "1215737",
        "nickname": "未设置昵称",
        "avatar": "",
        "msg": "有没有什么好玩的瑟瑟游戏推荐一下",
        "ymsg": "有没有什么好玩的瑟瑟游戏推荐一下",
        "type": "text",
        "img": "",
        "app": {},
        "bqb": {},
        "email": "",
        "state": "n",
        "user_info": {
            "nickname": "未设置昵称",
            "avatar": "",
            "email": "",
            "phone": "",
            "gender": "",
            "nature": ""
        },
        "room_info": {
            "room_id": "",
            "title": "",
            "intro": "",
            "limits": ""
        },
        "source": "http://zyy.muo.cc",
        "interact": {
            "like": 0,
            "winnow": false
        },
        "createdAt": "2025-01-27T16:13:05.575Z",
        "updatedAt": "2025-01-27T16:13:05.575Z"
    },
    ],

    codeText: '获取验证码',
    btnText: '登录/注册',

    // 在线人数
    online: 1256
})

// 无限循环
setInterval(() => {
    // 生成1200-1400之间的随机数
    let num = Math.floor(Math.random() * 200) + 1200;
    data.online = num;

    if(num > 1300){
        data.chat.push(msgList[Math.floor(Math.random() * msgList.length)])
        // 延迟100毫秒
        setTimeout(() => {
            scrollToBottom()
        }, 100)
    }
}, 3000)

if (Route.query.ac) {
    stores.ac = Route.query.ac;
}

if(localStorage.getItem('mychatToken')){
    Router.push({ path: '/chat/666666' });
}


// 登录
function login() {

    if(data.btnText != '登录/注册'){
        return
    }

    if(data.form.email == '' || data.form.code == ''){
        ElMessage.error('请输入正确的验证码')
        return
    }

    data.btnText = '登录中...'

    Axios.post('/api/v1/users/login', {
        email: data.form.email,
        code: data.form.code,
        invite: stores.ac
    })
    .then(response => {
        // console.log(response.data.data);
        // token保存到本地
        localStorage.setItem('mychatToken', response.data.token);
        // 延迟100毫秒
        setTimeout(() => {
            window.location.href = '/'
        }, 150)
    })
    .catch(error => {
        console.log(error);
        ElMessage.error('登录失败，请输入正确的验证码')
        data.btnText = '登录/注册'
    });
}



// 手机号或邮箱校验返回是手机号还是邮箱
function checkUserCode(e){
    if (/^1[3-9]\d{9}$/.test(e)) {
        return 'phone'
    } else if (/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/.test(e)) {
        return 'email'
    } else {
        return 'error'
    }
}


// 倒计时
function countDown() {
    let time = 60
    data.codeText = `${time}秒后重试`
    let timer = setInterval(() => {
        time--
        if (time > 0) {
            data.codeText = `${time}秒后重试`
        } else {
            clearInterval(timer)
            data.codeText = '获取验证码'
        }
    }, 1000)
}

// 获取验证码
function sendCode() {
    if(data.codeText != '获取验证码'){
        return
    }

    let type = checkUserCode(data.form.email)
    // console.log(type)
    if(type == 'phone'){
        ElMessage.error('请输入正确的邮箱')
    }

    if(type == 'error'){
        ElMessage.error('请输入正确的邮箱')
    }

    // 获取中
    data.codeText = '获取中...'

    if(type == 'email'){
        axios.post('https://api.zyy.muo.cc/account/user/send_code', JSON.stringify({
            "email": data.form.email,
            "geetest": {}
        }),
        {
            headers: {
                'Content-Type': 'application/json'
            }
        }

    ).then(response => {
            countDown()
            ElMessage.success('验证码发送成功，请注意查收')
        })
        .catch(error => {
            console.log(error);
            ElMessage.error('验证码发送失败，请重试')
        });
    }
}


// 滚动条滚动到底部
let chatBox = ref(null);
onMounted(() => {
    scrollToBottom()
})


function scrollToBottom() {
    chatBox.value.scrollTop = chatBox.value.scrollHeight;
}
</script>

<template>
<el-dialog v-model="data.visible" width="600">
    <div class="login-box">
        <div class="wx-qrcode">
            <div class="wx-qrcode-title">
                <icon-park type="wechat" theme="filled" size="24" fill="#09bb07"/>
                <span>抓鱼鸭微信公众号</span>
            </div>
            <img src="../../assets/menu/qrcode.jpeg" alt="">
        </div>

        <div class="login-content">
            <h1>😘 Hi，欢迎来到摸鱼聊天室</h1>
            <div class="form-box">
                <el-input v-model="data.form.email" style="width: 100%; height: 36px;" placeholder="输入邮箱登录" />
                <el-input
                    v-model="data.form.code"
                    style="width: 100%; margin-top: 10px; height: 36px;"
                    placeholder="输入验证码"
                    >
                    <template #append>
                        <el-button link style="padding: 0 10px; font-size: 13px;" @click="sendCode">{{data.codeText}}</el-button>
                    </template>
                </el-input>
            </div>
            <el-button type="primary" style="width: 100%; height: 36px; margin-top: 15px;" @click="login">{{data.btnText}}</el-button>

            <div class="info-box">
                <p>注意：验证码邮件可能会被放入垃圾哦 ，不建议用第三方邮件系统查看， 
                    <a href="https://home.zhuayuya.com/docs/%E9%82%AE%E7%AE%B1%E7%99%BD%E5%90%8D%E5%8D%95.html" class="email-link" target="_blank">建议使用常见邮箱～～</a>
                </p>
                <a href="https://home.zhuayuya.com/docs/%E9%82%AE%E7%AE%B1%E7%99%BD%E5%90%8D%E5%8D%95.html" class="info-link" target="_blank">👉️ 收不到验证码点我</a>
            </div>
        </div>
    </div>
</el-dialog>

<div @click="data.visible = true" class="skeleton-box">
    <div class="left-box">
        <div class="logo">
            <img src="../../assets/logo.svg" alt="">
        </div>
        <div class="list-box">
            <ul>
                <li v-for="(item, index) in stores.menu.menu_list" :key="index">
                    <i><img :src="item.icon" alt=""></i>
                    <span>{{item.name}}</span>
                </li>
            </ul>

            <ul>

                <el-tooltip
                    class="box-item"
                    effect="light"
                    :content="'登录后签到'"
                    placement="right"
                >
                    <li>
                        <i><img src="../../assets/menu/qiandao.svg" alt=""></i>
                        <span>签到</span>
                    </li>
                </el-tooltip>


                <el-popover
                    placement="right"
                    :width="175"
                    trigger="hover"
                >
                    <template #reference>
                        <li>
                            <i><img src="../../assets/menu/wxqrcode.svg" alt=""></i>
                            <span>公众号</span>
                        </li>
                    </template>

                    <template #default>
                        <img style="width: 150px;" src="../../assets/menu/qrcode.jpeg" alt="">
                    </template>
                </el-popover>

                <li>
                    <i><img src="../../assets/menu/user.svg" alt=""></i>
                    <span>登录</span>
                </li>
            </ul>
        </div>
    </div>

    <div class="center-box">
        <div class="banner-box">
            <img v-for="(item, index) in data.banner" :key="index" :src="item.img" alt="">
        </div>

        <ul class="controls-box">
            <li>
                <icon-park type="four-round-point-connection" size="20" fill="#949ba4"/>
                <span>加入房间</span>
            </li>

            <li>
                <icon-park type="newlybuild" size="20" fill="#949ba4"/>
                <span>创建房间</span>
            </li>

            <li>
                <icon-park type="application-one" size="20" fill="#949ba4"/>
                <span>添加应用</span>
            </li>
        </ul>

        <ul class="room-box">
            <li>
                <img src="../../assets/moyu.gif" alt="">
                <div>
                    <h3>摸鱼自习室</h3>
                    <p>你摸鱼我摸鱼，老板宝马换青桔</p>
                </div>
            </li>
        </ul>

    </div>

    <div class="right-box">
        <div class="header-box">
            <div class="avatar-box">
                <img src="../../assets/moyu.gif" alt="">
                <span>摸鱼自习室</span>
            </div>

            <span class="online-num"><i></i>在线人数：{{ data.online }}</span>
        </div>

        <div ref="chatBox" class="chat-box">
            <ul>
                <template v-for="(item, index) in msgList" :key="index">
                    <!-- 文字消息 -->
                    <li v-if="item.type === 'text'" class="text">
                        <div class="avatar">
                            <img :src="stores.config.port+'/api/v1/users/getUserAvatar/'+item.user_id" alt="">
                        </div>
                        <div class="content">
                            <div class="name">
                                <span>用户名</span>
                            </div>
                            <div class="msg">
                                {{item.msg}}
                            </div>
                        </div>
                    </li>

                    <!-- 图片消息 -->
                    <li v-if="item.type === 'bqb'" class="image">
                        <div>
                            <img class="avatar" :src="stores.config.port+'/api/v1/users/getUserAvatar/'+item.user_id" alt="">
                        </div>
                        <div class="content">
                            <div class="name">
                                <span>用户名</span>
                            </div>
                            <div class="image-msg">
                                <img :src="'https://mychat.bqb.zhuayuya.com/'+item.bqb.url" alt="">
                            </div>
                        </div>
                    </li>

                    <!-- 应用消息 -->
                    <li v-if="item.type === 'app'" class="app">
                        <div>
                            <img class="avatar" :src="stores.config.port+'/api/v1/users/getUserAvatar/'+item.user_id" alt="">
                        </div>
                        <div class="content">
                            <div class="name">
                                <span>用户名</span>
                            </div>
                            <div class="app-box">
                                <img :src="item.app.icon" alt="">
                                <div class="app-name">
                                    <h3>{{item.app.title}}</h3>
                                    <p>{{item.app.description}}</p>
                                </div>
                            </div>
                        </div>
                    </li>
                </template>
            </ul>
        </div>

        <div class="input-box">
            <div class="input-top">
                <div class="input-left">
                    <icon-park type="application-one" size="20" />
                    <icon-park type="grinning-face-with-tightly-closed-eyes" size="20" />
                    <span>/ 斜杠命令</span>
                </div>
                <span style="margin-right: 10px; cursor: pointer;">发送</span>
            </div>

            <div class="input-content">
                录后发送消息哦QaQ~
            </div>

        </div>
    </div>
</div>

</template>

<style scoped>
.email-link{
    color: #09bb07;
    transition: all 0.2s ease;
}
.email-link:hover{
    text-shadow: 0px 2px 10px #12ff1e;
}
.info-link{
    color: #fd1c1c !important;
    font-size: 13px;
    display: block;
    margin-top: 8px;
    text-decoration: none;
}
.info-link:hover{
    text-decoration: underline;
}
.info-box p{
    color: #787878;
    font-size: 13px;
    line-height: 1.5;
}
.info-box{
    padding: 10px;
    background: #f4f4f4;
    border-radius: 5px;
    margin-top: 18px;
}
.login-content h1{
    text-align: center;
    font-size: 20px;
    margin-bottom: 20px;
    color: #333;
}
.login-content{
    width: 560px;
    margin-left: 16px;
}
.wx-qrcode span{
    font-size: 18px;
    margin-left: 6px;
}
.wx-qrcode-title{
    width: 100%;
    background: #fff;
    padding-top: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius:5px 5px 0 0;
}
.wx-qrcode img{
    width: 100%;
    border-radius: 0 0 5px 5px;
}
.wx-qrcode{
    width: 380px;
    padding: 10px;
    background: #e7f1ff;
    border-radius: 5px;
}
.login-box{
    display: flex;
}
.app-name p{
    font-size: 13px;
    color: #888889;
}
.app-name h3{
    margin-bottom: 12px;
    font-size: 16px;
    color: #333;
    font-weight: 600;
}
.app-box img{
    width: 58px;
    height: 58px;
    margin-left: 10px;
    margin-right: 10px;
    border-radius: 10px;
}
.app-box{
    display: flex;
    height: 80px;
    width: 240px;
    background: #fff;
    align-items: center;
    border-radius: 2px 10px 10px 10px;
}
.name{
    font-size: 14px;
    color: #7e7f80;
    margin-bottom: 10px;
}
.content{
    margin-left: 10px;
}
.avatar{
    width: 50px;
    height: 50px;
}
.app{
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    display: flex;
}
.name{
    font-size: 14px;
    color: #7e7f80;
    margin-bottom: 10px;
}
.content{
    margin-left: 10px;
}
.avatar{
    width: 50px;
    height: 50px;
}
.image-msg img{
    border-radius: 2px 10px 10px 10px;
    color: #333;
    max-width: 300px;
    object-fit: cover;
    filter: blur(5px);
}
.image{
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    display: flex;
}
.msg{
    padding: 10px;
    background: #ffffff;
    border-radius: 2px 10px 10px 10px;
    color: #333;
}
.name{
    font-size: 14px;
    color: #7e7f80;
    margin-bottom: 10px;
}
.content{
    margin-left: 10px;
}
.text img{
    width: 50px;
    height: 50px;
}
.text{
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    display: flex;
}
.chat-box{
    height: calc(100vh - 312px);
    overflow: auto;
    filter: blur(5px);
}
.input-content:hover{
    color: #27c459;
    text-decoration: underline;
}
.input-content{
    text-align: center;
    font-size: 16px;
    color: #fff;
    line-height: 210px;
    cursor: pointer;
}
.input-left span{
    margin-left: 10px;
    cursor: pointer;
}
.input-left{
    display: flex;
    align-items: center;
}
.input-top{
    height: 38px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #7f858d;
    border-bottom: 1px solid #4d4f54;
}
.input-box{
    height: 250px;
    width: 100%;
    background: #383a40;
}
.online-num i{
    display: block;
    width: 8px;
    height: 8px;
    border-radius: 10px;
    background: #27c459;
    margin-right: 6px;
}
.online-num{
    color: #27c459 !important;
    font-size: 13px !important;
    margin-right: 18px;
    display: flex;
    align-items: center;
}
.header-box span{
    color: #ffffff;
    font-weight: 500;
    font-size: 16px;
    margin-left: 10px;
}
.header-box img{
    width: 42px;
    height: 42px;
    margin-left: 18px;
}
.avatar-box{
    display: flex;
    align-items: center;
}
.header-box{
    height: 62px;
    width: 100%;
    background: #2a2a2a;
    box-shadow: 0px 1px 3px rgba(0, 0, 0, .25);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.right-box{
    width: calc(100% - 368px);
    height: 100vh;
    background: #313338;
}
.room-box li p{
    width: 220px;
    font-size: 13px;
    color: #8d8d8d;
    margin-top: 10px;
    line-height: 18px;
    /* 最多一行 */
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}
.room-box li h3{
    font-size: 15px;
    font-weight: 600;
    color: #fff;
}
.room-box li img{
    width: 48px;
    height: 48px;
    background: #fff;
    margin-left: 10px;
    border-radius: 12px;
    margin-right: 10px;
}
.room-box li{
    height: 72px;
    background: #404249;
    display: flex;
    align-items: center;
}
.controls-box li span{
    font-size: 15px;
    color: #fff;
    margin-left: 10px;
}
.controls-box li{
    height: 42px;
    width: 100%;
    background: #2a2a2a;
    display: flex;
    align-items: center;
    cursor: pointer;
}
.controls-box li:hover{
    background: #4d4f54;
}
.controls-box{
    box-shadow: 0px 1px 3px rgba(0, 0, 0, .25);
}

.banner-box img{
    width: 100%;
}
.banner-box{
    width: 300px;
    display: flex;
    overflow: auto;
}
.banner-box::-webkit-scrollbar{
    display: none;
}
.center-box{
    height: 100vh;
    width: 300px;
    background: #2b2d31;
}
.logo{
    width: 100%;
    height:62px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.list-box ul li i{
    width: 48px;
    height: 48px;
    background: #4d4f54;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 12px;
    margin: 0 auto;
    margin-bottom: 6px;
    transition: all 0.2s;
}
.list-box ul li i:hover{
    background: #78797e;
}
.list-box ul li i img{
    width: 30px;
    height: 30px;
}
.list-box ul li span{
    font-size: 13px;
}
.list-box ul li{
    margin-bottom: 20px;
    cursor: pointer;
}
.list-box ul{
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    text-align: center;
}
.list-box{
    height: calc(100vh - 65px);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.left-box{
    width: 68px;
    height: 100%;
    background: #1e1f22;
    color: #fff;
}
.skeleton-box{
    width: 100%;
    height: 100vh;
    background: #872727;
    display: flex;
}
</style>