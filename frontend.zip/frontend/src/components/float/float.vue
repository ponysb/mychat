
<script setup>
import { ref, onMounted,computed, onBeforeUnmount } from 'vue';
import { useMainStore } from "../../store/index";
import Axios from '../../../utils/request';
const stores = useMainStore();

const floatBox = ref(null);
const position = ref({ x: window.innerWidth - 200, y: 68 });
const isDragging = ref(false);
const hasDragged = ref(false);
let offsetX = 0;
let offsetY = 0;
  
const startDrag = (e) => {
    e.preventDefault();
    isDragging.value = true;
    const clientX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
    const clientY = e.type === 'touchstart' ? e.touches[0].clientY : e.clientY;
    offsetX = clientX - floatBox.value.offsetLeft;
    offsetY = clientY - floatBox.value.offsetTop;
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', stopDrag);
    document.addEventListener('touchmove', drag);
    document.addEventListener('touchend', stopDrag);
    document.addEventListener('selectstart', preventDefaultSelection);
};
  
const drag = (e) => {
    if (isDragging.value) {
        const clientX = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
        const clientY = e.type === 'touchmove' ? e.touches[0].clientY : e.clientY;
        position.value.x = clientX - offsetX;
        position.value.y = clientY - offsetY;
        hasDragged.value = true;
    }
};
  
const stopDrag = () => {
    isDragging.value = false;
    setTimeout(() => {
        hasDragged.value = false;
    }, 200);
    document.removeEventListener('mousemove', drag);
    document.removeEventListener('mouseup', stopDrag);
    document.removeEventListener('touchmove', drag);
    document.removeEventListener('touchend', stopDrag);
    document.removeEventListener('selectstart', preventDefaultSelection);
};

const preventDefaultSelection = (e) => {
    e.preventDefault(); // Prevent text selection
};
  
onMounted(() => {
    document.addEventListener('mouseleave', stopDrag);
});
  
onBeforeUnmount(() => {
    document.removeEventListener('mouseleave', stopDrag);
});


// 点击
const handleClick = (e) => {
    if(stores.user.username == ''){
        stores.login.show = true
        return;
    }


    if (hasDragged.value) {
        return;
    }
    e.preventDefault();
    e.stopPropagation();
    stores.drawer.visible = true;
}


// 时间格式转换
const formattedTime = computed(() => {
    const seconds = stores.badge.online_time;
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    if (hours > 0) {
        // 格式化为 "小时:分钟:秒"
        const formattedHours = hours.toString().padStart(2, '0');
        const formattedMinutes = minutes.toString().padStart(2, '0');
        const formattedSeconds = remainingSeconds.toString().padStart(2, '0');
        return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
    } else {
        // 格式化为 "分钟:秒"
        const formattedMinutes = minutes.toString();
        const formattedSeconds = remainingSeconds.toString().padStart(2, '0');
        return `${formattedMinutes}:${formattedSeconds}`;
    }
});


// 提交数据
function submitData() {

    Axios.post('/api/v1/timed/moyuData', {})
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}

// 计时循环
let count = 0;
// 延迟2秒执行
setTimeout(() => {
    const timer = setInterval(() => {
        if(stores.user.username != ''){
            stores.badge.online_time += 1;
            count++;
            if(count === 10){
                submitData();
                count = 0;
            }
        }

    }, 1000);
}, 2500)

</script>


<template>
    <div v-show="stores.float.visible"
      class="float-box" 
      @mousedown="startDrag"
      @touchstart="startDrag"
      :style="{ left: `${position.x}px`, top: `${position.y}px` }"
      ref="floatBox"
      @click="handleClick($event)"
    >
        <span class="login-text" v-if="stores.user.username == ''">登录后使用</span>
        <div v-if="!stores.user.username == ''" style="margin-top: 18px;">
            <p>摸到的🐟️</p>
            <p> <span style="font-size: 13px;">{{ stores.badge.fish_catch }}</span> 条</p>
            <p style="font-size: 13px;">{{ formattedTime }}⏰️</p>
        </div>
    </div>
</template>
  
<style scoped>
.login-text {
    font-size: 16px;
    line-height: 88px;
    color: #494949;
    font-weight: 500;
    text-shadow: 1px 1px 10px rgba(0, 0, 0, .3);
}
.float-box p {
    font-size: 13px;
    line-height: 19px;
    color: #727272;
    font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";
    font-weight: 500;
    text-shadow: 1px 1px 10px rgba(0, 0, 0, .3);
}
.float-box {
    position: fixed;
    z-index: 99999999;
    width: 88px;
    height: 88px;
    background: rgba(255, 255, 255, .8);
    backdrop-filter:saturate(200%) blur(5px);
    border-radius: 50px;
    cursor: pointer;
    box-shadow: 0 3px 10px 5px rgba(0, 0, 0, .05);
    text-align: center;
}
.float-box:hover{
    background: rgba(255, 255, 255, .9);
}
</style>
  