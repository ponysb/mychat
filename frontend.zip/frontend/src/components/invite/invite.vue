<script setup>
import { reactive } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import Axios from '../../../utils/request';
import { useMainStore } from "../../store/index";
const stores = useMainStore();
const router = useRouter();
const route = useRoute();
const data = reactive({
    name: '加载中...',
    desc:'加载中...',
    avatar:'default.jpg',
    users:0
})

// 加入聊天室
const joinChat = () => {
    let token = localStorage.getItem('mychatToken')
    const user = JSON.parse(atob(token.split('.')[1]))
    // 校验token是否有效
    if(!user.user_id&&!user.username){
        localStorage.removeItem('mychatToken')
        ElMessage({
            message: '登录信息已过期，请重新登录',
            type: 'error',
        })
        router.push({path: '/login'})
    }

    
    // 校验token是否过期
    if(Date.now() > user.exp * 1000){
        ElMessage({
            message: '登录信息已过期，请重新登录',
            type: 'error',
        })
        localStorage.removeItem('mychatToken')
        router.push({path: '/login'})
    }


    Axios.post('/api/v1/chats/joinRoom', {
        room_id: route.params.id,
    })
    .then(response => {
        router.push({path: '/chat/'+route.params.id})
    })
    .catch(error => {
        if(err.response.data.message === '用户已经在房间中'){
            router.push({path: '/chat/'+route.params.id})  
        }else{
            console.log(err)
            ElMessage.error(err.response.data.message)
        }
    });

}


// 获取房间信息
const getRoomInfo = () => {

    Axios.get('/api/v1/chats/easyGetRoomInfo', { room_id: route.params.id })
    .then(response => {
        // console.log(response);
        data.name = response.data.name
        data.desc = response.data.desc
        data.avatar = response.data.avatar
        data.users = response.data.users
    })
    .catch(error => {
        data.name = '加载失败'
        data.desc = '加载失败'
        console.log(error)
    });

}
getRoomInfo()
</script>

<template>
    <div class="invite">
        <div class="invite-content">
            <img :src="stores.config.port + '/group/'+data.avatar" alt="">
            <h1>{{ data.name }}</h1>
            <p>{{ data.desc }}</p>
            <div>
                <i></i>
                聊天室人数：{{ data.users }}
            </div>
            <span @click="joinChat()">加入聊天室</span>
        </div>
    </div>
</template>

<style scoped>
.invite-content span:hover{
    box-shadow: 0 5px 20px rgba(4, 157, 191, 0.5);
}
.invite-content span{
    display: block;
    margin-top: 10px;
    width: 180px;
    height: 50px;
    font-size: 14px;
    background: #2fa9ce;
    margin: 0 auto;
    margin-top: 50px;
    line-height: 50px;
    color: #fff;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
}
.invite-content i{
    display: inline-block;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #2fa9ce;
    margin-right: 5px;
    vertical-align: middle;
}
.invite-content div{
    display: flex;
    align-items: center;
    justify-content: center;
    color: #2fa9ce;
    font-size: 12px;
    margin-top: 20px;
}
.invite-content p{
    width: 320px;
    font-size: 14px;
    color: #666;
    line-height: 1.5;
    margin: 0 auto;
    margin-top: 20px;
}
.invite-content h1{
    font-size: 20px;
    font-weight: 600;
    color: #232323;
}
.invite-content img{
    width: 88px;
    height: 88px;
    background: #f0f0f0;
    border-radius: 50%;
    object-fit: cover;
    margin: 38px auto;
}
.invite-content{
    width: 380px;
    height: 500px;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
    margin: 0 auto;
    margin-top: 80px;
    text-align: center;
    background: #fff;
}
.invite {
    width: 100%;
    height: 100vh;
    background: #fff;
    padding: 0;
    overflow: hidden;
    background-image: url('../../assets/invite/pattern.png');
    background-size: cover; /* 使背景图片覆盖整个元素 */
    background-position: center; /* 将背景图片居中 */
    background-repeat: no-repeat; /* 防止背景图片重复 */
}
</style>