<script setup>
import { useRoute, useRouter } from 'vue-router';
import Menu from './menu.vue';
import Friends from './friends.vue';
import Drawer from './drawer/drawer.vue';
import Browser from './browser/window.vue';
import Float from './float/float.vue';
import Terminal from './chat/terminal.vue';
import Axios from '../../utils/request';
import { io } from "socket.io-client";
import { useMainStore } from "../store/index";
import router from '../router';
const stores = useMainStore();
const route = useRoute();
const router_ = useRouter();


if(localStorage.getItem('mychatToken')){
    // console.log('有token')
    initLogin()
}else{
    router_.push({path: '/login'})
    // console.log('没有token')
}


// 初始化登录状态
function initLogin(){
    try{
        let token = localStorage.getItem('mychatToken')
        const user = JSON.parse(atob(token.split('.')[1]))

        // 校验token是否有效
        if(!user.user_id&&!user.username){
            localStorage.removeItem('mychatToken')
            router_.push({path: '/login'})
        }

        
        // 校验token是否过期
        if(Date.now() > user.exp * 1000){
            localStorage.removeItem('mychatToken')
            router_.push({path: '/login'})
        }

        Axios.post('/api/v1/users/check_login', {})
        .then(response => {
            // console.log(response)
            // 存放用户信息到公共空间
            stores.user = {
                rooms: response.data.rooms.rooms,  // 房间列表
                username: response.data.username,  // 用户名
                avatar: response.data.avatar,  // 头像
                nickname: response.data.nickname,  // 昵称
                status: response.data.status,  // 状态
                email: response.data.email,  // 邮箱
                phone: response.data.phone,  // 手机号
                gender: response.data.gender,  // 性别
                friends: response.data.friends,  // 好友列表
                signature: response.data.signature,  // 个性签名
            }

            // 存储用户信息到本地
            localStorage.setItem("mychatUser", JSON.stringify(stores.user));  // 存储用户信息

            // 判断房间列表有没有route.query.room_id
            if(route.name != 'app'&&route.name != 'AppContent'){
                // 判断是否带着房间id来的
                if(route.params.id){
                    if(!response.data.rooms.rooms_id.includes(route.params.id)){
                        router.push({path: '/invite/'+response.data.rooms.rooms_id[0]})
                        return
                    }else{
                        let index = response.data.rooms.rooms_body.findIndex(item => item.room_id === route.params.id);
                        stores.select_room = {
                            room_id: route.params.id,  // 当前选择的房间id
                            index: index,  // 当前选择的房间索引
                            messages: [],  // 当前房间消息列表
                        }
                    }
                }else{
                    stores.select_room = {
                        room_id: response.data.rooms.rooms_body[0].room_id,  // 当前选择的房间id
                        index: 0,  // 当前选择的房间索引
                        messages: [],  // 当前房间消息列表
                    }
                    router.push({path: '/chat/'+response.data.rooms.rooms_body[0].room_id})

                    console.log(response.data.rooms)
                    console.log(stores.select_room)
                }
            }


            // 连接socket
            stores.socket = io(stores.config.socket, {
                query: { user_id: response.data.user_id },
            });

            // 确认连接成功后加入房间
            stores.socket.on("connect", () => {
                console.log("socket connected");  // 连接成功
                stores.socket.emit("join_room", {rooms: response.data.rooms.rooms_id});  // 加入房间
                stores.rooms = response.data.rooms.rooms_body  // 房间列表
                stores.socket_message()  // 监听消息
            });
        })
        .catch(error => {
            console.log(error)
            ElMessage.error(error.response.data.message)
        });

    } catch (error) {
        console.log(error)
        ElMessage.error('登录失效，请重新登录')
        localStorage.removeItem('mychatToken')
        router_.push({path: '/login'})
    }
}



// 统计
let onePxUrl = stores.config.port + '/img/1px';
if(route.query.ac){
    stores.ac = route.query.ac;
    onePxUrl = 'http://localhost:3000/img/1px?ac='+route.query.ac;
}

// 悬浮球状态
let float = JSON.parse(localStorage.getItem('float'));
if(float){
    stores.float.visible = float.visible;
}



</script>

<template>
    <div v-if="stores.terminal">
        <Terminal />
    </div>

    <div v-show="!stores.terminal" class="container">
        <img style="display: none;" :src="onePxUrl" alt="">
        <Float />
        <!-- 侧边栏 -->
        <Drawer />
        
        <!-- 浏览器窗口 -->
        <Browser />

        <!-- 菜单栏 -->
        <div class="menu">
            <Menu />
        </div>
        <!-- 好友栏 -->
        <div v-if="stores.rooms.length > 0" class="friends">
            <Friends />
        </div>
        <!-- 聊天栏 -->
        <div v-if="stores.rooms.length > 0" class="chat-view">
            <router-view />
        </div>
    </div>
</template>

<style scoped>
/* 自定义样式 */
.container {
    height: 100vh;
    width: 100vw;
    display: flex;
}

.menu {
    width: 72px;
    background: #ffffff;
    border-right: 1px solid #e8e8e8;
}

.friends {
    width: 240px;
    background-color: #f7f7f7;
    border-right: 1px solid #e8e8e8;
}

.chat-view {
    width: calc(100% - 312px);
    height: 100%;
    background: #f1f1f1;
}

@media (max-width: 980px) {
    .chat-view {
        width: calc(100% - 72px);
    }
    .friends{
        display: none;
    }
}
</style>