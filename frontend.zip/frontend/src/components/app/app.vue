<script setup>
import { ref, reactive } from 'vue'
import MyApp from './myApp.vue';
import Axios from '../../../utils/request';
import { useRouter } from 'vue-router';
import { useMainStore } from "../../store/index";
import icon from '../../assets/logo.svg'
const stores = useMainStore();
const data = reactive({
    select: 0,    // 选择的分类

    apps: [],  // 应用列表
    top: [],    // 应用推荐列表

    switchMyApps: {  // 摸鱼应用和我添加的应用界面切换
        title: '我添加的应用',
        visible: false
    },

    keyword:'',

    title: '最新加入的应用',

    searchPopup:{
        visible: false,
        data: [
            {title: "站内", url: "站内", icon:icon, desc:"站内搜索"},
            {title: "资源避难所", url: "https://www.flysheep6.com/?s=", icon:"", desc:"单机游戏资源下载"},
            {title: "穷人论坛", url: "https://www.taiqiongle.com/?q=", icon:"", desc:"分享破解软件/影视/电子书/酷站！"},
            {title: "夸克资源搜索", url: "https://www.taiqiongle.com/?q=", icon:"", desc:"专注夸克网盘资源分享的网站"},
            {title: "工具盘", url: "https://gjpan.com/?s=", icon:"", desc:"夸克网盘资源每日更新"},
        ],
        select: 0,
        input: {
            title:'',
            url: '',
            desc: ''
        }
    }
})
const Router = useRouter();

// 请求数据
getApps()
function getApps() {

    Axios.post('/api/v1/chatApps/getChatApp', {})
    .then(response => {
        // console.log(response.data.users)
        data.apps = response.data
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}


// app鼓掌，鼓掌点击效果
function clickClap(app_id,index,e){
    e.stopPropagation(); 
    Axios.post('/api/v1/chatApps/appLike', {app_id})
    .then(response => {
        console.log(response)
        data.apps[index].interact.like.push(response.data)
    })
    .catch(error => {
        console.log(error);
    });

    var a_idx = 0;

    var a = new Array("👏");

    var heart = document.createElement("b"); //创建b元素
    heart.onselectstart = new Function('event.returnValue=false'); //防止拖动

    document.body.appendChild(heart).innerHTML = a[a_idx]; //将b元素添加到页面上
    a_idx = (a_idx + 1) % a.length;
    heart.style.cssText = "position: fixed;left:-100%;"; //给p元素设置样式

    var f = 16, // 字体大小
        x = event.clientX - f / 2, // 横坐标
        y = event.clientY - f, // 纵坐标
        c = randomColor(), // 随机颜色
        a = 1, // 透明度
        s = 1.2; // 放大缩小

    var timer = setInterval(function () { //添加定时器
        if (a <= 0) {
            document.body.removeChild(heart);
            clearInterval(timer);
        } else {
            heart.style.cssText = "font-size:16px;cursor: default;position: fixed;color:" +
                c + ";left:" + x + "px;top:" + y + "px;opacity:" + a + ";transform:scale(" +
                s + ");";

            y--;
            a -= 0.016;
            s += 0.002;
        }
    }, 15)

    
    // 随机颜色
    function randomColor() {

        return "rgb(" + (~~(Math.random() * 255)) + "," + (~~(Math.random() * 255)) + "," + (~~(Math
        .random() * 255)) + ")";

    }
}


// 搜索应用
function searchApp(){
    if(data.searchPopup.data[data.searchPopup.select].url != '站内'){
        window.open(data.searchPopup.data[data.searchPopup.select].url + data.keyword)
        return
    }

    if(data.keyword === ''){
        ElMessage.error('请输入关键字')
        data.title = '最新加入的应用'
        getApps()
        return
    }

    Axios.post('/api/v1/chatApps/searchChatApp', {
        keyword: data.keyword
    })
    .then(response => {
        // console.log(response.data.users)
        if(response.data.length === 0){
            ElMessage.error('没有搜索到相关应用')
            data.title = '最新加入的应用'
            getApps()
        }else{
            data.title = data.keyword+' 的搜索结果'
            data.apps = response.data
        }
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}


// 点击标签
function selectTag(e){
    if(e === ''){
        data.title = '最新加入的应用'
        getApps()
        return
    }


    Axios.get('/api/v1/chatApps/searchChatApp', {
        tag: e
    })
   .then(response => {
        if(response.data.length === 0){
            ElMessage.error('没有搜索到相关应用')
        }
        if(response.data.length !== 0){
            data.apps = response.data
            data.title = '标签为 '+ e + ' 的应用'
        }else{
            data.title = '我添加的应用'
            getApps()
        }
        
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });
}


// 获取全部标签
getChatAppTag()
function getChatAppTag(){
    Axios.get('/api/v1/chatApps/getChatAppTag', {})
   .then(response => {
        data.tags = response.data
    })
   .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });
}


// 选择引擎
function selectEngine(index){
    // console.log(index)
    data.searchPopup.select = index
    saveSearch()
}


// tab切换
function searchTab(e){
    if(e.keyCode === 9){
        e.preventDefault()
        if(data.searchPopup.select === data.searchPopup.data.length -1){
            data.searchPopup.select = 0
        }else{
            data.searchPopup.select++
        }
        saveSearch()
    }
}

// 添加搜索引擎
function addSearch(){
    if(data.searchPopup.input.url === ''){
        ElMessage.error('请输入搜索引擎链接')
        return
    }

    // 校验是否为链接正则复杂逻辑校验
    let reg = /^((ht|f)tps?):\/\/[\w\-]+(\.[\w\-]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$/;
    if(!reg.test(data.searchPopup.input.url)){
        ElMessage.error('请输入正确的搜索引擎链接')
        return
    }

    if(data.searchPopup.input.title === ''){
        ElMessage.error('请输入搜索引擎名称')
        return
    }
    data.searchPopup.data.unshift({
        title: data.searchPopup.input.title,
        url: data.searchPopup.input.url,
        icon: '',
        desc:''
    })
    saveSearch()
}

// 搜索引擎设置保存到本地
function saveSearch(){
    localStorage.setItem('mychatSearch', JSON.stringify({
        select: data.searchPopup.select,
        data: data.searchPopup.data,
    }))
}

if(localStorage.getItem('mychatSearch')){
    data.searchPopup.data = JSON.parse(localStorage.getItem('mychatSearch')).data
    data.searchPopup.select = JSON.parse(localStorage.getItem('mychatSearch')).select   
}

</script>

<template>

<el-dialog
    v-model="data.searchPopup.visible"
    title="搜索引擎管理"
    width="580"
>
    <div class="search-popup-box">
        <div class="add-search">
            <el-input v-model="data.searchPopup.input.url" style="width: 234px" placeholder="请输入搜索引擎链接..." />
            <el-input v-model="data.searchPopup.input.title" style="width: 234px; margin-left: 10px;" placeholder="请输入搜索引擎名称..." />
            <el-button @click="addSearch" type="primary" style="margin-left: 10px;">添加</el-button>
        </div>
        <ul>
            <li v-for="(item,index) in data.searchPopup.data" :key="index">
                <div class="search-popup-box-left">
                    <div class="search-popup-icon">
                        <img v-if="item.icon === ''" :src="'https://icon.bqb.cool?url='+item.url" alt="">
                        <img v-else :src="item.icon" alt="">
                    </div>
                    <div class="search-popup-info">
                        <h1>{{item.title}}</h1>
                        <p :title="item.url" v-if="item.desc === ''">{{item.url}}</p>
                        <p :title="item.desc" v-else>{{item.desc}}</p>
                    </div>
                </div>

                <el-button @click="() => {
                    data.searchPopup.data.splice(index, 1)
                }" style="margin-right: 10px;" size="small" link type="primary">移除</el-button>
            </li>
        </ul>
    </div>
</el-dialog>

<div class="app-box">
    <!-- 头部 -->
    <div class="app-header">
        <div class="app-header-left">
            摸鱼应用
            <span @click="() => {
                if(data.switchMyApps.visible){
                    data.switchMyApps.visible = false
                    data.switchMyApps.title = '我添加的应用'
                }else{
                    data.switchMyApps.visible = true
                    data.switchMyApps.title = '← 所有应用'
                }
            }" class="app-header-me">{{data.switchMyApps.title}}</span>
        </div>

        <div class="app-header-right">
            <el-dropdown placement="bottom">
                <div class="icon-box">
                    <img v-if="data.searchPopup.data[data.searchPopup.select].icon === ''" :src="'https://icon.bqb.cool?url='+data.searchPopup.data[data.searchPopup.select].url" alt="">
                    <img v-else :src="data.searchPopup.data[data.searchPopup.select].icon" alt="">
                </div>
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item @click="selectEngine(index)" v-for="(item,index) in data.searchPopup.data" :key="index">
                            <img class="search-icon" v-if="item.icon === ''" :src="'https://icon.bqb.cool?url='+item.url" alt="">
                            <img class="search-icon" v-else :src="item.icon" alt="">
                            {{item.title}}
                        </el-dropdown-item>

                        <el-dropdown-item @click="data.searchPopup.visible = true">
                            <el-icon><Plus /></el-icon>
                            添加
                        </el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>

            <input @keydown="searchTab($event)" @keyup.enter="searchApp" v-model="data.keyword" placeholder="搜索..." type="text" />
            <el-icon @click="searchApp" class="el-icon-search"><Search /></el-icon>
        </div>
    </div>

    <template v-if="data.switchMyApps.visible">
        <MyApp />
    </template>

    <div v-else class="app-body">
        <!-- 应用内容 -->
        <div class="app-content">
            <div class="app-content-left">
                <ul>
                    <div class="top-title">
                        <h1>{{ data.title }}</h1>
                    </div>

                    <li v-for="(item,index) in data.apps" :key="index" @click="Router.push({path: '/AppContent/'+item.app_id})">
                        <div style="display: flex; width: calc(100% - 150px);">
                            <div class="app-icon">
                                <img v-if="item.icon === ''" :src="'https://icon.bqb.cool?url='+item.url" alt="">
                                <img v-else :src="stores.config.port + '/app/'+item.icon" alt="">
                            </div>

                            <div class="app-info">
                                <div class="app-title">
                                    <h1>{{item.title}}</h1>
                                    <div class="skip-box">
                                        <el-icon><Position /></el-icon>
                                        <a :href="item.url" target="_blank"
                                            @click="(e) => {
                                            e.stopPropagation()
                                        }"
                                        >打开源站</a>
                                    </div>
                                </div>
                                <p>{{ item.desc }}</p>
                                
                                <div class="app-tag">
                                    <span v-for="(itemSub, index) in item.tag" :key="index">{{itemSub}}</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="interact-box">
                            <div @click="clickClap(item.app_id,index, $event)">
                                <img src="../../assets/app/guzhang.svg" alt="">
                                <h5>{{ item.interact.like.length }}</h5>
                            </div>

                            <div style="margin-left: 10px; line-height: 58px;"
                                @click="(e) => {
                                    e.stopPropagation()
                                    stores.browser.tabs.push({
                                        title: item.title,
                                        desc: item.desc,
                                        url: item.url
                                    })
                                    stores.browser.visible = true
                                }"
                            >
                                打开
                            </div>
                        </div>
                    </li>
                </ul>
            </div>

            <div class="app-content-right">
                <div style="position: fixed;">
                    <div class="top-title">
                        <h1>标签分类</h1>
                    </div>
                    <div class="tag-box">
                        <span @click="selectTag('')">全部</span>
                        <span @click="selectTag(item.tag_name)" v-for="(item,index) in data.tags" :key="index">{{ `${item.tag_name}（${item.app_num}）` }}</span>
                    </div>

                    <!-- <div class="banner-box">

                    </div> -->
                </div>
            </div>
        </div>
    </div>

</div>
</template>

<style scoped>
.search-popup-info p{
    font-size: 13px;
    margin-top: 5px;
    color: #6e6e6e;
    /* 超出... */
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}
.search-popup-info h1{
    font-size: 14px;
    color: #333;
}
.search-popup-info{
    margin-left: 10px;
}
.search-popup-icon img{
    width: 22px;
    height: 22px;
}
.search-popup-icon{
    width: 22px;
    height: 22px;
    border: 6px solid #ffffff;
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    margin-left: 10px;
}
.search-popup-box-left{
    display: flex;
}
.search-popup-box li{
    width: 268px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #f4f4f4;
    border-radius: 8px;
    margin-bottom: 12px;
}
.search-popup-box ul{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    max-height: 500px;
    overflow: auto;
}
.add-search{
    margin-bottom: 10px;
}
.interact-box div:hover{
    background: #f7ffff;
    border: 2px solid #2f9da7;
}
.interact-box div img{
    width: 25px;
    height: 25px;
    margin-top: 6px;
    margin-bottom: 2px;
}
.interact-box div{
    width: 58px;
    height: 58px;
    font-size: 14px;
    border-radius: 8px;
    border: 2px solid #e9e9e9;
    cursor: pointer;
    text-align: center;
    transition: all 0.2s;
    color: #333;
}
.interact-box{
    display: flex;
    justify-content: flex-end;
    margin-right: 20px;
}
.skip-box{
    width: 88px;
    margin-top: 2px;
    display: none;
    cursor: pointer;
}
.skip-box:hover{
    color: #2f9da7;
}
.skip-box:hover a{
    color: #2f9da7;
}
.skip-box i{
    font-size: 14px;
    margin-right: 3px;
}
.skip-box a{
    font-size: 14px;
    color: #333;
    text-decoration: none;
}
.app-title{
    display: flex;
    margin-right: 10px;
}
.app-info h1{
    font-size: 20px;
    font-weight: 300;
    color: #333;
    margin-right: 6px;
    cursor: pointer;
    /* 超出... */
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}
.app-info h1:hover{
    color: #2f9da7;
}
.app-info p{
    font-size: 14px;
    margin-top: 8px;
    letter-spacing: 1px;
    margin-right: 10px;
    line-height: 1.5;
    color: #64748b;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
.app-info{
    margin-left: 10px;
}
.app-tag{
    margin-top: 13px;
}
.app-tag span{
    display: inline-block;
    font-size: 12px;
    color: #999;
    margin-right: 8px;
    margin-bottom: 8px;
    padding: 5px 8px;
    border-radius: 5px;
    background: #f5f5f5;
    border: 1px solid #e9e9e9;
    cursor: pointer;
}
.interact-box{
    width: 150px;
    height: 20px;
}
.app-icon img{
    width: 58px;
    height: 58px;
    border-radius: 8px;
    object-fit: cover;
}
.app-icon{
    margin-left: 18px;
    width: 58px;
    height: 58px;
}
.app-content-left li{
    width: 100%;
    background: #ffffff;
    border-radius: 8px;
    margin-top: 20px;
    padding-top: 16px;
    padding-bottom: 10px;
    display: flex;
    justify-content: space-between;
}
.app-content-left li:hover .skip-box{
    display: flex;
}
.app-content-left{
    width: calc(100% - 300px);
}
.app-content-left ul{
    margin-bottom: 20px
}
.app-content{
    width: 66%;
    margin: 0 auto;
    display: flex;
}


.tag-box span{
    display: inline-block;
    font-size: 12px;
    color: #999;
    margin-right: 8px;
    margin-bottom: 8px;
    padding: 5px 8px;
    border-radius: 5px;
    background: #f5f5f5;
    border: 1px solid #e9e9e9;
    cursor: pointer;
}
.tag-box span:hover{
    background: #e9e9e9;
}
.tag-box{
    padding: 0 10px;
    border-bottom: 10px solid #ffffff;
    border-top: 10px solid #ffffff;
    box-sizing: border-box;
    word-break: break-all;
    overflow: auto;
    width: 300px;
    max-height: calc(100vh - 500px);
    margin-top: 20px;
    border-radius: 8px;
    background: #ffffff;
}
.top-title h1{
    font-size: 20px;
    font-weight: 600;
    color: #333;
    margin-top: 28px;
}
.app-content-right{
    width: 300px;
    margin-left: 16px;
}
.banner-box{
    width: 300px;
    height: 160px;
    border-radius: 8px;
    margin-top: 16px;
    background: #fff;
}
.app-header-me{
    padding: 10px;
    font-size: 13.5px;
    background: #fff;
    font-weight: 500;
    background: #35acb7;
    color: #fff;
    border-radius: 5px;
    cursor: pointer;
    margin-left: 10px;
}
.app-header-me:hover{
    background: #2f9da7;
}
.el-icon-search{
    font-size: 22px;
    color: #b5bac1;
    cursor: pointer;
}
.search-icon{
    width: 16px;
    margin-right: 5px;
}
.icon-box{
    width: 20px;
    height: 20px;
    margin-left: 8px;
    background: #ffffff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}
.icon-box:hover{
    background: #f8f8f8;
}
.icon-box img{
    width: 12px;
}
.app-header-right input{
    width: 200px;
    height: 22px;
    margin-left: 5px;
    background: #f4f4f4;
    color: #333;
    border: none;
    outline: none;
}
.app-header-right{
    height: 38px;
    background: #f4f4f4;
    display: flex;
    align-items: center;
    border-radius: 5px;
    padding-right: 10px;
}
.app-header-left{
    display: flex;
    align-items: center;
    font-size: 20px;
    color: #333;
    font-weight: 800;
}
.app-header{
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 60px;
    background: #fff;
    padding: 0 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    position: relative;
    z-index: 2;
}
.app-body{
    height: calc(100% - 60px);
    overflow: auto;
}
.app-box{
    height: 100%;
}

@media screen and (max-width: 1400px) {
    .app-content-right{
        display: none;
    }
    .app-content-left{
        width: 100%;
    }
}
</style>