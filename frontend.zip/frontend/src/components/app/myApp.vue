<script setup>
import { reactive } from 'vue'
import Axios from '../../../utils/request';
import { useRouter } from 'vue-router';
import { useMainStore } from "../../store/index";
const stores = useMainStore();

const router = useRouter();

const data = reactive({
    myApps:[],    // 我的应用

    editMyApp:{    // 编辑我的应用
        visible: false,
        form: '',
        app_id: '',
    },

    placard: {    // 海报
        visible: false,
        form: [],
    },
})



// 请求我的应用数据
getMyApps()
function getMyApps() {

    Axios.post('/api/v1/chatApps/getMyChatApp', {})
    .then(response => {
        data.myApps = response.data
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}


// 上传头像
function avatarUpload() {
    // console.log('上传头像')
    const input = document.createElement('input');
    input.type = 'file';
    input.onchange = e => {
        const file = e.target.files[0];
        const type = file.name.split('.').pop().toLowerCase();
        if (type !== 'jpg' && type !== 'jpeg' && type !== 'png' && type !== 'gif' && type !== 'webp' && type !== 'bmp') {
            ElMessage({
                message: '仅支持 jpg、jpeg、png、gif、webp、bmp 格式的图片',
                type: 'warning',
            })
            return;
        }

        const form = new FormData();
        form.append('file', file);

        // console.log(file)
        Axios.post('/api/v1/chatApps/uploadChatAppIcon', form, {
            'Content-Type': 'multipart/form-data',
        })
        .then(response => {
            data.editMyApp.form.icon = response.data.file.newFilename
            ElMessage({
                message: '上传成功',
                type:'success',
            })
        })
        .catch(error => {
            console.log(error)
            ElMessage({
                message: '上传失败',
                type: 'error',
            })
        });

    };
    input.click();
}


// 上传海报
function placardUpload() {
    // console.log('上传海报')
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.onchange = e => {
        const files = e.target.files;
        const form = new FormData();
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const type = file.name.split('.').pop().toLowerCase();
            if (type !== 'jpg' && type !== 'jpeg' && type !== 'png' && type !== 'gif' && type !== 'webp' && type !== 'bmp') {
                ElMessage({
                    message: '仅支持 jpg、jpeg、png、gif、webp、bmp 格式的图片',
                    type: 'warning',
                })
                return;
            }
            form.append('file', file);
        }


        Axios.post('/api/v1/chatApps/uploadChatAppPlacard', form)
        .then(response => {
            data.placard.form.push({
                title:response.data.file.originalFilename,
                url:response.data.file.newFilename, 
                type:'prview'
            })
            ElMessage({
                message: '上传成功',
                type:'success',
            })
        })
        .catch(error => {
            console.log(error)
            ElMessage({
                message: '上传失败',
                type: 'error',
            })
        });

    };
    input.click();
}


// 提交修改海报
function sendPlacard() {
    // console.log('提交修改海报')

    Axios.post('/api/v1/chatApps/editChatAppPlacard', {
        app_id: data.placard.app_id,
        placard: data.placard.form
    })
    .then(response => {
        ElMessage({
            message: '提交成功',
            type:'success',
        })
        data.placard.visible = false
        getMyApps()
    })
    .catch(error => {
        console.log(error)
        ElMessage({
            message: '提交失败',
            type: 'error',
        })
    });

}


// 更新我的应用
function editMyApp() {
    // console.log('更新我的应用')

    Axios.post('/api/v1/chatApps/editChatApp', {
        app_id: data.editMyApp.form.app_id,
        title: data.editMyApp.form.title,
        desc: data.editMyApp.form.desc,
        url: data.editMyApp.form.url,
        icon: data.editMyApp.form.icon,
        tag: data.editMyApp.form.tag.split(','),
    })
    .then(response => {
        ElMessage({
            message: '更新成功',
            type:'success',
        })
        data.editMyApp.visible = false
        getMyApps()
    })
    .catch(error => {
        console.log(error)
        ElMessage({
            message: '更新失败',
            type: 'error',
        })
    });

}


// 删除我的应用
function deleteMyApp(app_id) {

    Axios.post('/api/v1/chatApps/deleteChatApp', {
        app_id: app_id
    })
    .then(response => {
        ElMessage({
            message: '删除成功',
            type:'success',
        })
        getMyApps()
    })
    .catch(error => {
        console.log(error)
        ElMessage({
            message: '删除失败',
            type: 'error',
        })
    });

}
</script>

<template>
<!-- 编辑应用 -->
<el-dialog
    v-model="data.editMyApp.visible"
    title="编辑应用"
    width="500"
>
    <el-form :model="data.editMyApp.form" label-width="80px">
        <el-form-item label="应用logo" required>
            <el-avatar @click="avatarUpload" v-if="data.editMyApp.form.icon === ''" :src="'https://icon.bqb.cool?url='+data.editMyApp.form.url" />
            <el-avatar @click="avatarUpload" v-else :src="stores.config.port + '/app/'+data.editMyApp.form.icon" />
        </el-form-item>

        <el-form-item label="应用名称" required>
            <el-input v-model="data.editMyApp.form.title" placeholder="请输入应用名称"></el-input>
        </el-form-item>

        <el-form-item label="应用描述" required>
            <el-input v-model="data.editMyApp.form.desc" placeholder="请输入应用描述"></el-input>
        </el-form-item>

        <el-form-item label="应用链接" required>
            <el-input v-model="data.editMyApp.form.url" placeholder="请输入应用链接"></el-input>
        </el-form-item>

        <el-form-item label="应用标签">
            <el-input v-model="data.editMyApp.form.tag" placeholder="请输入标签"></el-input>
            <p style="font-size: 12px; color: brown;">多标签之间用 <span style="color: red; font-weight: bold;">英文逗号</span> 分割，例如：生活,学习,工作</p>
        </el-form-item>
    
        <el-button type="primary" @click="editMyApp">保存</el-button>
    </el-form>

</el-dialog>


<!-- 海报弹窗 -->
<el-dialog
    v-model="data.placard.visible"
    title="海报"
    width="500"
>
    <el-button type="primary" link @click="placardUpload">上传海报</el-button>
    <div style="background: #f1f1f1; margin-top: 10px; display: flex; justify-content: space-between; padding: 8px; border-radius: 5px; align-items: center;" v-for="(item, index) in data.placard.form">
        <img style="width: 100px; height: 68px; border-radius: 5px; object-fit: cover;" :src="stores.config.port + '/placard/'+item.url" alt="">
        <span>{{ item.title }}</span>
        <el-button type="primary" link @click="data.placard.form.splice(index, 1)">删除</el-button>
    </div>

    <el-button type="primary" v-if="data.placard.form.length > 0" style="margin-top: 10px;" @click="sendPlacard">提交修改</el-button>
    
</el-dialog>

<!-- 我的应用 -->
<div class="app-body">
    <div class="app-content">
        <h1>我的应用</h1>
        <el-table :data="data.myApps" style="width: 100%; margin-top: 20px;">
            <el-table-column prop="app_id" label="ID" width="65">
                <template #default="{ row }">
                    <el-avatar v-if="row.icon === ''" :src="'https://icon.bqb.cool?url='+row.url" />
                    <el-avatar v-else :src="stores.config.port + '/app/'+row.icon" />
                </template>
            </el-table-column>
            <el-table-column prop="title" label="应用名称" width="180">
                <template #default="{ row }">
                    <el-button link type="primary" @click="router.push('/AppContent/'+row.app_id)">{{ row.title }}</el-button>
                </template>
            </el-table-column>
            <el-table-column prop="desc" label="应用描述" width="280" />
            <el-table-column prop="url" label="应用链接" width="180" />
            <el-table-column prop="placard" label="海报" width="80">
                <template #default="{ row }">
                    <el-button @click="data.placard.form = row.placard; data.placard.app_id = row.app_id; data.placard.visible = true" link type="primary">查看</el-button>
                </template>
            </el-table-column>
            <el-table-column prop="interact" label="互动" width="80">
                <template #default="{ row }">
                    <span>喜欢：{{row.interact.like.length}}</span><br />
                    <span>热度：{{row.interact.see.length}}</span><br />
                    <!-- <span>评论：{{row.interact.comment.length}}</span><br /> -->
                </template>
            </el-table-column>
            <el-table-column prop="tag" label="标签" width="180">
                <template #default="{ row }">
                    <el-tag style="margin-bottom: 5px; margin-right: 5px;" v-for="(tag, index) in row.tag" :key="index" type="primary">{{tag}}</el-tag>
                </template>
            </el-table-column>
            
            <el-table-column prop="createdAt" label="创建时间" width="180">
                <template #default="{ row }">
                    {{ stores.formatDate(row.createdAt) }}
                </template>
            </el-table-column>
            
            <el-table-column  fixed="right" label="操作" width="180">
                <template #default="{ row }">
                    <el-button link type="primary" @click="data.editMyApp.visible = true; data.editMyApp.form = row">编辑</el-button>
                    <el-popconfirm title="确定删除该应用吗？" @confirm="deleteMyApp(row.app_id)" ok-text="确定" cancel-text="取消">
                        <template #reference>
                            <el-button link type="danger">删除</el-button>
                        </template>
                    </el-popconfirm>

                </template>
            </el-table-column>
        </el-table>
    </div>
    
    <div v-if="data.myApps.length === 0">
        <el-empty style="margin-top: 200px;" :image-size="200" />
    </div>
</div>
</template>

<style scoped>
.app-content h1{
    font-size: 22px;
    line-height: 1.2;
    font-weight: 600;
    color: #f2f3f5;
    margin-top: 22px;
    margin-bottom: 6px;
    padding-left: 32px;
}
.app-content{
    width: 76%;
    margin: 0 auto;
    /* background: #b5bac1; */
}
.app-body{
    height: calc(100% - 60px);
    overflow: auto;
}
</style>