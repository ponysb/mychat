<script setup>
import { reactive } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import Axios from '../../../utils/request';
import { useMainStore } from "../../store/index";
const stores = useMainStore();

const router = useRouter()
const route = useRoute()

const data = reactive({
    appData: '',

    hot:0,    // 热度

    comments: [],    // 评论

    commentText: '',    // 评论内容

    Loading: false,    // 加载状态

})


// 获取应用详情
getAppDetail()
function getAppDetail() {

    Axios.post('/api/v1/chatApps/getChatAppDetail', {
        app_id: route.params.id
    })
    .then(response => {
        data.appData = response.data
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}

// 获取热度
getInteract()
function getInteract() {

    Axios.get('/api/v1/chatApps/getBrowserHistory'+route.params.id, {})
    .then(response => {
        data.hot = response.data
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}

// 获取评论
getCommentList()
function getCommentList() {

    Axios.post('/api/v1/chatApps/getCommentList', {
        app_id: route.params.id
    })
    .then(response => {
        data.comments = response.data
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}

// 评论发送
function sendComment() {
    if (data.commentText.trim() === '') {
        return
    }


    Axios.post('/api/v1/chatApps/sendComment', {
        app_id: route.params.id,
        content: data.commentText
    })
    .then(response => {
        // console.log(response.data)
        data.commentText = ''
        getCommentList()
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

}


// app鼓掌，鼓掌点击效果
function clickClap(){


    Axios.post('/api/v1/chatApps/appLike', {
        app_id: route.params.id
    })
    .then(response => {
        // console.log(response.data)
        data.appData.interact.like.push(response.data)
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });

    var a_idx = 0;

    var a = new Array("👏");

    var heart = document.createElement("b"); //创建b元素
    heart.onselectstart = new Function('event.returnValue=false'); //防止拖动

    document.body.appendChild(heart).innerHTML = a[a_idx]; //将b元素添加到页面上
    a_idx = (a_idx + 1) % a.length;
    heart.style.cssText = "position: fixed;left:-100%;"; //给p元素设置样式

    var f = 16, // 字体大小
        x = event.clientX - f / 2, // 横坐标
        y = event.clientY - f, // 纵坐标
        c = randomColor(), // 随机颜色
        a = 1, // 透明度
        s = 1.2; // 放大缩小

    var timer = setInterval(function () { //添加定时器
        if (a <= 0) {
            document.body.removeChild(heart);
            clearInterval(timer);
        } else {
            heart.style.cssText = "font-size:16px;cursor: default;position: fixed;color:" +
                c + ";left:" + x + "px;top:" + y + "px;opacity:" + a + ";transform:scale(" +
                s + ");";

            y--;
            a -= 0.016;
            s += 0.002;
        }
    }, 15)

    
    // 随机颜色
    function randomColor() {

        return "rgb(" + (~~(Math.random() * 255)) + "," + (~~(Math.random() * 255)) + "," + (~~(Math
        .random() * 255)) + ")";

    }
}

// 评论鼓掌
function clickCommentClap(comment_id, index){
    // console.log(comment_id, index)

    Axios.post('/api/v1/chatApps/commentLike', {
        comment_id: comment_id
    })
    .then(response => {
        // console.log(response.data)
        data.comments[index].interact.like.push(response.data)
    })
    .catch(error => {
        ElMessage({
            message: error.response.data.message,
            type: 'error',
        })
        console.log(error);
    });


    var a_idx = 0;

    var a = new Array("👏");

    var heart = document.createElement("b"); //创建b元素
    heart.onselectstart = new Function('event.returnValue=false'); //防止拖动

    document.body.appendChild(heart).innerHTML = a[a_idx]; //将b元素添加到页面上
    a_idx = (a_idx + 1) % a.length;
    heart.style.cssText = "position: fixed;left:-100%;"; //给p元素设置样式

    var f = 16, // 字体大小
        x = event.clientX - f / 2, // 横坐标
        y = event.clientY - f, // 纵坐标
        c = randomColor(), // 随机颜色
        a = 1, // 透明度
        s = 1.2; // 放大缩小

    var timer = setInterval(function () { //添加定时器
        if (a <= 0) {
            document.body.removeChild(heart);
            clearInterval(timer);
        } else {
            heart.style.cssText = "font-size:16px;cursor: default;position: fixed;color:" +
                c + ";left:" + x + "px;top:" + y + "px;opacity:" + a + ";transform:scale(" +
                s + ");";

            y--;
            a -= 0.016;
            s += 0.002;
        }
    }, 15)

    
    // 随机颜色
    function randomColor() {

        return "rgb(" + (~~(Math.random() * 255)) + "," + (~~(Math.random() * 255)) + "," + (~~(Math
        .random() * 255)) + ")";

    }
}


// 浏览器打开
function browserClick(e){
    window.open(e)
}
</script>

<template>
<div v-if="data.appData != ''" style="height: 100%; overflow: auto;">
    <div class="app-content">
        <el-icon @click="router.push({path: '/app'})"><Back /></el-icon>
        <img class="app-logo" v-if="data.appData.icon === ''" :src="'https://icon.bqb.cool?url='+data.appData.url" alt="">
        <img class="app-logo" v-if="data.appData.icon != ''" :src="stores.config.port + '/app/'+data.appData.icon" alt="">
        <div class="app-x1">
            <h1>{{data.appData.title}}</h1>
            <div>
                <!-- <el-button>添加到房间</el-button> -->
                <el-button @click="() => {
                    stores.browser.tabs.push({
                        title: data.appData.title,
                        desc: data.appData.desc,
                        url: data.appData.url
                    })
                    stores.browser.visible = true
                }">直接开玩</el-button>
                <el-button @click="browserClick(data.appData.url)">浏览器打开</el-button>
            </div>
        </div>

        <div class="app-x2">
            <div class="app-x2-left">
                <template v-if="data.appData.placard.length != 0">
                    <img v-for="(item, index) in data.appData.placard" :key="index" :src="stores.config.port + '/placard/'+item.url" alt="">
                </template>
                
                <div v-if="data.appData.placard.length === 0" style="width: 100%; height: 100%; display: flex; justify-content: center; align-items: center; color: #b5bac1;">未上传海报...</div>
            </div>

            <div class="app-x2-right">
                <div>
                    <h2>人气</h2>
                    <div>
                        <p>热度：{{data.hot}}</p>
                        <p>讨论：{{ data.comments.length }}</p>

                        <div class="app-x2-right-like">
                            <p>喜欢：{{ data.appData.interact.like.length }}</p>
                            <i @click="clickClap"><img style="height: 26px;" src="../../assets/app/guzhang.svg" alt=""></i>
                        </div>
                    </div>
                </div>

                <div class="app-x2-right-tags">
                    <h2>标签</h2>
                    <div>
                        <el-tag v-for="(item, index) in data.appData.tag" :key="index" type="primary">{{item}}</el-tag>
                    </div>
                </div>
            </div>
        </div>

        <div class="app-x3">
            <h1>简介</h1>
            <p>{{data.appData.desc}}</p>
        </div>

        <div class="app-x4">
            <h1>讨论区：{{data.comments.length}} 条</h1>
            <div class="app-input">
                <el-input
                    v-model="data.commentText"
                    class="app-input-textarea"
                    :rows="5"
                    type="textarea"
                    placeholder="请输入讨论内容..."
                />
                <div class="app-input-btn">
                    <span>还可以输入 1000 字</span>
                    <el-button @click="sendComment" type="primary">发送</el-button>
                </div>
            </div>

            <!-- 讨论区 -->
            <div class="app-discuss">
                <ul>
                    <li v-for="(item, index) in data.comments" :key="index">
                        <div class="app-discuss-user">
                            <div>
                                <p>{{item.nickname}}</p>
                                <span class="app-discuss-time">{{stores.formatDate(item.createdAt)}}</span>
                            </div>
                            <div @click="clickCommentClap(item.comment_id, index)" class="app-discuss-like">
                                <img src="../../assets/app/guzhang.svg" alt="">
                                <span>{{item.interact.like.length}}</span>
                            </div>
                        </div>

                        <p class="app-discuss-content">{{item.content}}</p>
                    </li>

                    <i>没有更多讨论了...</i>
                </ul>
            </div>
        </div>
    </div>
</div>
</template>

<style scoped>
.app-x2-right-like i:hover{
    transform: scale(1.3);
}
.app-x2-right-like i{
    height: 26px;
    margin-top: -22px;
    margin-left: 6px;
    cursor: pointer;
    transition: all 0.3s;
}
.app-x2-right-like{
    display: flex;
    align-items: center;
}
.app-discuss-time{
    font-size: 14px;
    color: #8d9198;
    margin-left: 10px;
    margin-top: -3px;
}
.app-discuss-like span{
    margin-top: 3px;
    font-size: 14px;
    color: #8d9198;
}
.app-discuss-like{
    cursor: pointer;
}
.app-discuss-user img:hover{
    transform: scale(1.3);
}
.app-discuss-user img{
    width: 20px;
    height: 20px;
    margin-right: 6px;
    transition: all 0.3s;
}
.app-discuss-user div{
    display: flex;
    align-items: center;
}
.app-discuss-user p{
    font-size: 15px;
    color: #333;
    margin-bottom: 6px;
}
.app-discuss-user{
    display: flex;
    justify-content: space-between;
}
.app-discuss-content{
    margin-top: 12px;
    font-size: 14px;
    color: #333;
    line-height: 1.5;
}
.app-discuss ul i{
    display: block;
    text-align: center;
    color: #b5bac1;
    margin-top: 20px;
    padding-bottom: 20px;
}
.app-discuss li{
    padding-bottom: 20px;
    margin-top: 20px;
    border-bottom: 1px solid #4b4b4b;
}
.app-discuss{
    margin-top: 26px;
}
.app-input-btn span{
    color: #4e5058;
    font-size: 14px;
}
.app-input-btn{
    height: 32px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 6px 10px;
}
.app-input-textarea{
    width: 100%;
}
.app-input{
    background: #fff;
    border-radius: 3px;
}
.app-x4 h1{
    font-size: 18px;
    color: #333;
    margin-bottom: 16px;
}
.app-x4{
    width:calc(100% - 300px);
    margin-top: 28px;
}
.app-x3 p{
    font-size: 14px;
    color: #818181;
    margin-bottom: 16px;
    line-height: 1.8;
}
.app-x3 h1{
    font-size: 18px;
    font-weight: 700;
    color: #333;
    margin-bottom: 16px;
}
.app-x3{
    width: calc(100% - 300px);
    margin-top: 20px;
}
.app-x2-right-tags .el-tag{
    margin-right: 10px;
    margin-bottom: 10px;
}
.app-x2-right p{
    height: 32px;
    font-size: 14px;
    color: #818181;
}
.app-x2-right h2{
    font-size: 16px;
    font-weight: 700;
    color: #333;
    margin-bottom: 16px;
}
.app-x2-right{
    width: 280px;
}
.app-x2-left img{
    height: 360px;
    margin-right: 10px;
    border-radius: 6px;
}
.app-x2-left{
    width: calc(100% - 300px);
    padding-bottom: 10px;
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    overflow-y: hidden;
}
.app-x2{
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
}
.app-x1 h1{
    font-size: 24px;
    color: #333;
}
.app-x1{
    margin-top: 30px;
    display: flex;
    justify-content: space-between;
}
.app-logo{
    display: block;
    width: 68px;
    height: 68px;
    padding: 10px;
    margin-top: 20px;
    margin-bottom: 20px;
    background: #ffffff;
    border-radius: 10px;
    border: 1px solid #e2e2e2;
}
.el-icon{
    font-size: 22px;
    color: #333;
    cursor: pointer;
    padding: 6px;
    border-radius: 5px;
    background: #fff;
    margin-top: 20px;
    border: 1px solid #e2e2e2;
}
.el-icon:hover{
    background: #fafafa;
}
.app-content{
    width: 78%;
    height: 100%;
    margin: 0 auto;
}
</style>