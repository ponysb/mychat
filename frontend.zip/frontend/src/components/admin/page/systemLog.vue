<script setup>
import axios from 'axios'
import { ref, reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    logs: [],
    time: new Date(),
})
fetchSystemLog()
function fetchSystemLog() {
    axios({
        method: 'get',
        url: stores.config.port + '/api/v1/admin/getLogList?time='+ data.time,
        headers: {
            'Content-Type': 'application/json;charset=UTF-8',
            'Authorization': 'Bearer '+ localStorage.getItem('adminToken')
        }
    })
    .then(response => {
        data.logs = response.data.data.split('\n').reverse()
    })
   .catch(err => {
        console.log(err)
        ElMessage({
            message: err.response.data.message,
            type: 'warning',
        })
        data.logs = []
    })
}
</script>

<template>
    <div class="systemlog">
        <el-date-picker
            v-model="data.time"
            type="date"
            placeholder="选择日期"
            size="small"
            @change="fetchSystemLog"
      />
        <p v-for="(log, index) in data.logs" :key="index">{{ log }}</p>
    </div>
</template>

<style scoped>
.systemlog p{
    font-size: 14px;
    font-weight: 300;
    line-height: 1.6;
    color: #0f0;
    margin-bottom: 8px;
    letter-spacing: .4px;
}
.systemlog{
    height: 100%;
    background: #000000;
    padding: 20px;
    overflow: auto;
}
</style>