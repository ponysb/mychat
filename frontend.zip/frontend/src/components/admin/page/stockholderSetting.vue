<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    vip:0,
    pro:0
})

// 获取商品信息
getStockholderSetting()
function getStockholderSetting() {
    axios.get(stores.config.port + '/api/v1/admin/goods', {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
            data.vip = res.data.data.vip
            data.pro = res.data.data.pro
    })
    .catch(err => {
        console.log(err)
    })
}


// 更新商品信息
function updateStockholderSetting() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/goods',
        data: {
            vip: Number(data.vip),
            pro: Number(data.pro)
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
        console.log(res)
        getStockholderSetting()
    })
    .catch(err => {
        console.log(err)
    })
}

</script>

<template>
    <div class="stockholder-setting-box">
        <div class="stockholder-setting-content">
            <h1>股东设置</h1>

            <div style="display: flex; flex-wrap: wrap;">
                <el-form :inline="true" :model="data" class="demo-form-inline">

                    <el-form-item label="摸鱼股东">
                        <el-input v-model="data.vip" placeholder="请输入入股金额" clearable />
                    </el-form-item>

                    <el-form-item label="超级摸鱼股东">
                        <el-input v-model="data.pro" placeholder="请输入入股金额" clearable />
                    </el-form-item>

                    <el-form-item label="">
                        <el-button type="primary" @click="updateStockholderSetting">更新</el-button>
                    </el-form-item>
                </el-form>
            </div>

            
        </div>
    </div>
</template>

<style scoped>
.stockholder-setting-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.stockholder-setting-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.stockholder-setting-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>