<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    avatarData: []
})

// 获取群头像数据
getAvatarData()
function getAvatarData() {
    axios.get(stores.config.port + '/api/v1/admin/roomAvatars', {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
        data.avatarData = res.data.data
    })
}


// 设为违规
function handleDelete(avatar) {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/restoreRoomAvatarGroup',
        data: {
            avatar: avatar
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
        getAvatarData()
    })
}

</script>

<template>
    <div class="room-avatar-box">
        <div class="room-avatar-content">
            <h1>房间头像集体审核</h1>

            <div style="display: flex; flex-wrap: wrap;">
                <div v-for="(item, index) in data.avatarData" style="width: 100px; text-align: center; margin-bottom: 16px;">
                    <el-avatar :src="stores.config.port + '/group/'+item" />
                    <el-button style="margin-top: 6px;" type="danger" size="small" @click="handleDelete(item)">设为违规</el-button>
                </div>
            </div>

            
        </div>
    </div>
</template>

<style scoped>
.room-avatar-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.room-avatar-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.room-avatar-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>