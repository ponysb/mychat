<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    form:{
        room_id: '',
        name:'',
        owner_id: '',
        createdAt: [],
    },
    tableData: [],

    selectForm: {
        visible: false,
        avatar: '',
        room_id: '',
        name:'',
        desc: '',
        createdAt: [],
    },

    records: {
        visible: false,
        room_id: '',
        records: [],
        limit: 1000,
        offset: 0,
        total: 0,
    },
})

// 获取房间列表
getRooms()
function getRooms() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/rooms',
        data: data.form,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
        console.log(res.data)
        data.tableData = res.data.data
    })
    .catch(err => {
        console.log(err)
    })
}


// 编辑房间
function editRoom() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/editRoom',
        data: {
            room_id: data.selectForm.room_id,
            name: data.selectForm.name,
            desc: data.selectForm.desc,
            status: data.selectForm.status
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        ElMessage({
            message: '房间信息修改成功，刷新页面后生效',
            type:'success',
        })
        data.selectForm.visible = false // 关闭编辑弹窗
        getRooms()
    })
    .catch(err => {
        ElMessage({
            message: '房间信息修改失败',
            type: 'error',
        })
        console.log(err)
    })
}

// 设置头像违规
function setAvatarIllegal(room_id) {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/restoreRoomAvatar',
        data: {
            room_id: room_id,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        ElMessage({
            message: '头像违规设置成功，刷新页面后生效',
            type:'success',
        })
    })
    .catch(err => {
        console.log(err)
        ElMessage({
            message: '头像违规设置失败',
            type: 'error',
        })
    })
}


// 获取聊天记录
function getRecords(room_id) {
    data.records.visible = true
    data.records.room_id = room_id
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/getRecords',
        data: {
            room_id: room_id,
            limit: data.records.limit,
            offset: data.records.offset,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        data.records.records = res.data.data.records
        data.records.total = res.data.data.totalCount / 100
        console.log(data.records.total)
    })
    .catch(err => {
        console.log(err)
    })
}


// 翻页
function switchPage(currentPage) {
    console.log(currentPage)
    data.records.offset = (currentPage - 1) * 1000
    getRecords(data.records.room_id)
}
</script>

<template>

    <!-- 房间信息编辑 -->
    <el-dialog title="编辑房间信息" v-model="data.selectForm.visible" style="width: 500px;">
        <p style="color:brown; margin-left: 12px; margin-bottom: 13px;">用户信息违规情况下修改，谨慎操作！</p>

        <el-form ref="form" :model="data.selectForm" label-width="80px">

            <el-form-item label="房间头像">
                <el-avatar :size="50" :src="stores.config.port + '/group/'+data.selectForm.avatar" />
                <el-button @click="setAvatarIllegal(data.selectForm.room_id)" style="margin-left: 10px;" size="small" type="default">设为违规</el-button>
            </el-form-item>

            <el-form-item label="房间名称">
                <el-input v-model="data.selectForm.name" placeholder="请输入房间名称" clearable />
            </el-form-item>

            <el-form-item label="房间介绍">
                <el-input v-model="data.selectForm.desc" placeholder="请输入房间介绍" clearable />
            </el-form-item>

            <el-form-item label="用户状态">
                <el-select v-model="data.selectForm.status">
                    <el-option label="正常" :value="1"></el-option>
                    <el-option label="冻结" :value="2"></el-option>
                </el-select>
            </el-form-item>
             
        </el-form>

        <template #footer>
            <div class="dialog-footer">
                <el-button @click="data.selectForm.visible = false">取消</el-button>
                <el-button type="primary" @click="editRoom">保存</el-button>
            </div>
        </template>
    </el-dialog>


    <!-- 聊天记录 -->
    <el-dialog title="聊天记录" v-model="data.records.visible" style="width: 1500px; height: 800px;">
        <el-table :data="data.records.records" border style="width: 100%; height: 680px;">
            <el-table-column label="房间ID" prop="room_id"></el-table-column>
            <el-table-column label="用户名" prop="username"></el-table-column>
            <el-table-column label="用户昵称" prop="nickname"></el-table-column>
            <el-table-column label="消息内容" prop="msg"></el-table-column>
            <el-table-column label="原内容" prop="ymsg"></el-table-column>
            <el-table-column label="消息类型" prop="type"></el-table-column>
            <el-table-column label="发送时间" prop="createdAt">
                <template #default="{ row }">
                    {{ stores.formatDate(row.createdAt) }}
                </template>
            </el-table-column>
        </el-table>
        <el-pagination @change="switchPage" background layout="prev, pager, next" style="margin-top: 15px;" :total="data.records.total" />
    </el-dialog>

    <div class="rooms-box">
        <div class="rooms-content">
            <h1>房间管理</h1>
            <el-form :inline="true" :model="data.form" class="demo-form-inline">

                <el-form-item label="房间ID">
                    <el-input v-model="data.form.room_id" placeholder="请输入房间ID" clearable />
                </el-form-item>

                <el-form-item label="房间名">
                    <el-input v-model="data.form.name" placeholder="请输入房间名" clearable />
                </el-form-item>

                <el-form-item label="创建人ID">
                    <el-input v-model="data.form.owner_id" placeholder="请输入创建人用户名" clearable />
                </el-form-item>
                
                <el-form-item label="创建日期">
                    <el-date-picker
                        style="width: 220px;"
                        v-model="data.form.createdAt"
                        type="daterange"
                        range-separator="-"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间"
                    />
                </el-form-item>
                
                <el-form-item>
                    <el-button type="primary" @click="getRooms">搜索</el-button>
                    <el-button type="default" @click="() => {
                        data.form = {
                            room_id: '',
                            name:'',
                            owner_id: '',
                            createdAt: [],
                        }
                        getRooms()
                    }">重置</el-button>
                </el-form-item>
            </el-form>
            <el-table :data="data.tableData" border style="width: 100%; height: calc(100% - 88px);">
                <el-table-column label="房间ID" prop="room_id"></el-table-column>
                <el-table-column label="房间名" prop="name"></el-table-column>
                <el-table-column label="房间头像" prop="avatar">
                    <template #default="{ row }">
                        <el-avatar :size="50" :src="stores.config.port + '/group/'+row.avatar" />
                    </template>
                </el-table-column>
                <el-table-column label="房间介绍" prop="desc"></el-table-column>
                <el-table-column label="房主ID" prop="owner_id"></el-table-column>
                <el-table-column label="成员数量" prop="users">
                    <template #default="{ row }">
                        {{ row.users.length }}
                    </template>
                </el-table-column>
                <el-table-column label="房间状态" prop="status">
                    <template #default="{ row }">
                        <el-tag v-if="row.status === 1" type="success">正常</el-tag>
                        <el-tag v-if="row.status === 2" type="danger">冻结</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="房间公告" prop="announcement">
                    <template #default="{ row }">
                        {{ row.announcement.length }}
                    </template>
                </el-table-column>
                <el-table-column label="聊天记录" prop="announcement">
                    <template #default="{ row }">
                        <el-button @click="getRecords(row.room_id)" link type="primary">查看</el-button>
                    </template>
                </el-table-column>
                <el-table-column label="创建日期" prop="createdAt">
                    <template #default="{ row }">
                        {{ stores.formatDate(row.createdAt) }}
                    </template>
                </el-table-column>
                <!-- 固定列 -->
                <el-table-column label="操作" width="88" fixed="right">
                    <template #default="{ row }">
                        <el-button @click="() => {
                            data.selectForm = {
                                visible: true,
                                room_id: row.room_id,
                                avatar: row.avatar,
                                name: row.name,
                                desc: row.desc,
                                status: row.status,
                            }
                        }" size="small" type="primary">编辑</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<style scoped>
.rooms-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.rooms-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.rooms-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>