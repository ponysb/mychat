<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    tableData: [],
    form: {
        visible: false,
        content: '',
        valid_time: []
    },

    formEdit: {
        visible: false,
        notice_id: '',
        content: '',
        valid_time: [],
        status: 1
    }
})


// 获取公告列表
getNoticeList()
function getNoticeList() {
    axios({
        method: 'get',
        url: stores.config.port + '/api/v1/admin/notices',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        data.tableData = res.data.data
    })
    .catch(err => {
        console.log(err)
    })
}

// 添加公告
function addNotice() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/writeNotice',
        data: {
            content: data.form.content,
            valid_time: data.form.valid_time
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res)
        data.form.visible = false
        getNoticeList()
    })
    .catch(err => {
        console.log(err)
    })
}


// 编辑公告
function handleEdit() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/editNotice',
        data: {
            notice_id: data.formEdit.notice_id,
            content: data.formEdit.content,
            valid_time: data.formEdit.valid_time,
            status: data.formEdit.status
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res)
        data.formEdit.visible = false
        getNoticeList()
    })
    .catch(err => {
        console.log(err)
    })
}


</script>

<template>

    <!-- 编辑公告 -->
    <el-dialog title="编辑公告" v-model="data.formEdit.visible" style="width: 500px; max-height: 880px; overflow: auto;">

        <el-form ref="form" :model="data.add_room" label-width="80px">

            <el-form-item label="公告内容">
                <el-input type="textarea" v-model="data.formEdit.content" placeholder="请输入公告内容" clearable />
            </el-form-item>

            <el-form-item label="有效期">
                <el-date-picker
                        style="width: 220px;"
                        v-model="data.formEdit.valid_time"
                        type="daterange"
                        range-separator="-"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间"
                    />
            </el-form-item>

            <el-form-item label="公告状态">
                <el-select v-model="data.formEdit.status" placeholder="请选择" style="width: 160px">
                    <el-option label="有效" :value="1"/>
                    <el-option label="作废" :value="2"/>
                </el-select>
            </el-form-item>
        </el-form>

        <template #footer>
            <div class="dialog-footer">
                <el-button @click="data.formEdit.visible = false">取消</el-button>
                <el-button type="primary" @click="handleEdit">保存</el-button>
            </div>
        </template>
    </el-dialog>



    <!-- 添加公告 -->
    <el-dialog title="添加公告" v-model="data.form.visible" style="width: 500px; max-height: 880px; overflow: auto;">

        <el-form ref="form" :model="data.add_room" label-width="80px">

            <el-form-item label="公告内容">
                <el-input type="textarea" v-model="data.form.content" placeholder="请输入公告内容" clearable />
            </el-form-item>


            <el-form-item label="有效期">
                <el-date-picker
                        style="width: 220px;"
                        v-model="data.form.valid_time"
                        type="daterange"
                        range-separator="-"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间"
                    />
            </el-form-item>


        </el-form>

        <template #footer>
            <div class="dialog-footer">
                <el-button @click="data.form.visible = false">取消</el-button>
                <el-button type="primary" @click="addNotice">保存</el-button>
            </div>
        </template>
    </el-dialog>


    <div class="order-box">
        <div class="order-content">
            <h1>系统公告</h1>
            <div style="margin-bottom: 10px;">
                <el-button type="primary" @click="data.form.visible = true">添加公告</el-button>
            </div>
            <el-table :data="data.tableData" border style="width: 100%">
                <el-table-column label="公告ID" prop="notice_id"></el-table-column>
                <el-table-column label="公告内容" prop="content"></el-table-column>
                <el-table-column label="有效期" prop="valid_time">
                    <template #default="{ row }">
                        {{ stores.formatDate(row.valid_time[0]) }} - {{ stores.formatDate(row.valid_time[1]) }}
                    </template>
                </el-table-column>
                <el-table-column label="看过人数" prop="look_num"></el-table-column>
                <el-table-column label="公告状态" prop="status">
                    <template #default="{ row }">
                        <el-tag v-if="row.status === 1" type="success">正常</el-tag>
                        <el-tag v-if="row.status === 2" type="warning">作废</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="创建日期" prop="createdAt">
                    <template #default="{ row }">
                        {{ stores.formatDate(row.createdAt) }}
                    </template>
                </el-table-column>

                <!-- 固定列 -->
                <el-table-column label="操作" width="88" fixed="right">
                    <template #default="{ row }">
                        <el-button type="text" @click="() => {
                            data.formEdit = {
                                visible: true,
                                notice_id: row.notice_id,
                                content: row.content,
                                valid_time: row.valid_time,
                                status: row.status
                            }
                        }">编辑</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<style scoped>
.order-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.order-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.order-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>