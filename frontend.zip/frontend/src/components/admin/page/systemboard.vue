<template>
    <div>
        /admin/systemboard
    </div>
</template>