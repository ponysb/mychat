<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    avatarList: [],
})

// 请求头像列表
getAvatarList()
function getAvatarList() {
    axios.get(stores.config.port + '/api/v1/admin/userAvatars', {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
        // 对象转数组
        data.avatarList = Object.values(res.data.data)
        console.log(data.avatarList)
    })
}

// 头像设为违规
function setAvatarIllegal(avatar) {
    let username = avatar.split('.')[0]
    axios({
        method: 'POST',
        url: stores.config.port + '/api/v1/admin/avatarIllegal',
        data: {
            username: username,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        ElMessage({
            message: '头像已设为违规，刷新查看效果',
            type: 'success',
        })
    })
    .catch(err => {
        console.log(err)
        ElMessage({
            message: err.response.data.message,
            type: 'error',
        })
    })
}

</script>

<template>
    <div class="user-avatar-box">
        <div class="user-avatar-content">
            <h1>用户头像集体审核</h1>

            <div style="display: flex; flex-wrap: wrap; height: calc(100% - 38px); overflow: auto;">
                <div v-for="(avatar, index) in data.avatarList" :key="index" style="width: 100px; text-align: center; margin-bottom: 16px;">
                    <el-avatar :src="stores.config.port + '/user/'+avatar" />
                    <p style="margin-top: 6px;">{{avatar}}</p>
                    <el-button style="margin-top: 6px;" type="danger" size="small" @click="setAvatarIllegal(avatar)">设为违规</el-button>
                </div>
            </div>

            
        </div>
    </div>
</template>

<style scoped>
.user-avatar-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.user-avatar-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.user-avatar-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>