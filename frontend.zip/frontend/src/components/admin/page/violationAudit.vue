<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    form:{
        username: '',
        status: 1
    },
    tableData: []
})

// 获取数据
getData()
function getData() {
    axios({
        method: 'get',
        url: stores.config.port + '/api/v1/admin/reportData',
        params: data.form,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        // 处理数据
        data.tableData = res.data.data
    })
   .catch(err => {
        console.log(err)
    })
}

// 封禁或忽略
function handleEdit(affair_id, report_id, reason, status) {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/banUser',
        data: {
            affair_id,
            report_id,
            reason,
            status,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
   .then(res => {
        console.log(res.data)
        ElMessage({
            message: '操作成功',
            type:'success',
        })
        // 刷新数据
        getData()
    })
   .catch(err => {
        console.log(err)
        ElMessage({
            message: err.response.data.message,
            type: 'error',
        })
    })
}

</script>

<template>
    <div class="report-box">
        <div class="report-content">
            <h1>举报管理</h1>
            <el-form :inline="true" :model="data.form" class="demo-form-inline">

                <el-form-item label="用户名">
                    <el-input v-model="data.form.username" placeholder="请输入用户名" clearable />
                </el-form-item>

                <el-form-item label="审核状态">
                    <el-select v-model="data.form.status" placeholder="Select" style="width: 160px">
                        <el-option label="未处理" :value="1"/>
                        <el-option label="已封禁" :value="2"/>
                        <el-option label="忽略" :value="3"/>
                    </el-select>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="getData">搜索</el-button>
                    <el-button type="default" @click="() => {
                        data.form.username = '';
                        data.form.status = 1;
                        getData()
                    }">重置</el-button>
                </el-form-item>
            </el-form>
            <el-table :data="data.tableData" border style="width: 100%; height: calc(100% - 88px);">
                <el-table-column label="举报ID" prop="report_id"></el-table-column>
                <el-table-column label="举报人" prop="username"></el-table-column>
                <el-table-column label="举报类型" prop="type"></el-table-column>
                <el-table-column label="举报原因" prop="reason"></el-table-column>
                <el-table-column label="举报内容" prop="content"></el-table-column>
                <el-table-column label="审核状态" prop="status">
                    <template #default="{ row }">
                        <el-tag v-if="row.status === 1" type="primary">未处理</el-tag>
                        <el-tag v-if="row.status === 2" type="danger">已封禁</el-tag>
                        <el-tag v-if="row.status === 3" type="info">已忽略</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="举报时间" prop="createdAt">
                    <template #default="{ row }">
                        <div>{{ stores.formatDate(row.createdAt) }}</div>
                    </template>
                </el-table-column>
                <!-- 固定列 -->
                <el-table-column label="操作" width="150" fixed="right">
                    <template #default="{ row }">
                        <el-button size="small" type="primary" @click="handleEdit(row.affair_id, row.report_id, row.reason, 2)">封禁</el-button>
                        <el-button size="small" type="default" @click="handleEdit(row.affair_id, row.report_id, '', 3)">忽略</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<style scoped>
.report-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.report-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.report-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>