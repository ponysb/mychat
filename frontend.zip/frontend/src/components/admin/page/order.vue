<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    searchForm: {
        username: '',
        order_id: '',
        createdAt: [],
        status: null,
        goods: '',
    },

    tableData:[]
})

// 请求订单数据
getOrderData()
function getOrderData() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/orders',
        data: data.searchForm,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
        data.tableData = res.data.data
    })
    .catch(err => {
        console.log(err)
    })
}

</script>

<template>
    <div class="order-box">
        <div class="order-content">
            <h1>订单管理</h1>
            <el-form :inline="true" :model="data.searchForm" class="demo-form-inline">

                <el-form-item label="用户名">
                    <el-input v-model="data.searchForm.username" placeholder="请输入用户名" clearable />
                </el-form-item>

                <el-form-item label="订单号">
                    <el-input v-model="data.searchForm.order_id" placeholder="请输入订单号" clearable />
                </el-form-item>

                <el-form-item label="订单状态">
                    <el-select v-model="data.searchForm.status" placeholder="请选择" style="width: 160px">
                        <el-option label="全部" :value="null"></el-option>
                        <el-option label="待付款" :value="0"></el-option>
                        <el-option label="已付款" :value="1"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item label="商品">
                    <el-select v-model="data.searchForm.goods" placeholder="请选择" style="width: 160px">
                        <el-option label="全部" :value="''"></el-option>
                        <el-option label="摸鱼股东" :value="'摸鱼股东'"></el-option>
                        <el-option label="超级摸鱼股东" :value="'超级摸鱼股东'"></el-option>
                    </el-select>
                </el-form-item>
                
                <el-form-item label="创建日期">
                    <el-date-picker
                        style="width: 220px;"
                        v-model="data.searchForm.createdAt"
                        type="daterange"
                        range-separator="-"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间"
                    />
                </el-form-item>

                
                <el-form-item>
                    <el-button type="primary" @click="getOrderData">搜索</el-button>
                    <el-button type="default" @click="() => {
                        data.searchForm = {
                            username: '',
                            order_id: '',
                            createdAt: [],
                            status: null,
                            goods: '',
                        }
                        getOrderData()
                    }">重置</el-button>
                </el-form-item>
            </el-form>
            <el-table :data="data.tableData" border style="width: 100%; height: calc(100% - 88px);">
                <el-table-column label="订单ID" prop="order_id"></el-table-column>
                <el-table-column label="用户名" prop="username"></el-table-column>
                <el-table-column label="商品" prop="goods"></el-table-column>
                <el-table-column label="金额" prop="price"></el-table-column>
                <el-table-column label="订单状态" prop="status">
                    <template #default="{ row }">
                        <el-tag v-if="row.status === 0" type="warning">待付款</el-tag>
                        <el-tag v-if="row.status === 1" type="success">已付款</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="创建日期" prop="createdAt">
                    <template #default="{ row }">
                        {{ stores.formatDate(row.createdAt) }}
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<style scoped>
.order-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.order-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.order-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>