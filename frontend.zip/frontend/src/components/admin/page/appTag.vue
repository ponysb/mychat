<script setup>
import axios from 'axios';
import { reactive, ref } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    form:{
        visible: false,
        app_name: '',
        status: 1,
    },
    tableData:[]
})


// 请求所有标签
getAppTagList()
function getAppTagList() {
    axios.get(stores.config.port + '/api/v1/admin/appTags', {
        params: {
            tag_name: data.form.tag_name,
            status: data.form.status,
        }
    }).then(res => {
        if (res.data.code === 200) {
            data.tableData = res.data.data;
        }
    })
}

// 编辑标签
function editApp(id, status) {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/editAppTag', 
        data:{
            status: status,
            id: id,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem('adminToken')
        }
    }).then(res => {
        if (res.data.code === 200) {
            getAppTagList();
        }
    })
}

// 添加标签
function addAppTag() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/addAppTag',
        data:{
            tag_name: data.form.tag_name,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+ localStorage.getItem('adminToken')
        }
    }).then(res => {
        if (res.data.code === 200) {
            data.form = {
                visible: false,
                app_name: '',
                status: 1,
            }
            getAppTagList();
        }
    })
}

</script>

<template>

    <!-- 编辑应用信息弹窗 -->
    <el-dialog title="编辑应用信息" v-model="data.form.visible" style="width: 500px;">
        <el-form ref="form" :model="data.form" label-width="80px">

            <el-form-item label="标签名称">
                <el-input v-model="data.form.tag_name" placeholder="请输入标签" clearable />
            </el-form-item>
        </el-form>

        <template #footer>
            <div class="dialog-footer">
                <el-button @click="data.form.visible = false">取消</el-button>
                <el-button type="primary" @click="addAppTag">保存</el-button>
            </div>
        </template>
    </el-dialog>


    <div class="apps-box">
        <div class="apps-content">
            <h1>应用标签管理</h1>
            <el-form :inline="true" :model="data.form" class="demo-form-inline">

                <el-form-item label="标签名称">
                    <el-input v-model="data.form.tag_name" placeholder="请输入应用名称" clearable />
                </el-form-item>

                <el-form-item label="标签状态">
                    <el-select v-model="data.form.status" placeholder="请选择" style="width: 160px">
                        <el-option label="正常" :value="1"/>
                        <el-option label="已禁用" :value="0"/>
                    </el-select>
                </el-form-item>
                
                <el-form-item>
                    <el-button type="primary" @click="getAppTagList">搜索</el-button>
                    <el-button type="default" @click="() => {
                        data.form = {
                            visible: false,
                            app_name: '',
                            status: 1,
                        }
                        getAppTagList();
                    }">重置</el-button>
                    <el-button type="primary" @click="data.form.visible = true">添加标签</el-button>
                </el-form-item>
            </el-form>

            <el-table :data="data.tableData" border style="width: 100%; height: calc(100% - 138px);">
                <el-table-column label="标签ID" prop="id"></el-table-column>
                <el-table-column label="标签名称" prop="tag_name"></el-table-column>
                <el-table-column label="应用数量" prop="app_num"></el-table-column>
                <el-table-column label="标签状态" prop="status">
                    <template #default="{ row }">
                        <el-tag v-if="row.status === 1" type="success">正常</el-tag>
                        <el-tag v-if="row.status === 0" type="warning">已禁用</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="创建时间" prop="title">
                    <template #default="{ row }">
                        {{ stores.formatDate(row.createdAt) }}
                    </template>
                </el-table-column>

                <!-- 操作 -->
                <el-table-column label="操作">
                    <template #default="{ row }">
                        <el-button v-if="row.status === 1" size="small" type="danger" @click="editApp(row.id, 0)">禁用</el-button>
                        <el-button v-if="row.status === 0" size="small" type="danger" @click="editApp(row.id, 1)">启用</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<style scoped>
.apps-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.apps-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.apps-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>