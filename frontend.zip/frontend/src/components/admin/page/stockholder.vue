<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    username:'',
    tableData:[]
})


// 获取股东列表
getStockholderList()
function getStockholderList() {
    axios.get(stores.config.port + '/api/v1/admin/shareholders',{
        params:{
            username:data.username
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    })
    .then(res => {  
        data.tableData = res.data.data
    })
    .catch(err => {
        console.log(err)
    })
}
</script>

<template>
    <div class="stockholder-box">
        <div class="stockholder-content">
            <h1>股东列表</h1>
            <el-form :inline="true" class="demo-form-inline">

                <el-form-item label="用户名">
                    <el-input v-model="data.username" placeholder="请输入用户名" clearable />
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="getStockholderList">搜索</el-button>
                    <el-button type="default" @click="() => {
                        data.username = ''
                        getStockholderList()
                    }">重置</el-button>
                </el-form-item>
            </el-form>
            <el-table :data="data.tableData" border style="width: 100%; height: calc(100% - 88px);">
                <el-table-column label="用户ID" prop="user_id"></el-table-column>
                <el-table-column label="用户名" prop="username"></el-table-column>
                <el-table-column label="头像" prop="avatar">
                    <template #default="{ row }">
                        <el-avatar :size="50" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+row.username" />
                    </template>
                </el-table-column>
                <el-table-column label="用户昵称" prop="nickname"></el-table-column>
                <el-table-column label="邀请码" prop="invite"></el-table-column>
                <el-table-column label="个性签名" prop="signature"></el-table-column>
                <el-table-column label="性别" prop="gender"></el-table-column>
                <el-table-column label="所在房间" prop="rooms">
                    <template #default="{ row }">
                        {{ row.rooms.length }}
                    </template>
                </el-table-column>
                <el-table-column label="邮箱" prop="email"></el-table-column>
                <el-table-column label="手机号" prop="phone"></el-table-column>
                <el-table-column label="注册地" prop="ip"></el-table-column>
                <el-table-column label="用户状态" prop="status">
                    <template #default="{ row }">
                        <el-tag v-if="row.status === 1" type="success">正常</el-tag>
                        <el-tag v-if="row.status === 2" type="danger">冻结</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="注册日期" prop="createdAt">
                    <template #default="{ row }">
                        {{ stores.formatDate(row.createdAt) }}
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<style scoped>
.stockholder-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.stockholder-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.stockholder-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>