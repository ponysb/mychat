<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    mch_id: "1234567890",
    developer_appid: "wx1234567890abcdef"
})

// 获取支付设置
getPaySetting()
function getPaySetting() {
    axios.get(stores.config.port + '/api/v1/admin/payment', {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
            data.mch_id = res.data.data.mch_id
            data.developer_appid = res.data.data.developer_appid
    })
    .catch(err => {
        console.log(err)
    })
}

// 更新支付设置
function updatePaySetting() {
    axios({
        method: 'post',
        url: stores.config.port + '/api/v1/admin/payment',
        data: {
            mch_id: data.mch_id,
            developer_appid: data.developer_appid
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+localStorage.getItem('adminToken')
        }
    }).then(res => {
        console.log(res)
        getPaySetting()
    })
    .catch(err => {
        console.log(err)
    })
}


</script>

<template>
    <div class="pay-box">
        <div class="pay-content">
            <h1>支付设置（蓝兔支付）</h1>

            <div style="display: flex; flex-wrap: wrap;">
                <el-form :inline="true" :model="data" class="demo-form-inline">

                    <el-form-item label="商户号">
                        <el-input v-model="data.mch_id" placeholder="请输入商户号" clearable />
                    </el-form-item>

                    <el-form-item label="应用ID">
                        <el-input v-model="data.developer_appid" placeholder="请输入应用ID" clearable />
                    </el-form-item>

                    <el-form-item label="">
                        <el-button type="primary" @click="updatePaySetting">更新</el-button>
                    </el-form-item>
                </el-form>
            </div>

            
        </div>
    </div>
</template>

<style scoped>
.pay-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.pay-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.pay-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>