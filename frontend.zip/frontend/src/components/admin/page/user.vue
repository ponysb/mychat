<script setup>
import axios from 'axios';
import { reactive } from 'vue'
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const data = reactive({
    // 搜索表单
    searchForm: {
        user_id: '',
        username: '',
        nickname: '',
        email: '',
        phone: '',
        createdAt: [],
    },
    tableData: [],

    form: {
        visible: false,
        user_id: '',
        username: '',
        nickname: '',
        signature: '',
        status: 1,
    },
})


// 获取用户列表
getUserList()
function getUserList() {
    console.log(data.searchForm)
    axios({
        method: 'POST',
        url: stores.config.port + '/api/v1/admin/users',
        data: {
            user_id: data.searchForm.user_id,
            username: data.searchForm.username,
            nickname: data.searchForm.nickname,
            email: data.searchForm.email,
            phone: data.searchForm.phone,
            createdAt: data.searchForm.createdAt,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        data.tableData = res.data.data
    })
    .catch(err => {
        console.log(err)
    })
}


// 头像设为违规
function setAvatarIllegal() {
    axios({
        method: 'POST',
        url: stores.config.port + '/api/v1/admin/avatarIllegal',
        data: {
            username: data.form.username,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        ElMessage({
            message: '头像已设为违规，刷新查看效果',
            type: 'success',
        })
    })
    .catch(err => {
        console.log(err)
        ElMessage({
            message: err.response.data.message,
            type: 'error',
        })
    })
}


// 修改用户信息
function updateUserInfo() {
    axios({
        method: 'POST',
        url: stores.config.port + '/api/v1/admin/editUser',
        data: {
            user_id: data.form.user_id,
            nickname: data.form.nickname,
            signature: data.form.signature,
            status: data.form.status,
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem('adminToken')
        }
    })
    .then(res => {
        console.log(res.data)
        ElMessage({
            message: '用户信息修改成功',
            type:'success',
        })
        getUserList()
        data.form.visible = false
    })
    .catch(err => {
        console.log(err)
        ElMessage({
            message: err.response.data.message,
            type: 'error',
        })
    })
}
</script>

<template>
    <!-- 用户信息编辑 -->
    <el-dialog title="编辑用户信息" v-model="data.form.visible" style="width: 500px;">
        <p style="color:brown; margin-left: 12px; margin-bottom: 13px;">用户信息违规情况下修改，谨慎操作！</p>

        <el-form ref="form" :model="data.add_room" label-width="80px">

            <el-form-item label="用户头像">
                <el-avatar :size="50" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+data.form.username" />
                <el-button @click="setAvatarIllegal" style="margin-left: 10px;" size="small" type="default">设为违规</el-button>
            </el-form-item>

            <el-form-item label="用户昵称">
                <el-input v-model="data.form.nickname" placeholder="请输入用户昵称" clearable />
            </el-form-item>

            <el-form-item label="个性签名">
                <el-input v-model="data.form.signature" placeholder="请输入个性签名" clearable />
            </el-form-item>

            <el-form-item label="用户状态">
                <el-select v-model="data.form.status">
                    <el-option label="正常" :value="1"></el-option>
                    <el-option label="冻结" :value="2"></el-option>
                </el-select>
            </el-form-item>
             
        </el-form>

        <template #footer>
            <div class="dialog-footer">
                <el-button @click="data.form.visible = false">取消</el-button>
                <el-button type="primary" @click="updateUserInfo">保存</el-button>
            </div>
        </template>
    </el-dialog>


    <div class="user-box">
        <div class="user-content">
            <h1>用户列表</h1>
            <el-form :inline="true" :model="data.searchForm" class="demo-form-inline">

                <el-form-item label="用户ID">
                    <el-input v-model="data.searchForm.user_id" placeholder="请输入用户ID" clearable />
                </el-form-item>

                <el-form-item label="用户昵称">
                    <el-input v-model="data.searchForm.nickname" placeholder="请输入用户昵称" clearable />
                </el-form-item>

                <el-form-item label="用户名">
                    <el-input v-model="data.searchForm.username" placeholder="请输入用户名" clearable />
                </el-form-item>

                <el-form-item label="邮箱">
                    <el-input v-model="data.searchForm.email" placeholder="请输入邮箱" clearable />
                </el-form-item>

                <el-form-item label="手机号">
                    <el-input v-model="data.searchForm.phone" placeholder="请输入手机号" clearable />
                </el-form-item>

                <el-form-item label="注册日期">
                    <el-date-picker
                        style="width: 220px;"
                        v-model="data.searchForm.createdAt"
                        type="daterange"
                        range-separator="-"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间"
                    />
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="getUserList">搜索</el-button>
                    <el-button type="default" @click="() => {
                        data.searchForm = {
                            user_id: '',
                            username: '',
                            nickname: '',
                            email: '',
                            phone: '',
                            createdAt: [],
                        }
                        getUserList()
                    }">重置</el-button>
                </el-form-item>
            </el-form>
            <el-table :data="data.tableData" border style="width: 100%; height: calc(100% - 138px);">
                <el-table-column label="用户ID" prop="user_id"></el-table-column>
                <el-table-column label="用户名" prop="username"></el-table-column>
                <el-table-column label="头像" prop="avatar">
                    <template #default="{ row }">
                        <el-avatar :size="50" :src="stores.config.port + '/api/v1/users/getUserAvatar/'+row.username" />
                    </template>
                </el-table-column>
                <el-table-column label="用户昵称" prop="nickname"></el-table-column>
                <el-table-column label="邀请码" prop="invite"></el-table-column>
                <el-table-column label="个性签名" prop="signature"></el-table-column>
                <el-table-column label="性别" prop="gender"></el-table-column>
                <el-table-column label="所在房间" prop="rooms">
                    <template #default="{ row }">
                        <div>{{ row.rooms.length }}</div>
                    </template>
                </el-table-column>
                <el-table-column label="邮箱" prop="email"></el-table-column>
                <el-table-column label="手机号" prop="phone"></el-table-column>
                <el-table-column label="注册地" prop="ip"></el-table-column>
                <el-table-column label="用户状态" prop="status">
                    <template #default="{ row }">
                        <el-tag v-if="row.status === 1" type="success">正常</el-tag>
                        <el-tag v-if="row.status === 2" type="danger">冻结</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="注册日期" prop="createdAt" width="150">
                    <template #default="{ row }">
                        <div>{{ stores.formatDate(row.createdAt) }}</div>
                    </template>
                </el-table-column>
                <!-- 固定列 -->
                <el-table-column label="操作" width="160" fixed="right">
                    <template #default="{row}">
                        <el-button @click="() => {
                            data.form.visible = true
                            data.form.user_id = row.user_id
                            data.form.nickname = row.nickname
                            data.form.username = row.username
                            data.form.signature = row.signature
                            data.form.status = row.status
                        }" size="small" type="primary">编辑</el-button>
                        
                        <el-popconfirm title="重置密码为123456">
                            <template #reference>
                                <el-button size="small" type="danger">重置密码</el-button>
                            </template>

                            <template #actions="{ confirm, cancel }">
                                <el-button size="small" @click="cancel">确定</el-button>
                                <el-button
                                    type="primary"
                                    size="small"
                                    @click="confirm"
                                >
                                    取消
                                </el-button>
                            </template>
                        </el-popconfirm>
                        
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<style scoped>
.user-content h1{
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}
.user-content{
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    background: #fff;
    border: 1px solid #d9d9d9;
}
.user-box {
    height: 100%;
    display: flex;
    padding: 18px;
    box-sizing: border-box;
    background: #f5f5f5;
    justify-content: center;
    align-items: center;
}
</style>