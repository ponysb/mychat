<script setup>
import { useMainStore } from '../../../store/index'
const stores = useMainStore()

function logout(){
    localStorage.removeItem('adminToken')
    stores.admin.user = {
        username: '',
        user_id: '',
    }
    // 刷新页面
    window.location.reload()
}
</script>

<template>
    <div class="header">
        <div class="logo">
            <img src="../../../assets/logo.svg" alt="logo">
            <h1>摸鱼聊天室管理后台</h1>
        </div>

        <div class="user">
            <span>欢迎，{{stores.admin.user.username}}</span>
            <span @click="logout"> 退出登录</span>
        </div>
    </div>
</template>

<style scoped>
.user span:last-child{
    color: #0b78d8;
    font-size: 16px;
    margin-right: 10px;
    cursor: pointer;
}
.user span:last-child:hover{
    color: #0050b3;
}
.user{
    margin-right: 26px;
}
.logo h1{
    font-size: 22px;
    font-weight: bold;
    color: #333;
    margin-left: 6px;
}
.logo img{
    width: 40px;
    height: 40px;
    margin-left: 20px;
}
.logo{
    display: flex;
    align-items: center;
}
.header{
    width: 100%;
    height: 60px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

</style>