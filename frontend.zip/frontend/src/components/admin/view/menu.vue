<script setup>
import { useRouter } from 'vue-router';
import { IconPark } from '@icon-park/vue-next/es/all';
import { useMainStore } from "../../../store/index";
const stores = useMainStore();
const router = useRouter();


// 点击子菜单
function sunMenuClick(item, child) {
    if(item.name === '机器人管理'){
        ElMessage.error("功能开发中...")
        return;
    }else{
        router.push({path:child.url})
    }
}
</script>

<template>
    <div>
        <el-row class="tac">
            <el-col>
                <el-menu default-active="2" class="el-menu-vertical-demo">
                    <template v-for="(item, index) in stores.admin.menu_list" :key="index">
                        <el-menu-item v-if="item.children.length === 0" :index="item.routeName">
                            <div @click="router.push({path:item.url})" style="height: 32px; display: flex; align-items: center;">
                                <el-icon>
                                    <IconPark :type="item.icon" size="18" />
                                </el-icon>
                                {{item.name}}
                            </div>
                            
                        </el-menu-item>
                        <el-sub-menu v-else :index="item.routeName">
                            <template #title>
                                <el-icon>
                                    <IconPark :type="item.icon" size="18" />
                                </el-icon>
                                {{ item.name }}
                            </template>
                            <el-menu-item @click="sunMenuClick(item, child)" v-for="(child, index) in item.children" :key="index" :index="child.routeName">
                                <el-icon>
                                    <IconPark :type="child.icon" size="18" />
                                </el-icon>
                                {{ child.name }}
                            </el-menu-item>
                        </el-sub-menu>
                    </template>
                </el-menu>
            </el-col>
        </el-row>
    </div>
</template>

<style>
.el-menu{
    border: none;
}
</style>