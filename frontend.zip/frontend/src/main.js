import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import { createPinia } from 'pinia'
import router from './router'; // 导入路由配置
import ElementPlus from 'element-plus'
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import * as ElIconList from '@element-plus/icons-vue'

const app = createApp(App);
app.use(createPinia()); // 注册状态管理插件

app.use(ElementPlus, {
    locale: zhCn,
})

// 注册icon
for (const name in ElIconList) {
    app.component(name, ElIconList[name])
}


app.use(router); // 注册路由插件
app.mount('#app');